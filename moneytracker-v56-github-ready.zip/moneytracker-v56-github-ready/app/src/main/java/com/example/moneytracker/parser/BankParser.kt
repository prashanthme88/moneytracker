package com.example.moneytracker.parser

import com.example.moneytracker.data.TxType
import java.text.SimpleDateFormat
import java.util.Locale

sealed interface Parsed {
    data class Tx(val amount: Double, val currency: String, val type: TxType, val merchant: String?,
                  val account: String?, val kind: String?, val category: String, val transactionTimestamp: Long? = null) : Parsed
    data class BillInfo(val title: String, val amount: Double?, val currency: String?, val dueDate: Long?, val subscription: Boolean) : Parsed
    data class BalanceInfo(val bank: String, val account: String?, val currency: String, val amount: Double) : Parsed
}

object BankParser {
    /** SMS sender IDs to read (edit in Settings). Notifications are read from any app but must pass the strict check. */
    val smsSenders = mutableSetOf(
        "ENBD", "ENBDX", "EmiratesNBD", "ADCB", "FAB", "MASHREQ", "DIB", "RAKBANK", "Dubai First", "DubaiFirst", "Etisalat", "e&", "DEWA", "DU", "Salik", "Empower",
        // India: major public/private banks and common SMS sender aliases
        "HDFCBK", "HDFCBANK", "HDFC Bank", "ICICIB", "ICICI Bank", "SBIINB", "SBI", "State Bank of India",
        "AXISBK", "Axis Bank", "KOTAK", "AD-KOTAKB-S", "Kotak Mahindra", "PNBSMS", "Punjab National Bank",
        "BOB", "Bank of Baroda", "CANBNK", "Canara Bank", "IDFCFB", "IDFC FIRST", "YESBANK",
        "INDUSIND", "UNIONBANK", "IDBI", "FEDERAL", "RBLBANK", "BANK OF INDIA", "IOB"
    )
    /** Include Emirates NBD aliases even if an older saved sender list only contains ENBD. */
    fun smsSenderMatches(): List<String> = (smsSenders.toList() + listOf("EmiratesNBD", "ENBD", "ENBDX", "Etisalat", "e&", "DEWA", "DU", "Salik", "Empower"))
        .map { it.trim() }.filter { it.isNotEmpty() }.distinctBy { it.lowercase(Locale.ROOT) } + listOf("Dubai First", "DubaiFirst")
    fun isBankSender(s: String): Boolean {
        val sender = s.trim()
        // Explicit exception: Kotak's transactional sender uses the AD-KOTAKB-S alias.
        if (sender.equals("AD-KOTAKB-S", ignoreCase = true) || sender.contains("AD-KOTAKB-S", ignoreCase = true)) return true
        // Utility bill SMS must be accepted even when an older saved sender list omits the provider.
        if (sender.contains("etisalat", ignoreCase = true) || sender.equals("e&", ignoreCase = true) || sender.startsWith("eand", ignoreCase = true)) return true
        if (sender.contains("dewa", ignoreCase = true) || sender.contains("dubai electricity", ignoreCase = true) || sender.contains("dubaiwater", ignoreCase = true)) return true
        if (sender.equals("DU", ignoreCase = true) || sender.startsWith("DU-", ignoreCase = true) || sender.contains("du telecom", ignoreCase = true)) return true
        if (sender.contains("salik", ignoreCase = true) || sender.contains("empower", ignoreCase = true)) return true
        // Other AD-* sender IDs are promotional and must not be parsed.
        if (sender.startsWith("AD-", ignoreCase = true)) return false
        return smsSenderMatches().any { sender.contains(it, ignoreCase = true) }
    }

    private val I = RegexOption.IGNORE_CASE
    private const val CUR = "AED|DHS?|USD|EUR|GBP|INR|SAR|QAR|KWD|BHD|OMR|CAD|AUD|NZD|SGD|MYR|IDR|PHP|THB|JPY|CNY|CNH|HKD|CHF|ZAR|PKR|BDT|LKR|NPR|TRY|RUB|KRW|SEK|NOK|DKK|PLN|CZK|HUF|BRL|MXN|Rs\\.?"
    private val amtA = Regex("""\b($CUR)\.?\s?([\d,]+(?:\.\d{1,3})?)""", I)
    private val amtB = Regex("""([\d,]+(?:\.\d{1,3})?)\s?($CUR)\b""", I)
    private val ctxBad = Regex("""(balance|\bbal\b|limit|avl|avail|outstanding|minimum|total\s+(amount\s+)?due)""", I)
    private val minRx = Regex("min", I)
    private val skip = Regex("""\b(otp|one[- ]time|verification code|cvv|declined|failed|unsuccessful|insufficient|not authori[sz]ed|pre-?approved|apply now|click here|promo)""", I)
    // Exclude marketing copy that mentions a potential reward amount but is not an actual posted credit.
    private val marketing = Regex("""\b(get|win|earn|enjoy|unlock|up to|up-to|offer|offers|promotional|promotion|marketing message|limited time|join|refer|invite|shop and|get rewarded|cashback offer|cashback up to|bonus points|promo code|use code|spend .* get|buy .* get|eligible to win)\b""", I)
    private val postedCredit = Regex("""\b(cashback of|cashback credited|cashback received|cashback has been credited|credited with|refund of|refund credited|amount credited|you have received|successfully credited)\b""", I)
    private val credit = Regex("""\b(credited|received|deposited|salary|payroll|refund(?:ed)?|reversal|reversed|cashback)\b""", I)
    private val debit = Regex("""\b(spent|purchase[d]?|debited|deducted|withdrawn|withdrawal|cash withdrawal|charged|paid|payment of|used (?:for|at)|card transaction|card purchase|pos transaction|transfer(?:red)? to|telegraphic transfer|issuance of telegraphic transfer|sent|pos|atm)\b""", I)
    private val cardPay = Regex("""(credit card payment|card payment|payment (?:of .{0,80})?for card.{0,50}processed|payment (?:of .{0,25})?(?:received|credited).{0,40}card|payment towards .{0,20}card|towards payment of (?:your )?credit card|payment of your credit card|thank you for your payment)""", I)
    private val balRx = Regex("""\b(avl|available|bal|balance|limit)\b""", I)
    private val kCredit = Regex("""credit\s*card|\bcc\b""", I); private val kDebit = Regex("""debit\s*card""", I)
    private val kCard = Regex("""\bcard\b""", I); private val kAcct = Regex("""a/c|\bacct?\b|account""", I)
    private val last4a = Regex("""(?:card|a/c|acct?\.?|account)\s*(?:no\.?|number|#)?\s*(?:ending(?:\s+with|\s+in)?|ends\s+with)?\s*:?\s*[xX*•.\-]*\s*(\d{4})\b""", I)
    private val last4b = Regex("""(?:ending|ends)(?:\s+with|\s+in)?\s*:?\s*[xX*•.\-]*\s*(\d{4})\b|for\s+card\s+\d{4}[xX*•.\-]*(\d{4})\b""", I)
    private val merchantRx = Regex("""(?:\bat\b|@|\bto\b|\bfrom\b)\s*:?\s*([A-Za-z0-9][A-Za-z0-9 &.'*/\-]{1,40}?)(?=\s*(?:,|\.\s|\.$|\bon\b|\busing\b|\bvia\b|\bwith\b|\bref\b|\bavl\b|\bavailable\b|\bbal\b|\bdate\b|\bcard\b|\bfor\b|\b(?:AED|DHS?|USD|EUR|GBP|INR|SAR|QAR|KWD|BHD|OMR)\b|$))""", I)
    private val atLabel = Regex("""\bAt\s*:\s*(.+?)(?=\s+(?:Date|Amount|Available|Avl|Card|Time|Ref|Balance|AED|DHS?|USD|EUR|GBP|INR|SAR|QAR|KWD|BHD|OMR)\b|$)""", I)
    private val aggregator = Regex("""^(paymob|network\s*international|ngenius|telr|checkout\.com|stripe|paytabs|payfort|sq|paypal|amazon)\s*[*\-]+\s*""", I)
    private val refundRx = Regex("""refund|reversal|reversed""", I)
    private val badMerchant = Regex("""^(your|my|the|a/c|acct|account|card|ur|you|credit|debit)\b""", I)
    private val bill = Regex("""\b(due (?:on|by|date)|minimum (?:amount )?due|total (?:amount )?due|bill|invoice|statement|renew(?:s|al)?|subscription)""", I)
    private val subs = Regex("""\b(subscription|renew(?:s|al)?|auto-?renew|recurring)\b""", I)
    private val totalDue = Regex("""(?:total\s+(?:amount\s+)?due|amount\s+due|outstanding(?:\s+balance)?|bill\s+amount)[^0-9]{0,12}([\d,]+(?:\.\d{1,2})?)""", I)
    // Etisalat/e& bill format: “Total amount to pay before 15 NOV 2026: AED 450.45”.
    private val payableBefore = Regex("""total\s+amount\s+to\s+pay\s+before\s+\d{1,2}\s+[A-Za-z]{3,9}\s+\d{2,4}\s*:\s*(?:AED|DHS?)\s*([\d,]+(?:\.[\d]{1,2})?)""", I)
    // DEWA monthly bill: “Your October bill (...) for account XXXX is AED 609.54”.
    // Capture the bill total before the itemized electricity/water/housing amounts.
    private val dewaBillTotal = Regex("""\byour\s+[A-Za-z]+\s+bill\b.{0,180}?\bis\s*(?:AED|DHS?)\s*([\d,]+(?:\.[\d]{1,2})?)""", I)
    // Supports separated dates (25 Nov 2026) and compact bank formats (25NOV26).
    private val dueRx = Regex("""\b(?:due(?:\s+date)?(?:\s+(?:is|on|by))?|by|before)\s*:?\s*(\d{1,2}(?:[-/ ]+[A-Za-z]{3,9}[-/ ]+|[A-Za-z]{3,9})\d{2,4}|\d{1,2}[-/ ]+\d{1,2}[-/ ]+\d{2,4})""", I)
    private val billers = Regex("""\b(auto finance|dewa|dubai electricity|dubai water|addc|sewa|fewa|etisalat|e&|du|virgin mobile|salik|empower|netflix|spotify|shahid|osn|youtube|apple|google)\b""", I)
    private val dateFormats = listOf("dd-MMM-yyyy", "dd MMM yyyy", "dd/MM/yyyy", "dd-MM-yyyy", "dd MMMM yyyy", "dd-MMM-yy", "dd MMM yy", "dd/MM/yy", "ddMMMyy", "ddMMMyyyy")
    @Volatile private var customCats: List<Pair<String, Regex>> = emptyList()
    private data class SavedTransactionRule(val type: TxType, val category: String, val pattern: Regex)
    @Volatile private var savedTransactionRules: List<SavedTransactionRule> = emptyList()
    fun setCustomRules(raw: String) {
        customCats = raw.lineSequence().mapNotNull { line ->
            val category = line.substringBefore("=").trim(); val keywords = line.substringAfter("=", "").trim()
            if (category.isBlank() || keywords.isBlank()) null else runCatching { category to Regex(keywords, I) }.getOrNull()
        }.toList()
    }
    /** Learned rules are stored as TYPE<TAB>CATEGORY<TAB>REGEX, one rule per line. */
    fun setTransactionTypeRules(raw: String) {
        savedTransactionRules = raw.lineSequence().mapNotNull { line ->
            val parts = line.split('\t', limit = 3)
            if (parts.size != 3) return@mapNotNull null
            val type = runCatching { TxType.valueOf(parts[0].trim().uppercase()) }.getOrNull() ?: return@mapNotNull null
            val category = parts[1].trim().ifBlank { "Other" }
            val regex = runCatching { Regex(parts[2], I) }.getOrNull() ?: return@mapNotNull null
            SavedTransactionRule(type, category, regex)
        }.toList()
    }

    private val cats = listOf(
        "Grocery" to "carrefour|lulu|spinneys|choithram|union ?coop|waitrose|grocer|supermarket|hypermarket|farm fresh|viva|almaya",
        "Food" to "talabat|deliveroo|starbucks|mcdonald|kfc|burger|pizza|cafe|coffee|restaurant|bakery|shawarma|subway|domino|tim hortons|kitchen",
        "Transportation" to "uber|careem|rta|salik|\\bnol\\b|enoc|adnoc|eppco|emarat|taxi|parking|petrol|fuel|metro|darb",
        "Education" to "school|university|college|tuition|education|academy|nursery|bookshop",
        "Shopping" to "toys?\\b|amazon|noon|namshi|ikea|sharaf|jumbo|centrepoint|h&m|zara|shein|mall|ounass|apple\\.com|google play",
        "Bills & utilities" to "dewa|addc|sewa|fewa|etisalat|\\bdu\\b|virgin mobile|empower|district cooling|telecom|internet|utility|jio|prepaid recharge",
        "Entertainment" to "netflix|spotify|shahid|osn|disney|youtube|cinema|vox|reel|anghami|playstation|steam|xbox",
        "Health" to "pharmacy|clinic|hospital|medical|aster|nmc|medcare|dental|optic",
        "Travel" to "emirates|etihad|flydubai|air arabia|airline|booking\\.com|airbnb|hotel|agoda|expedia",
        "Cash" to "atm|cash withdrawal|cash wdl",
        "Fees & interest" to "\\bfee\\b|\\bvat\\b|interest|\\bcharges?\\b|penalty|annual"
    ).map { (n, p) -> n to Regex(p, I) }

    private fun amounts(t: String): List<Triple<Double, String, Int>> =
        (amtA.findAll(t).toList().ifEmpty { amtB.findAll(t).toList() }).map { m ->
            val a = m.groupValues[1]; val b = m.groupValues[2]
            val (num, cur) = if (a.first().isDigit()) a to b else b to a
            Triple(num.replace(",", "").toDoubleOrNull() ?: 0.0, cur.uppercase().let { if (it.startsWith("DH")) "AED" else if (it.startsWith("RS")) "INR" else it }, m.range.first)
        }.filter { it.first > 0 }

    private fun before(t: String, at: Int) = t.substring(maxOf(0, at - 28), at)
    private fun kindOf(t: String) = when {
        kCredit.containsMatchIn(t) -> "Credit card"; kDebit.containsMatchIn(t) -> "Debit card"
        kCard.containsMatchIn(t) -> "Card"; kAcct.containsMatchIn(t) -> "Account"; else -> null
    }
    private fun last4(t: String): String? {
        val a = last4a.find(t)
        if (a != null) return a.groupValues[1]
        val b = last4b.find(t) ?: return null
        return b.groupValues.drop(1).firstOrNull { it.isNotBlank() }
    }
    private fun tidy(s: String): String {
        val x = s.replace(Regex("\\s+"), " ").trim()
        return if (x == x.uppercase()) Regex("(^|[ \\-])([a-z])").replace(x.lowercase()) { it.groupValues[1] + it.groupValues[2].uppercase() } else x
    }
    private fun merchantOf(t: String): String? {
        val explicit = atLabel.find(t)?.groupValues?.get(1)
        val labelled = explicit?.let { sequenceOf(it) } ?: sequenceOf<String>()
        val candidates = labelled + merchantRx.findAll(t).map { it.groupValues[1] } + listOfNotNull(
            Regex("""(?i)\b(?:merchant|at|purchase at|spent at|paid to|payment to|pos)\s*[:#-]?\s*([A-Za-z0-9][A-Za-z0-9 &.'*/-]{1,40}?)(?=\s+(?:for|on|using|via|with|card|amount|aed|dhs?|usd|eur|gbp|inr|sar|date|time|ref|auth|available|balance)\b|[,;.]|$)""").find(t)?.groupValues?.get(1)
        ).asSequence()
        return candidates.map { aggregator.replace(it.trim().trimEnd('.', ',', '-', ' '), "") }
            .map { it.replace(Regex("\\s+"), " ").trim() }
            .firstOrNull { it.any(Char::isLetter) && !badMerchant.containsMatchIn(it) && !Regex("""(?i)^(?:AED|DHS?|USD|EUR|GBP|INR|SAR|QAR|KWD|BHD|OMR)\b""").containsMatchIn(it) }
            ?.let(::tidy)
    }

    private fun group(match: MatchResult?, vararg names: String): String? {
        if (match == null) return null
        return names.firstNotNullOfOrNull { n -> runCatching { match.groups[n]?.value?.takeIf { it.isNotBlank() } }.getOrNull() }
    }

    private fun dateTime(s: String?): Long? {
        if (s.isNullOrBlank()) return null
        val formats = listOf("yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy HH:mm", "dd-MM-yyyy HH:mm", "dd MMM yyyy HH:mm", "dd-MMM-yyyy HH:mm", "dd/MM/yy HH:mm", "dd-MM-yy HH:mm", "dd MMM yy HH:mm", "dd/MM/yyyy", "dd-MM-yy", "dd-MM-yyyy", "dd MMM yyyy", "dd-MMM-yyyy")
        return formats.firstNotNullOfOrNull { f -> runCatching { SimpleDateFormat(f, Locale.ENGLISH).apply { isLenient = false }.parse(s.trim())?.time }.getOrNull() }
    }

    private fun categorize(merchant: String?, text: String, type: TxType, cardPayment: Boolean): String {
        if (cardPayment) return "Card payment"
        if (type == TxType.DEBIT && Regex("""(?i)\b(?:emi|loan installment|loan repayment|monthly installment|instalment)\b""").containsMatchIn(text)) return "EMI / Loan repayment"
        // ATM/cash withdrawals move funds from a bank account into the cash wallet; they are not an expense.
        if (type == TxType.DEBIT && Regex("""(?i)\b(?:cash withdrawal|atm withdrawal|withdrawn cash|cash withdrawn|atm cash)\b""").containsMatchIn(text)) return "Cash withdrawal"
        if (Regex("""(?i)telegraphic transfer|\btransfer(?:red)?\b""").containsMatchIn(text)) return "Transfers"
        if (Regex("""(?i)\bDDR[- ]""").containsMatchIn(text)) return "Direct debit"
        if (type == TxType.CREDIT) return if (Regex("salary", I).containsMatchIn(text)) "Salary" else if (Regex("refund|reversal|cashback", I).containsMatchIn(text)) "Refund" else "Income"
        val hay = listOfNotNull(merchant, text).joinToString(" ")
        return customCats.firstOrNull { it.second.containsMatchIn(hay) }?.first ?: cats.firstOrNull { it.second.containsMatchIn(hay) }?.first ?: "Unknown"
    }

    /** strict = notification input. Accept transaction-like wording even when banks omit account digits. */
    fun parse(text: String, strict: Boolean = false): Parsed? {
        val t = text.replace(Regex("\\s+"), " ").trim()
        val recognisedBillerBill = bill.containsMatchIn(t) && billers.containsMatchIn(t)
        if (skip.containsMatchIn(t) && !recognisedBillerBill) return null
        if (marketing.containsMatchIn(t) && !postedCredit.containsMatchIn(t) && !recognisedBillerBill) return null
        val acct = last4(t); val kind = kindOf(t)
        // Balance alerts are account snapshots, not spending transactions. Keep the available
        // amount out of the transaction ledger and expose it to account-balance storage instead.
        if (Regex("(?i)\\bavailable\\s+(?:a/c\\s+)?bal(?:ance)?\\b").containsMatchIn(t) &&
            Regex("(?i)\\b(?:as\\s+on|as\\s+of)\\b").containsMatchIn(t)) {
            val amountMatch = Regex("(?i)\\b(INR|AED|DHS?|USD|EUR|GBP|SAR|QAR|KWD|BHD|OMR)\\s*([\\d,]+(?:\\.\\d{1,2})?)").find(t)
            val amount = amountMatch?.groupValues?.get(2)?.replace(",", "")?.toDoubleOrNull()
            val currency = amountMatch?.groupValues?.get(1)?.uppercase()?.let { if (it.startsWith("DH")) "AED" else it }
            val bank = when {
                Regex("(?i)HDFC\\s*Bank|HDFCBK|HDFCBANK").containsMatchIn(t) -> "HDFC Bank"
                Regex("(?i)Emirates\\s*NBD|ENBDX|ENBD").containsMatchIn(t) -> "Emirates NBD"
                else -> Regex("(?i)\\b([A-Za-z][A-Za-z &]+?\\s+Bank)\\b").find(t)?.groupValues?.get(1)?.trim() ?: "Bank"
            }
            if (amount != null && amount >= 0 && currency != null) return Parsed.BalanceInfo(bank, acct, currency, amount)
        }
        val dueMs = dueRx.find(t)?.groupValues?.get(1)?.let(::parseDate)

        if (bill.containsMatchIn(t) && (t.contains("due", true) || billers.containsMatchIn(t) || subs.containsMatchIn(t))) {
            if (strict && dueMs == null && !billers.containsMatchIn(t) && !subs.containsMatchIn(t)) return null
            val all = amounts(t)
            val amt = payableBefore.find(t)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull()
                ?: (if (Regex("\\bdewa\\b", I).containsMatchIn(t)) dewaBillTotal.find(t)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() else null)
                ?: totalDue.find(t)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull()
                ?: all.firstOrNull { !minRx.containsMatchIn(before(t, it.third)) }?.first ?: all.firstOrNull()?.first
            val biller = billers.find(t)?.value?.let(::tidy)
            val stmt = t.contains("statement", true) || Regex("\\bstmt\\b", I).containsMatchIn(t)
            val title = when {
                biller != null -> biller + if (stmt) " statement" else " bill"
                acct != null && stmt && Regex("\\bADIB\\b", I).containsMatchIn(t) -> "ADIB Covered card ••$acct statement"
                acct != null && stmt -> "${kind ?: "Card"} ••$acct statement"
                else -> merchantOf(t) ?: t.take(40)
            }
            if (amt == null && dueMs == null) return null
            return Parsed.BillInfo(title, amt, all.firstOrNull()?.second, dueMs, subs.containsMatchIn(t))
        }

        // Match a user-approved generic rule first. Named capture groups are optional; when present,
        // they provide structured fields while the built-in parser fills any missing values.
        val learned = savedTransactionRules.firstOrNull { rule -> runCatching { rule.pattern.containsMatchIn(t) }.getOrDefault(false) }
        val learnedMatch = learned?.pattern?.find(t)
        val capturedAmount = group(learnedMatch, "amount", "amt", "value", "transactionAmount")?.replace(",", "")?.toDoubleOrNull()?.takeIf { it > 0 }
        val capturedCurrency = group(learnedMatch, "currency", "cur")?.uppercase()?.let { if (it.startsWith("DH")) "AED" else if (it.startsWith("RS") || it == "₹") "INR" else it }
        val amountHit = amounts(t).firstOrNull { !ctxBad.containsMatchIn(before(t, it.third)) }
        val amountValue = capturedAmount ?: amountHit?.first
        if (amountValue == null) return null
        val amountCurrency = capturedCurrency ?: amountHit?.second ?: "AED"
        val capturedCard = group(learnedMatch, "card", "account", "last4", "cardNumber")?.filter(Char::isDigit)?.takeLast(4)?.takeIf { it.length == 4 }
        val accountValue = capturedCard ?: acct
        val capturedMerchant = group(learnedMatch, "merchant", "payee", "description", "merchantName")?.trim()?.takeIf { it.any(Char::isLetter) }
        val merchantValue = capturedMerchant ?: merchantOf(t) ?: when {
            Regex("""(?i)telegraphic transfer""").containsMatchIn(t) -> "Telegraphic Transfer"
            Regex("""(?i)\bDDR[- ]""").containsMatchIn(t) -> "Direct Debit"
            Regex("""(?i)cash withdrawal""").containsMatchIn(t) -> "Cash Withdrawal"
            cardPay.containsMatchIn(t) -> "Credit Card Payment"
            else -> null
        }
        val capturedDate = group(learnedMatch, "datetime", "date_time", "transactionDate", "dateTime", "date", "time")
        val transactionTime = dateTime(capturedDate)
            ?: Regex("""\b(?:\d{4}-\d{2}-\d{2}|\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}|\d{1,2}\s+[A-Za-z]{3,9}\s+\d{2,4})\s+\d{1,2}:\d{2}(?::\d{2})?\b""").find(t)?.value?.let(::dateTime)
            ?: Regex("""\b(?:\d{4}-\d{2}-\d{2}|\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}|\d{1,2}\s+[A-Za-z]{3,9}\s+\d{2,4})\b""").find(t)?.value?.let(::dateTime)
        // Many bank apps redact account digits in notifications. In strict mode, accept only
        // explicit transaction language (or salary/payroll) when no account/balance marker exists.
        // Promotional wording and OTP/declined messages have already been filtered above.
        val strongTxSignal = debit.containsMatchIn(t) || credit.containsMatchIn(t) ||
            Regex("\\bsalary\\b|payroll|credited into your account|deducted from your account", I).containsMatchIn(t) || cardPay.containsMatchIn(t)
        if (strict && accountValue == null && !balRx.containsMatchIn(t) && !strongTxSignal && learned == null) return null
        val cardPayment = cardPay.containsMatchIn(t)
        val d = debit.find(t)?.range?.first ?: Int.MAX_VALUE
        val c = credit.find(t)?.range?.first ?: Int.MAX_VALUE
        val type = when {
            cardPayment -> TxType.DEBIT
            Regex("\\bsalary\\b|salary credited|payroll credited|monthly salary", I).containsMatchIn(t) -> TxType.CREDIT
            c == Int.MAX_VALUE && d == Int.MAX_VALUE -> learned?.type ?: return null
            cardPayment && c != Int.MAX_VALUE -> TxType.CREDIT
            refundRx.containsMatchIn(t) -> TxType.CREDIT
            c < d -> TxType.CREDIT
            else -> TxType.DEBIT
        }
        val finalType = learned?.type ?: type
        val finalCategory = learned?.category ?: categorize(merchantValue, t, finalType, cardPayment)
        return Parsed.Tx(amountValue, amountCurrency, finalType, merchantValue, accountValue, kind ?: if (capturedCard != null) "Card" else null, finalCategory, transactionTime)
    }

    private fun parseDate(s: String): Long? = dateFormats.firstNotNullOfOrNull { f ->
        runCatching { SimpleDateFormat(f, Locale.ENGLISH).apply { isLenient = false }.parse(s.trim())?.time }.getOrNull()
            ?.takeIf { it > 946_684_800_000L }
    }
}
