package com.example.moneytracker

import android.content.Context
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.util.Locale

/** Fetches and caches a money/finance-themed quote from ZenQuotes.io once per day, with an offline fallback. */
object QuoteService {
    private const val ENDPOINT = "https://zenquotes.io/api/quotes"
    private const val FALLBACK = "Beware of little expenses; a small leak will sink a great ship. — Benjamin Franklin"
    private val financeWords = listOf("money", "wealth", "rich", "finance", "financial", "invest", "saving", "save", "spend", "capital", "dollar", "fortune", "debt", "budget", "business", "value")

    fun daily(ctx: Context): String {
        val day = LocalDate.now().toString()
        Prefs.cachedQuote(ctx, day)?.takeIf { it.isNotBlank() }?.let { return it }
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4500
                readTimeout = 4500
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "MoneyTracker-Android/1.0")
            }
            if (connection.responseCode !in 200..299) throw IllegalStateException("Quote service returned ${connection.responseCode}")
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val array = JSONArray(body)
            val relevant = (0 until array.length()).mapNotNull { array.optJSONObject(it) }
                .firstOrNull { obj ->
                    val q = obj.optString("q").lowercase(Locale.ROOT)
                    financeWords.any { word -> Regex("\\b${Regex.escape(word)}\\b", RegexOption.IGNORE_CASE).containsMatchIn(q) }
                } ?: array.optJSONObject(0) ?: throw IllegalStateException("No quote returned")
            val quote = relevant.optString("q").trim()
            val author = relevant.optString("a").trim().ifBlank { "Unknown" }
            if (quote.isBlank()) throw IllegalStateException("Empty quote")
            val value = "“$quote” — $author"
            Prefs.saveCachedQuote(ctx, day, value)
            value
        } catch (_: Throwable) {
            Prefs.cachedQuote(ctx, day)?.takeIf { it.isNotBlank() } ?: FALLBACK
        } finally {
            connection?.disconnect()
        }
    }
}
