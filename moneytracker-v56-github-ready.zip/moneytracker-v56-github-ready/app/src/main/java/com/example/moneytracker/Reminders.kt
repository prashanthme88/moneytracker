package com.example.moneytracker

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import com.example.moneytracker.data.*
import java.time.*
import java.util.concurrent.TimeUnit

object NotificationNavigation {
    const val EXTRA_TARGET_TAB = "target_tab"
    const val TAB_HOME = 0
    const val TAB_TRANSACTIONS = 1
    const val TAB_BILLS = 2

    fun pendingIntent(context: Context, targetTab: Int, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_TARGET_TAB, targetTab)
        }
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}

/** Daily spending summary at the time selected in Settings. Clicking opens Transactions. */
class ReminderWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    @SuppressLint("MissingPermission")
    override suspend fun doWork(): Result {
        val context = applicationContext
        val db = AppDb.get(context)
        val nm = NotificationManagerCompat.from(context)
        val systemManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        systemManager.createNotificationChannel(NotificationChannel("daily-summary", "Daily money summary", NotificationManager.IMPORTANCE_DEFAULT))

        if (Prefs.dailyReminderEnabled(context)) {
            val zone = ZoneId.systemDefault()
            val start = LocalDate.now(zone).atStartOfDay(zone).toInstant().toEpochMilli()
            val now = System.currentTimeMillis()
            val today = db.tx().between(start, now)
            val spend = today.filter { it.type == TxType.DEBIT && it.counts() }
            val mainCurrency = Prefs.mainCurrency(context)
            val knownTotal = spend.sumOf { tx ->
                (ExchangeRates.cachedRate(tx.currency, mainCurrency) ?: if (tx.currency.equals(mainCurrency, true)) 1.0 else 0.0) * tx.amount
            }
            val unknownTotals = spend.filter { tx -> !tx.currency.equals(mainCurrency, true) && ExchangeRates.cachedRate(tx.currency, mainCurrency) == null }
                .groupBy { it.currency.uppercase() }.mapValues { (_, rows) -> rows.sumOf { it.amount } }
            val title: String
            val body: String
            if (today.isEmpty()) {
                title = "Your daily money check-in"
                body = "No transactions recorded today. Open MoneyTracker and add a transaction to keep your summary accurate."
            } else if (spend.isEmpty()) {
                title = "No expenses recorded today"
                body = "You have ${today.count { it.type == TxType.CREDIT && it.counts() }} income transaction(s) recorded today."
            } else {
                val extraText = if (unknownTotals.isEmpty()) "" else " · Also recorded: " + unknownTotals.entries.joinToString(", ") { (currency, value) -> "$currency ${"%,.2f".format(value)}" }
                title = if (unknownTotals.isEmpty()) "Today's spending: $mainCurrency ${"%,.2f".format(knownTotal)}" else "Today's spending summary"
                body = "${spend.size} expense transaction(s). $mainCurrency ${"%,.2f".format(knownTotal)} converted total$extraText"
            }
            val contentIntent = NotificationNavigation.pendingIntent(context, NotificationNavigation.TAB_TRANSACTIONS, 2001)
            nm.notify(2, NotificationCompat.Builder(context, "daily-summary")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .build())
        }
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val work = WorkManager.getInstance(ctx)
            if (!Prefs.dailyReminderEnabled(ctx)) {
                work.cancelUniqueWork("daily-money-reminders")
            } else {
                val zone = ZoneId.systemDefault()
                val now = ZonedDateTime.now(zone)
                var target = now.toLocalDate().atTime(Prefs.dailyReminderHour(ctx), Prefs.dailyReminderMinute(ctx)).atZone(zone)
                if (!target.isAfter(now)) target = target.plusDays(1)
                val delay = Duration.between(now, target).toMillis().coerceAtLeast(1_000L)
                val request = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS)
                    .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                    .build()
                work.enqueueUniquePeriodicWork("daily-money-reminders", ExistingPeriodicWorkPolicy.UPDATE, request)
            }
            BillReminderWorker.schedule(ctx)
        }
    }
}

/** Morning reminder for bills pending within 3 days (or overdue). Clicking opens the Bills section. */
class BillReminderWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    @SuppressLint("MissingPermission")
    override suspend fun doWork(): Result {
        val context = applicationContext
        if (!Prefs.billReminderEnabled(context)) return Result.success()
        val db = AppDb.get(context)
        val nm = NotificationManagerCompat.from(context)
        val systemManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        systemManager.createNotificationChannel(NotificationChannel("bills", "Bill reminders", NotificationManager.IMPORTANCE_DEFAULT))

        val soon = db.bills().pendingNow()
            .filter { (it.daysLeft() ?: Int.MAX_VALUE) <= 3 }
            .sortedBy { it.daysLeft() }
        if (soon.isNotEmpty()) {
            val lines = soon.map { b ->
                val d = b.daysLeft() ?: 0
                val whenText = when { d < 0 -> "overdue by ${-d}d"; d == 0 -> "due today"; else -> "in ${d}d" }
                "${b.title}: ${b.currency ?: ""} ${b.amount?.let { "%,.2f".format(it) } ?: ""} ($whenText)".replace(Regex("\\s+"), " ").trim()
            }
            val summaryText = lines.joinToString("\n")
            val contentIntent = NotificationNavigation.pendingIntent(context, NotificationNavigation.TAB_BILLS, 2002)
            nm.notify(1, NotificationCompat.Builder(context, "bills")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("${soon.size} pending bill(s) due within 3 days")
                .setContentText(lines.first())
                .setStyle(NotificationCompat.InboxStyle().also { style -> lines.forEach(style::addLine) }.setBigContentTitle("${soon.size} pending bill(s) need attention").setSummaryText(summaryText.take(60)))
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .build())
        }
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val work = WorkManager.getInstance(ctx)
            if (!Prefs.billReminderEnabled(ctx)) {
                work.cancelUniqueWork("morning-bill-reminders")
                return
            }
            val zone = ZoneId.systemDefault()
            val now = ZonedDateTime.now(zone)
            var target = now.toLocalDate().atTime(Prefs.billReminderHour(ctx), Prefs.billReminderMinute(ctx)).atZone(zone)
            if (!target.isAfter(now)) target = target.plusDays(1)
            val delay = Duration.between(now, target).toMillis().coerceAtLeast(1_000L)
            val request = PeriodicWorkRequestBuilder<BillReminderWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .build()
            work.enqueueUniquePeriodicWork("morning-bill-reminders", ExistingPeriodicWorkPolicy.UPDATE, request)
        }
    }
}
