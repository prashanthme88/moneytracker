package com.example.moneytracker

import android.content.Context
import com.example.moneytracker.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToLong

/** Cleanup and reconciliation run at app startup and after an SMS inbox refresh. */
object TransactionMaintenance {
    private const val DUPLICATE_WINDOW_MS = 6 * 60 * 1000L
    private val mutex = Mutex()

    suspend fun run(context: Context): Pair<Int, Int> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val db = AppDb.get(context.applicationContext)
            val removed = deduplicate(db)
            deduplicateBills(db)
            val paid = markMatchingPastCardBillsPaid(db)
            removed to paid
        }
    }

    private suspend fun deduplicate(db: AppDb): Int {
        val rows = db.tx().all().filterNot { it.bank.equals("Manual", true) }
        if (rows.size < 2) return 0

        val buckets = HashMap<String, MutableList<Txn>>()
        val survivors = mutableListOf<Txn>()
        val deleteIds = linkedSetOf<Long>()
        val updates = linkedMapOf<Long, Txn>()

        for (row in rows) {
            val core = "${(row.amount * 1000.0).roundToLong()}|${row.currency.uppercase(Locale.ROOT)}|${row.type.name}"
            val candidates = buckets.getOrPut(core) { mutableListOf() }
            val matchIndex = candidates.indexOfFirst { old ->
                abs(old.timestamp - row.timestamp) <= DUPLICATE_WINDOW_MS && sameTransaction(old, row)
            }
            if (matchIndex < 0) {
                candidates += row
                survivors += row
            } else {
                val old = candidates[matchIndex]
                val preferred = if (quality(row) > quality(old)) row else old
                val other = if (preferred.id == row.id) old else row
                deleteIds += other.id
                val merged = preferred.copy(
                    account = preferred.account ?: other.account,
                    kind = preferred.kind ?: other.kind,
                    merchant = preferred.merchant ?: other.merchant,
                    category = if (preferred.category == "Other" && other.category != "Other") other.category else preferred.category,
                    rawText = if (other.rawText.length > preferred.rawText.length) other.rawText else preferred.rawText
                )
                candidates[matchIndex] = merged
                val survivorIndex = survivors.indexOfFirst { it.id == old.id || it.id == row.id }
                if (survivorIndex >= 0) survivors[survivorIndex] = merged
                updates[merged.id] = merged
                updates.remove(other.id)
            }
        }

        if (deleteIds.isNotEmpty()) db.tx().deleteByIds(deleteIds.toList())
        updates.values.filterNot { it.id in deleteIds }.forEach { db.tx().update(it) }
        return deleteIds.size
    }

    private fun sameTransaction(a: Txn, b: Txn): Boolean {
        val aa = a.account?.filter(Char::isDigit)?.takeLast(4)
        val ba = b.account?.filter(Char::isDigit)?.takeLast(4)
        val am = normalize(a.merchant.orEmpty())
        val bm = normalize(b.merchant.orEmpty())
        val ar = normalize(a.rawText)
        val br = normalize(b.rawText)
        val sameRaw = ar.isNotBlank() && br.isNotBlank() && (ar == br || ar.contains(br) || br.contains(ar))

        // Same account is useful evidence, but not enough by itself: people can make two
        // same-value purchases with one card in a short period. Also require a merchant or
        // source-message match before removing a row.
        if (!aa.isNullOrBlank() && !ba.isNullOrBlank()) {
            if (aa != ba) return false
            if (am.isNotBlank() && bm.isNotBlank()) {
                return (am == bm && a.category.equals(b.category, true)) || sameRaw
            }
            return sameRaw
        }

        if (am.isNotBlank() && bm.isNotBlank() && am == bm) return a.category.equals(b.category, true)
        // Only use raw text as a fallback when the source message is effectively the same.
        return sameRaw
    }

    private fun normalize(value: String): String = value.lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9]"), "")

    private fun quality(t: Txn): Int =
        (if (!t.account.isNullOrBlank()) 8 else 0) +
        (if (!t.kind.isNullOrBlank()) 3 else 0) +
        (if (!t.merchant.isNullOrBlank()) 2 else 0) +
        (if (t.category != "Other") 1 else 0) +
        t.rawText.length.coerceAtMost(500) / 100

    private suspend fun deduplicateBills(db: AppDb): Int {
        val all = db.bills().all()
        if (all.size < 2) return 0
        val kept = mutableListOf<Bill>()
        val deleteIds = mutableListOf<Long>()
        for (bill in all.sortedWith(compareBy<Bill> { if (it.status == "PAID") 0 else if (it.status == "PENDING") 1 else 2 }.thenBy { it.id })) {
            if (BillPayments.isDuplicateBill(kept, bill)) {
                deleteIds += bill.id
            } else {
                kept += bill
            }
        }
        if (deleteIds.isNotEmpty()) db.bills().deleteByIds(deleteIds)
        return deleteIds.size
    }

    private suspend fun markMatchingPastCardBillsPaid(db: AppDb): Int {
        val allBills = db.bills().all()
        val bills = allBills.filter {
            it.status == "PENDING" && (it.amount ?: 0.0) > 0.0
        }
        if (bills.isEmpty()) return 0
        val txs = db.tx().all()
        val used = allBills.filter { it.status == "PAID" }.mapNotNull { it.paymentTxnId }.toMutableSet()
        var marked = 0
        for (bill in bills) {
            val matched = BillPayments.findMatchingPayment(bill, txs, used) ?: continue
            db.bills().setPaymentStatus(bill.id, "PAID", matched.timestamp, matched.id, matched.rawText, matched.bank, matched.sourceType)
            used += matched.id
            marked++
        }
        return marked
    }

}