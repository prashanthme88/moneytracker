package com.example.moneytracker

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Fetches a recent reference-rate table. Rates are indicative, not bank/card settlement rates. */
object ExchangeRates {
    @Volatile private var rates: Map<String, Double> = emptyMap()
    @Volatile var updatedAt: Long = 0L
        private set

    fun cachedRate(from: String, to: String): Double? {
        val a = from.uppercase(); val b = to.uppercase()
        if (a == b) return 1.0
        val r = rates
        val baseToA = r[a] ?: return null
        val baseToB = r[b] ?: return null
        return baseToB / baseToA
    }

    fun refresh(): Boolean = try {
        val connection = (URL("https://open.er-api.com/v6/latest/USD").openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000; readTimeout = 8000; requestMethod = "GET"
        }
        try {
            val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            if (json.optString("result") != "success") {
                false
            } else {
                val obj = json.getJSONObject("rates")
                val map = mutableMapOf("USD" to 1.0)
                obj.keys().forEach { key ->
                    val value = obj.optDouble(key, Double.NaN)
                    if (value.isFinite() && value > 0) map[key.uppercase()] = value
                }
                rates = map
                updatedAt = System.currentTimeMillis()
                true
            }
        } finally { connection.disconnect() }
    } catch (_: Throwable) { false }
}
