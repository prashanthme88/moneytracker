package com.example.moneytracker

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.InsertChart
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.moneytracker.data.*
import java.util.Locale
import kotlin.math.abs

val chartTypeOptions = listOf(
    "Line Chart", "Column Chart", "Bar Chart", "Waterfall Chart", "Pie Chart", "Donut Chart",
    "Area Chart", "Stacked Column Chart", "Stacked Bar Chart", "Scatter Plot", "Combo Chart",
    "Bullet Chart", "Gauge / Speedometer Chart", "OHLC Bar Chart", "Candlestick Chart", "Heikin-Ashi Chart"
)

@Composable fun ChartTypeSelector(selected: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
            Icon(Icons.Default.InsertChart, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(selected, maxLines = 1)
            Spacer(Modifier.width(4.dp))
            Icon(Icons.Default.ArrowDropDown, contentDescription = "Choose chart type", modifier = Modifier.size(18.dp))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, modifier = Modifier.heightIn(max = 440.dp)) {
            chartTypeOptions.forEach { type ->
                DropdownMenuItem(text = { Text(type) }, leadingIcon = {
                    if (type == selected) Icon(Icons.Default.Check, contentDescription = null)
                }, onClick = { expanded = false; onSelect(type) })
            }
        }
    }
}

private data class CategorySpend(
    val label: String,
    val amount: Double,
    val txAmounts: List<Double>
)

/** Every chart visualizes expense categories for the transaction period supplied by the caller (default: this month). */
@Composable fun FinanceChart(transactions: List<Txn>, chartType: String, budget: Double?, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val spendTx = remember(transactions) { transactions.filter { it.type == TxType.DEBIT && it.counts() }.sortedBy { it.timestamp } }
    val categoryData = remember(spendTx) {
        val all = spendTx.groupBy { it.category.ifBlank { "Other" } }
            .map { (name, rows) -> CategorySpend(name, rows.sumOf { it.amount }, rows.map { it.amount }) }
            .sortedByDescending { it.amount }
        if (all.size <= 8) all else {
            all.take(7) + CategorySpend("Other categories", all.drop(7).sumOf { it.amount }, all.drop(7).flatMap { it.txAmounts })
        }
    }
    val categories = categoryData.map { it.label }
    val amounts = categoryData.map { it.amount }
    val totalSpend = spendTx.sumOf { it.amount }
    val incomeByCategory = remember(transactions, categories) {
        val credits = transactions.filter { it.type == TxType.CREDIT && it.counts() }
        categories.map { category ->
            if (category == "Other categories") credits.filter { it.category !in categories }.sumOf { it.amount }
            else credits.filter { (it.category.ifBlank { "Other" }) == category }.sumOf { it.amount }
        }
    }
    val isBudgetChart = chartType == "Bullet Chart" || chartType == "Gauge / Speedometer Chart"
    if (isBudgetChart && (budget == null || budget <= 0.0)) {
        Column(modifier.fillMaxWidth().height(156.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(Icons.Default.Savings, contentDescription = null, tint = cs.primary, modifier = Modifier.size(32.dp))
            Text("Set a monthly budget to use this chart", style = MaterialTheme.typography.bodyMedium)
        }
        return
    }
    if (spendTx.isEmpty()) {
        Box(modifier.fillMaxWidth().height(156.dp), contentAlignment = Alignment.Center) { Text("No expenses in this period yet", color = cs.onSurfaceVariant) }
        return
    }
    val colors = listOf(Color(0xFF00A896), Color(0xFF5E60CE), Color(0xFFFF9F1C), Color(0xFFE84855), Color(0xFF3A86FF), Color(0xFFB5179E), Color(0xFF2EC4B6), Color(0xFF8338EC), Color(0xFFFB5607), Color(0xFF43AA8B))
    val primary = Color(0xFF5E60CE)
    val secondary = Color(0xFFFF9F1C)
    val txAmounts = remember(spendTx) { spendTx.takeLast(140) }
    val incomeMax = incomeByCategory.maxOrNull() ?: 0.0
    val maxValue = maxOf(amounts.maxOrNull() ?: 0.0, incomeMax, 1.0)
    val safeTotal = totalSpend.coerceAtLeast(1.0)
    val chartReveal by animateFloatAsState(targetValue = 1f, animationSpec = tween(durationMillis = 850), label = "chartReveal")
    val animatedAmounts = amounts.map { it * chartReveal }
    val animatedIncome = incomeByCategory.map { it * chartReveal }
    val animatedTotal = totalSpend * chartReveal

    Canvas(modifier.fillMaxWidth().height(if (chartType.contains("Gauge")) 160.dp else 184.dp)) {
        val w = size.width
        val h = size.height
        val padX = 12.dp.toPx()
        val padTop = 12.dp.toPx()
        val padBottom = 10.dp.toPx()
        val chartH = (h - padTop - padBottom).coerceAtLeast(1f)
        val chartW = (w - 2 * padX).coerceAtLeast(1f)
        val count = categories.size.coerceAtLeast(1)
        fun xAt(i: Int, n: Int = count): Float = padX + chartW * (i + 0.5f) / n
        fun yAt(value: Double, max: Double = maxValue): Float = padTop + chartH - (value / max.coerceAtLeast(1.0)).toFloat().coerceIn(0f, 1f) * chartH
        fun line(values: List<Double>, max: Double, color: Color, width: Float = 3.dp.toPx()) {
            if (values.size == 1) {
                drawCircle(color, 4.dp.toPx(), Offset(xAt(0), yAt(values.first(), max)))
                return
            }
            if (values.size < 2) return
            val path = Path()
            values.forEachIndexed { i, v -> if (i == 0) path.moveTo(xAt(i), yAt(v, max)) else path.lineTo(xAt(i), yAt(v, max)) }
            drawPath(path, color, style = Stroke(width))
            values.forEachIndexed { i, v -> drawCircle(color, radius = 3.dp.toPx(), center = Offset(xAt(i), yAt(v, max))) }
        }
        when (chartType) {
            "Line Chart" -> line(animatedAmounts, maxValue, primary)
            "Area Chart" -> {
                val path = Path(); path.moveTo(xAt(0), padTop + chartH)
                animatedAmounts.forEachIndexed { i, v -> path.lineTo(xAt(i), yAt(v)) }
                path.lineTo(xAt(animatedAmounts.lastIndex), padTop + chartH); path.close()
                drawPath(path, primary.copy(alpha = 0.22f))
                line(animatedAmounts, maxValue, primary)
            }
            "Column Chart" -> animatedAmounts.forEachIndexed { i, value ->
                val bw = chartW / (count * 1.8f); val top = yAt(value)
                drawRoundRect(primary, Offset(xAt(i) - bw / 2, top), Size(bw, (padTop + chartH - top).coerceAtLeast(2f)), cornerRadius = CornerRadius(5.dp.toPx()))
            }
            "Bar Chart" -> {
                val bh = chartH / (count * 1.7f)
                animatedAmounts.forEachIndexed { i, value -> drawRoundRect(colors[i % colors.size], Offset(padX, padTop + chartH * i / count + bh / 2), Size((chartW * (value / maxValue).toFloat()).coerceAtLeast(2f), bh), cornerRadius = CornerRadius(4.dp.toPx())) }
            }
            "Waterfall Chart" -> {
                val cumulative = animatedAmounts.runningFold(0.0) { a, b -> a + b }.drop(1)
                val mx = (cumulative.maxOrNull() ?: 1.0).coerceAtLeast(1.0)
                val bw = chartW / (count * 1.8f)
                animatedAmounts.forEachIndexed { i, value ->
                    val previous = if (i == 0) 0.0 else cumulative[i - 1]
                    val top = yAt(cumulative[i], mx); val bottom = yAt(previous, mx)
                    drawRect(colors[i % colors.size], Offset(xAt(i) - bw / 2, top), Size(bw, (bottom - top).coerceAtLeast(2f)))
                }
            }
            "Pie Chart", "Donut Chart" -> {
                var angle = -90f
                val diameter = minOf(h - 4.dp.toPx(), w * 0.58f).coerceAtLeast(20f)
                val top = (h - diameter) / 2
                animatedAmounts.forEachIndexed { i, value ->
                    val sweep = (value / safeTotal * 360.0).toFloat()
                    drawArc(colors[i % colors.size], angle, sweep, chartType == "Pie Chart", topLeft = Offset((w - diameter) / 2, top), size = Size(diameter, diameter), style = if (chartType == "Donut Chart") Stroke(26.dp.toPx()) else androidx.compose.ui.graphics.drawscope.Fill)
                    angle += sweep
                }
            }
            "Stacked Column Chart" -> {
                val bw = chartW * 0.34f
                var bottom = padTop + chartH
                animatedAmounts.forEachIndexed { i, value ->
                    val bh = (value / safeTotal).toFloat() * chartH
                    bottom -= bh
                    drawRect(colors[i % colors.size], Offset((w - bw) / 2, bottom), Size(bw, bh.coerceAtLeast(0f)))
                }
            }
            "Stacked Bar Chart" -> {
                var left = padX
                animatedAmounts.forEachIndexed { i, value ->
                    val bw = chartW * (value / safeTotal).toFloat()
                    drawRect(colors[i % colors.size], Offset(left, padTop + chartH * 0.34f), Size(bw, chartH * 0.32f))
                    left += bw
                }
            }
            "Scatter Plot" -> {
                val maxAmount = (txAmounts.maxOfOrNull { it.amount } ?: 1.0).coerceAtLeast(1.0)
                val from = txAmounts.firstOrNull()?.timestamp ?: 0L
                val to = txAmounts.lastOrNull()?.timestamp ?: from + 1L
                txAmounts.forEachIndexed { i, tx ->
                    val txCatIndex = categories.indexOf(tx.category.ifBlank { "Other" }).let { if (it < 0) categories.lastIndex.coerceAtLeast(0) else it }
                    val x = if (to == from) xAt(i, txAmounts.size.coerceAtLeast(1)) else padX + chartW * ((tx.timestamp - from).toFloat() / (to - from))
                    drawCircle(colors[txCatIndex % colors.size], 4.dp.toPx(), Offset(x, yAt(tx.amount, maxAmount)))
                }
            }
            "Combo Chart" -> {
                val bw = chartW / (count * 2.2f)
                animatedAmounts.forEachIndexed { i, value -> val top = yAt(value); drawRect(primary.copy(alpha = 0.7f), Offset(xAt(i) - bw / 2, top), Size(bw, (padTop + chartH - top).coerceAtLeast(2f))) }
                line(animatedIncome, maxValue, secondary)
            }
            "Bullet Chart" -> {
                val target = budget!!.coerceAtLeast(1.0)
                drawRoundRect(cs.surfaceVariant, Offset(padX, h * 0.35f), Size(chartW, h * 0.32f), cornerRadius = CornerRadius(8.dp.toPx()))
                drawRoundRect(if (totalSpend > target) cs.error else primary, Offset(padX, h * 0.35f), Size(chartW * (animatedTotal / target).toFloat().coerceAtMost(1.35f), h * 0.32f), cornerRadius = CornerRadius(8.dp.toPx()))
                drawRect(cs.onSurface.copy(alpha = 0.7f), Offset(padX + chartW, h * 0.25f), Size(2.dp.toPx(), h * 0.52f))
            }
            "Gauge / Speedometer Chart" -> {
                val target = budget!!.coerceAtLeast(1.0); val ratio = (animatedTotal / target).toFloat().coerceIn(0f, 1f)
                val diameter = minOf(w * 0.62f, h * 1.55f); val left = (w - diameter) / 2; val top = h * 0.12f
                drawArc(cs.surfaceVariant, 180f, 180f, false, Offset(left, top), Size(diameter, diameter), style = Stroke(20.dp.toPx()))
                drawArc(if (totalSpend > target) cs.error else primary, 180f, 180f * ratio, false, Offset(left, top), Size(diameter, diameter), style = Stroke(20.dp.toPx()))
            }
            "OHLC Bar Chart", "Candlestick Chart", "Heikin-Ashi Chart" -> {
                val records = categoryData.map { category ->
                    val values = category.txAmounts
                    val open = values.firstOrNull() ?: 0.0; val close = values.lastOrNull() ?: 0.0
                    val high = values.maxOrNull() ?: 0.0; val low = values.minOrNull() ?: 0.0
                    doubleArrayOf(open, maxOf(high, open, close), minOf(low, open, close), close)
                }.let { raw ->
                    if (chartType != "Heikin-Ashi Chart") raw else {
                        var prevOpen = 0.0; var prevClose = 0.0
                        raw.mapIndexed { i, r ->
                            val haClose = (r[0] + r[1] + r[2] + r[3]) / 4.0
                            val haOpen = if (i == 0) (r[0] + r[3]) / 2.0 else (prevOpen + prevClose) / 2.0
                            prevOpen = haOpen; prevClose = haClose
                            doubleArrayOf(haOpen, maxOf(r[1], haOpen, haClose), minOf(r[2], haOpen, haClose), haClose)
                        }
                    }
                }
                val maxRecord = (records.flatMap { it.toList() }.maxOrNull() ?: 1.0).coerceAtLeast(1.0)
                records.forEachIndexed { i, r ->
                    val x = xAt(i); val yHigh = yAt(r[1], maxRecord); val yLow = yAt(r[2], maxRecord); val yOpen = yAt(r[0], maxRecord); val yClose = yAt(r[3], maxRecord)
                    val color = if (r[3] >= r[0]) Color(0xFF2D9A62) else Color(0xFFC94C4C)
                    drawLine(color, Offset(x, yHigh), Offset(x, yLow), 2.dp.toPx())
                    if (chartType == "OHLC Bar Chart") {
                        drawLine(color, Offset(x - 7.dp.toPx(), yOpen), Offset(x, yOpen), 2.dp.toPx())
                        drawLine(color, Offset(x, yClose), Offset(x + 7.dp.toPx(), yClose), 2.dp.toPx())
                    } else {
                        val width = (chartW / (count * 2.2f)).coerceAtLeast(5.dp.toPx())
                        drawRect(color, Offset(x - width / 2, minOf(yOpen, yClose)), Size(width, (abs(yClose - yOpen)).coerceAtLeast(3.dp.toPx())))
                    }
                }
            }
        }
    }

    if (chartType == "Pie Chart" || chartType == "Donut Chart" || chartType == "Stacked Column Chart" || chartType == "Stacked Bar Chart") {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            categoryData.forEachIndexed { i, item ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = colors[i % colors.size], shape = CircleShape, modifier = Modifier.size(8.dp)) {}
                    Spacer(Modifier.width(4.dp))
                    Text("${item.label} ${"%,.0f".format(item.amount)}", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    } else {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            categoryData.forEachIndexed { i, item ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = colors[i % colors.size], shape = CircleShape, modifier = Modifier.size(8.dp)) {}
                    Spacer(Modifier.width(4.dp))
                    Text(item.label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
        }
    }
    if (chartType == "Combo Chart") Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) { LegendDot(primary, "Spending"); LegendDot(secondary, "Income") }
    if (isBudgetChart) Text("Selected period: %,.2f spent · %,.2f budget".format(totalSpend, budget ?: 0.0), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
    if (chartType in listOf("OHLC Bar Chart", "Candlestick Chart", "Heikin-Ashi Chart")) Text("Each OHLC candle summarizes transaction amounts in a spending category, not market prices.", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
}

@Composable private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) { Canvas(Modifier.size(8.dp)) { drawCircle(color) }; Spacer(Modifier.width(4.dp)); Text(label, style = MaterialTheme.typography.labelSmall) }
}
