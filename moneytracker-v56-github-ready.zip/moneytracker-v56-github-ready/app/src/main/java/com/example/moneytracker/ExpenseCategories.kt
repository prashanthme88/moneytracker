package com.example.moneytracker

/** Local-first expense taxonomy and merchant keyword rules. No cloud AI is required to categorize transactions. */
object ExpenseCategories {
    val names = listOf(
        "Food and dining", "Education", "EMI", "Fuel", "Groceries", "Health",
        "House Rent", "Investment", "Kids", "Movies and Subscriptions", "Shopping", "Bills"
    )

    val defaults: Map<String, String> = linkedMapOf(
        "Food and dining" to "talabat|deliveroo|restaurant|cafe|coffee|starbucks|mcdonald|kfc|burger|pizza|shawarma|subway|domino|tim hortons|bakery|food delivery|dining",
        "Education" to "school|tuition|university|college|education|academy|nursery|school fee|school fees|bookshop|education payment",
        "EMI" to "\\bemi\\b|loan installment|loan repayment|car loan|home loan|mortgage|auto finance|finance installment|installment payment",
        "Fuel" to "enoc|adnoc|emarat|eppco|petrol station|fuel station|fuel purchase|\\bpetrol\\b|\\bfuel\\b",
        "Groceries" to "save more|lulu|nesto|carrefour|spinneys|choithram|union ?coop|waitrose|supermarket|hypermarket|grocer|farm fresh|viva|almaya",
        "Health" to "pharmacy|hospital|clinic|medical|aster|nmc|medcare|dental|doctor|healthcare|life pharmacy|boots pharmacy",
        "House Rent" to "house rent|rent payment|rental payment|property rent|real estate rent|landlord|ejari|tenant rent",
        "Investment" to "investment|brokerage|stock market|securities|trading account|mutual fund|investment fund|portfolio|equity purchase",
        "Kids" to "kids|children|toys?\\b|baby shop|babycare|mothercare|toys r us|kidswear|childcare|play area",
        "Movies and Subscriptions" to "netflix|spotify|shahid|osn|disney\\+?|youtube premium|anghami|cinema|vox|reel cinema|movie ticket|playstation|steam|xbox|subscription|apple services|google play",
        "Shopping" to "amazon|noon|namshi|ikea|sharaf|jumbo|centrepoint|h&m|zara|shein|mall|ounass|apple store|electronics|retail|shopping",
        "Bills" to "dewa|addc|sewa|fewa|etisalat|\\bdu\\b|virgin mobile|empower|district cooling|telecom|internet bill|utility|salik recharge|water bill|electricity bill"
    )

    fun defaultRules(): String = defaults.entries.joinToString("\n") { (category, pattern) -> "$category=$pattern" }

    /** Returns exact keyword alternatives assigned to more than one category. */
    fun duplicateKeywords(raw: String): List<Triple<String, String, String>> {
        fun normalize(part: String): String = part
            .replace("\\b", "")
            .replace(Regex("\\[dDsSwW]"), " ")
            .replace(Regex("[^A-Za-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ").trim().lowercase()
        val seen = linkedMapOf<String, String>()
        val duplicates = mutableListOf<Triple<String, String, String>>()
        raw.lineSequence().filter { it.contains("=") }.forEach { line ->
            val category = line.substringBefore("=").trim()
            line.substringAfter("=").split("|").map(::normalize).filter { it.length >= 2 }.forEach { keyword ->
                val prior = seen[keyword]
                if (prior != null && !prior.equals(category, true)) duplicates += Triple(keyword, prior, category)
                else seen[keyword] = category
            }
        }
        return duplicates.distinct()
    }

    fun parseRules(raw: String): List<Pair<String, Regex>> = raw.lineSequence().mapNotNull { line ->
        val category = line.substringBefore("=").trim()
        val pattern = line.substringAfter("=", "").trim()
        if (category.isBlank() || pattern.isBlank()) null
        else runCatching { category to Regex(pattern, RegexOption.IGNORE_CASE) }.getOrNull()
    }.toList()


    fun replaceRule(raw: String, category: String, pattern: String): String {
        val entries = raw.lineSequence().filter { it.isNotBlank() && !it.substringBefore("=").trim().equals(category, true) }.toMutableList()
        if (pattern.isNotBlank()) entries += "$category=${pattern.trim()}"
        val order = names.mapIndexed { index, name -> name.lowercase() to index }.toMap()
        return entries.sortedBy { order[it.substringBefore("=").trim().lowercase()] ?: Int.MAX_VALUE }.joinToString("\n")
    }

    fun appendMerchantRule(raw: String, category: String, merchant: String): String {
        val escaped = Regex.escape(merchant.trim())
        if (escaped.isBlank()) return raw
        val entries = raw.lineSequence().filter { it.isNotBlank() }.toMutableList()
        val index = entries.indexOfFirst { it.substringBefore("=").trim().equals(category, true) }
        if (index >= 0) {
            val old = entries[index].substringAfter("=", "").trim()
            if (runCatching { Regex(old, RegexOption.IGNORE_CASE).containsMatchIn(merchant) }.getOrDefault(false)) return raw
            entries[index] = "$category=${if (old.isBlank()) escaped else "$old|$escaped"}"
        } else entries += "$category=$escaped"
        return entries.joinToString("\n")
    }
}
