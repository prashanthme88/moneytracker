package com.example.moneytracker

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Application entry point declared in AndroidManifest.xml. */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.load(this)
        ReminderWorker.schedule(this)
        AutoBackupWorker.schedule(this)
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            runCatching { TransactionMaintenance.run(this@App) }
        }
    }
}
