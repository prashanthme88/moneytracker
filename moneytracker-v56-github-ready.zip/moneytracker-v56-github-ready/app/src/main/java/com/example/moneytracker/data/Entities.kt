package com.example.moneytracker.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import java.time.*
import java.time.temporal.ChronoUnit

enum class TxType { DEBIT, CREDIT }

@Entity(tableName = "transactions", indices = [Index(value = ["fingerprint"], unique = true)])
data class Txn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Double, val currency: String, val type: TxType,
    val merchant: String?, val account: String?, val bank: String,
    val kind: String? = null, val category: String = "Other",
    val timestamp: Long, val rawText: String,
    val fingerprint: String, // dedupes the SMS + notification copies of one transaction
    /** SMS or NOTIFICATION when the capture channel is known; null for manual/legacy rows. */
    val sourceType: String? = null
)

@Entity(tableName = "bills", indices = [Index(value = ["fingerprint"], unique = true)])
data class Bill(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String, val amount: Double?, val currency: String?,
    val dueDate: Long?, val bank: String, val isSubscription: Boolean = false,
    val status: String = "PENDING", // PENDING | PAID | DISMISSED
    val rawText: String, val fingerprint: String,
    /** Payment evidence. paidAt is the matched transaction time when found, otherwise the manual mark time. */
    val paidAt: Long? = null,
    val paymentTxnId: Long? = null,
    val paymentRawText: String? = null,
    val paymentBank: String? = null,
    val paymentSourceType: String? = null,
    val recurrence: String? = null // NONE | MONTHLY | YEARLY
)

/** Days until due (negative = overdue). Drives the countdown badge in the Bills screen. */
fun Bill.daysLeft(): Int? = dueDate?.let {
    ChronoUnit.DAYS.between(LocalDate.now(), Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).toLocalDate()).toInt()
}

@Dao interface TxDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(t: Txn): Long
    @Update suspend fun update(t: Txn)
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC LIMIT :n") fun recent(n: Int): Flow<List<Txn>>
    @Query("SELECT * FROM transactions ORDER BY timestamp ASC") suspend fun all(): List<Txn>
    @Query("SELECT * FROM transactions WHERE timestamp BETWEEN :from AND :to ORDER BY timestamp DESC")
    suspend fun between(from: Long, to: Long): List<Txn>
    @Query("DELETE FROM transactions WHERE id IN (:ids)") suspend fun deleteByIds(ids: List<Long>)
    @Query("DELETE FROM transactions WHERE id=:id") suspend fun deleteById(id: Long)
    @Query("UPDATE transactions SET category=:category WHERE merchant IS NOT NULL AND lower(trim(merchant))=lower(trim(:merchant))") suspend fun setCategoryForMerchant(merchant: String, category: String): Int
    @Query("UPDATE transactions SET category=CASE WHEN :excluded THEN 'Excluded' ELSE category END WHERE id=:id") suspend fun setExcluded(id: Long, excluded: Boolean)
}

@Dao interface BillDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(b: Bill): Long
    @Update suspend fun update(b: Bill)
    @Query("SELECT * FROM bills WHERE status='PENDING' ORDER BY dueDate IS NULL, dueDate") fun pending(): Flow<List<Bill>>
    @Query("SELECT * FROM bills WHERE status='PENDING'") suspend fun pendingNow(): List<Bill>
    @Query("SELECT * FROM bills ORDER BY dueDate") suspend fun all(): List<Bill>
    @Query("SELECT * FROM bills ORDER BY CASE status WHEN 'PENDING' THEN 0 WHEN 'PAID' THEN 1 ELSE 2 END, dueDate IS NULL, dueDate DESC") fun allFlow(): Flow<List<Bill>>
    @Query("UPDATE bills SET status=:s WHERE id=:id") suspend fun setStatus(id: Long, s: String)
    @Query("UPDATE bills SET status=:s, paidAt=:paidAt, paymentTxnId=:paymentTxnId, paymentRawText=:paymentRawText, paymentBank=:paymentBank, paymentSourceType=:paymentSourceType WHERE id=:id")
    suspend fun setPaymentStatus(id: Long, s: String, paidAt: Long?, paymentTxnId: Long?, paymentRawText: String?, paymentBank: String?, paymentSourceType: String?)
    @Query("DELETE FROM bills WHERE id=:id") suspend fun deleteById(id: Long)
    @Query("DELETE FROM bills WHERE id IN (:ids)") suspend fun deleteByIds(ids: List<Long>)
}

@Database(entities = [Txn::class, Bill::class], version = 5)
abstract class AppDb : RoomDatabase() {
    abstract fun tx(): TxDao
    abstract fun bills(): BillDao
    companion object {
        @Volatile private var inst: AppDb? = null
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE bills ADD COLUMN paidAt INTEGER")
                db.execSQL("ALTER TABLE bills ADD COLUMN paymentTxnId INTEGER")
                db.execSQL("ALTER TABLE bills ADD COLUMN paymentRawText TEXT")
                db.execSQL("ALTER TABLE bills ADD COLUMN paymentBank TEXT")
            }
        }
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Nullable fields preserve legacy rows and do not require destructive migration.
                db.execSQL("ALTER TABLE transactions ADD COLUMN sourceType TEXT")
                db.execSQL("ALTER TABLE bills ADD COLUMN paymentSourceType TEXT")
            }
        }
        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) { db.execSQL("ALTER TABLE bills ADD COLUMN recurrence TEXT") }
        }
        fun closeCurrent() = synchronized(this) { inst?.close(); inst = null }
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "money.db")
                .addMigrations(MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
                .fallbackToDestructiveMigration()
                .build().also { inst = it }
        }
    }
}

/** Internal money movements are tracked under Payments/Cash Wallet, not income or spending. */
fun Txn.isPayment() = category.equals("Card payment", true) || category.equals("Credit card payment", true) || category.equals("Transfers", true) || category.equals("Transfer", true) || category.equals("Direct debit", true)
fun Txn.isCashMovement() = category.equals("Cash transfer", true) || category.equals("Cash withdrawal", true) || category.equals("Cash Wallet top-up", true)
fun Txn.counts() = !category.equals("Excluded", true) && !isCashMovement() && !category.equals("Card payment", true) && !category.equals("Credit card payment", true)
fun Txn.accountLabel() = if (account == null) "Unknown account" else "${kind ?: "Account"} ••$account"

/**
 * Live cash wallet balance for the supplied transactions (current month):
 * + Cash withdrawals / Cash transfers / Cash Wallet top-ups / Cash Wallet income
 * - Cash spending (transactions paid from Cash Wallet or categorized as Cash spending / Cash)
 * Never cached; if spending exceeds withdrawals (or there are no withdrawals), the balance is negative.
 */
fun computeLiveCashWalletBalance(rows: List<Txn>, mainCurrency: String? = null, rateResolver: ((String, String) -> Double?)? = null): Double {
    fun amountInMain(tx: Txn): Double {
        if (mainCurrency.isNullOrBlank() || tx.currency.equals(mainCurrency, true)) return tx.amount
        val rate = rateResolver?.invoke(tx.currency, mainCurrency) ?: 1.0
        return tx.amount * rate
    }
    var balance = 0.0
    for (tx in rows) {
        if (tx.category.equals("Excluded", true)) continue
        val amt = amountInMain(tx)
        when {
            tx.isCashMovement() -> balance += amt
            tx.kind.equals("Cash Wallet", true) && tx.type == TxType.CREDIT -> balance += amt
            tx.kind.equals("Cash Wallet", true) && tx.type == TxType.DEBIT -> balance -= amt
            tx.type == TxType.DEBIT && (tx.category.equals("Cash spending", true) || tx.category.equals("Cash", true)) -> balance -= amt
        }
    }
    return balance
}

fun Txn.isCashWalletEntry(): Boolean =
    !category.equals("Excluded", true) && (
        isCashMovement() ||
        kind.equals("Cash Wallet", true) ||
        (type == TxType.DEBIT && (category.equals("Cash spending", true) || category.equals("Cash", true)))
    )
