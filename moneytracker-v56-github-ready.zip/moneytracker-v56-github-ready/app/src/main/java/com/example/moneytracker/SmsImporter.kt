package com.example.moneytracker

import android.content.Context
import android.provider.Telephony
import com.example.moneytracker.parser.BankParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId

/** Reads the existing SMS inbox. Needs READ_SMS. Safe to run repeatedly: duplicates are ignored by fingerprint. */
object SmsImporter {
    private val inbox = Telephony.Sms.Inbox.CONTENT_URI

    /** Returns (messages scanned, new rows added), or null if the inbox can't be read. */
    suspend fun run(ctx: Context): Pair<Int, Int>? = withContext(Dispatchers.IO) {
        val senders = BankParser.smsSenderMatches()
        if (senders.isEmpty()) {
            runCatching { TransactionMaintenance.run(ctx) }
            return@withContext 0 to 0
        }
        var scanned = 0; var added = 0
        val result = try {
            val sixMonthsAgo = LocalDate.now().minusMonths(3).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
            val selection = "date >= ? AND (address NOT LIKE 'AD-%' OR address LIKE '%AD-KOTAKB-S%') AND (" + senders.joinToString(" OR ") { "address LIKE ?" } + ")"
            val args = arrayOf(sixMonthsAgo.toString(), *senders.map { "%$it%" }.toTypedArray())
            ctx.contentResolver.query(inbox, arrayOf("address", "body", "date"), selection, args, "date ASC")?.use { c ->
                while (c.moveToNext()) {
                    scanned++
                    if (Ingest.handle(ctx, c.getString(0) ?: "", c.getString(1) ?: "", c.getLong(2), historic = true)) added++
                }
            }
            scanned to added
        } catch (e: SecurityException) { null }
        if (result != null) runCatching { TransactionMaintenance.run(ctx) }
        result
    }

    /** Named senders in the latest 1500 messages whose texts look like transactions or bills, most active first. */
    suspend fun detect(ctx: Context): List<Pair<String, Int>> = withContext(Dispatchers.IO) {
        val counts = HashMap<String, Int>()
        try {
            ctx.contentResolver.query(inbox, arrayOf("address", "body"), null, null, "date DESC LIMIT 1500")?.use { c ->
                while (c.moveToNext()) {
                    val a = c.getString(0) ?: continue
                    if (a.none { it.isLetter() } || a.trim().startsWith("AD-", ignoreCase = true)) continue
                    if (BankParser.parse(c.getString(1) ?: "") != null) counts[a] = (counts[a] ?: 0) + 1
                }
            }
        } catch (e: SecurityException) { }
        counts.filter { it.value >= 2 }.toList().sortedByDescending { it.second }
    }
}
