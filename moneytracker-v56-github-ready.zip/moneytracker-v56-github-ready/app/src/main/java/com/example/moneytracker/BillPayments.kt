package com.example.moneytracker

import com.example.moneytracker.data.*
import kotlin.math.abs
import java.util.Locale

/** Conservative matching of a bill to captured debits. Unmatched manual payments still record the time marked paid. */
object BillPayments {
    private val cardBillPattern = Regex("credit\\s*card|card.{0,30}(statement|bill)|statement.{0,30}card|\\bcc\\b", RegexOption.IGNORE_CASE)
    private val cardPaymentPattern = Regex("credit\\s*card.{0,30}payment|card.{0,20}payment|payment.{0,35}(credit\\s*card|card)|thank you for your payment|card payment", RegexOption.IGNORE_CASE)
    private val paymentPattern = Regex("payment|paid|bill|settlement|autopay|standing order|direct debit|thank you for your payment", RegexOption.IGNORE_CASE)

    fun canonicalBillerKey(bill: Bill): String {
        val raw = "${bill.title} ${bill.bank}".lowercase(Locale.ROOT)
        val stopWords = setOf("bill", "statement", "stmt", "payment", "due", "reminder", "monthly", "invoice", "pending", "manual", "pasted", "message", "subscription", "covered", "card", "account", "bank")
        val known = listOf("dewa", "etisalat", "e&", "du", "salik", "empower", "sewa", "fewa", "etihadwe", "addc", "tabreed", "emicool", "sergas", "lootah", "virgin", "netflix", "spotify", "youtube", "disney", "osn", "shahid", "apple", "icloud", "google", "amazon", "noon", "careem", "talabat", "enbd", "emirates nbd", "adcb", "fab", "mashreq", "dib", "adib", "rakbank", "hsbc", "citi", "dubaifirst", "dubai first", "hdfc", "icici", "sbi", "kotak", "axis")
        val matchedKnown = known.firstOrNull { k ->
            if (k.length <= 2) Regex("\\b${Regex.escape(k)}\\b", RegexOption.IGNORE_CASE).containsMatchIn(raw)
            else raw.contains(k)
        }?.let { if (it == "e&") "etisalat" else if (it == "enbd") "emirates nbd" else if (it == "dubaifirst") "dubai first" else it }
        val last4 = lastFour(bill.title + " " + bill.rawText).orEmpty()
        if (matchedKnown != null) return "$matchedKnown|$last4"
        val tokens = normalize(bill.title).split(Regex("\\s+")).filter { it.length >= 2 && it !in stopWords }
        val base = if (tokens.isNotEmpty()) tokens.joinToString(" ") else normalize(bill.title)
        return "$base|$last4"
    }

    fun isSameDayOrClose(a: Long?, b: Long?): Boolean {
        if (a == null && b == null) return true
        if (a == null || b == null) return false
        val da = java.time.Instant.ofEpochMilli(a).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
        val db = java.time.Instant.ofEpochMilli(b).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
        return da == db || kotlin.math.abs(java.time.temporal.ChronoUnit.DAYS.between(da, db)) <= 3
    }

    fun isDuplicateBill(existing: List<Bill>, candidate: Bill): Boolean {
        val candKey = canonicalBillerKey(candidate)
        val candNormTitle = normalize(candidate.title)
        val candRawNorm = normalize(candidate.rawText)
        return existing.any { b ->
            if (b.fingerprint.equals(candidate.fingerprint, ignoreCase = true)) return@any true
            if (candRawNorm.length >= 16 && candRawNorm == normalize(b.rawText) && !candRawNorm.startsWith("manually added")) return@any true
            val sameBiller = canonicalBillerKey(b) == candKey || normalize(b.title) == candNormTitle
            if (!sameBiller) return@any false
            val sameAmount = when {
                b.amount != null && candidate.amount != null -> abs(b.amount - candidate.amount) <= 0.01
                b.amount == null && candidate.amount == null -> true
                else -> false
            }
            val sameDue = isSameDayOrClose(b.dueDate, candidate.dueDate)
            when {
                b.dueDate != null && candidate.dueDate != null -> sameDue && (sameAmount || b.amount == null || candidate.amount == null)
                b.amount != null && candidate.amount != null -> sameAmount && (b.dueDate == null || candidate.dueDate == null || sameDue)
                else -> sameDue && sameAmount
            }
        }
    }

    suspend fun insertIfUnique(db: AppDb, candidate: Bill): Long {
        val existing = db.bills().all()
        if (isDuplicateBill(existing, candidate)) return -1L
        return db.bills().insert(candidate)
    }

    fun isCreditCardBill(bill: Bill): Boolean = cardBillPattern.containsMatchIn(bill.title + " " + bill.rawText)

    fun findMatchingPayment(bill: Bill, transactions: List<Txn>, assignedTxnIds: Set<Long> = emptySet()): Txn? {
        val expected = bill.amount ?: return null
        if (expected <= 0.0) return null
        val due = bill.dueDate
        val from = (due ?: System.currentTimeMillis()) - 60L * 24 * 60 * 60 * 1000
        val to = (due ?: System.currentTimeMillis()) + 45L * 24 * 60 * 60 * 1000
        val billLast4 = lastFour(bill.title + " " + bill.rawText)
        val tokens = normalize(bill.title).split(Regex("\\s+")).filter { it.length >= 4 && it !in setOf("credit", "card", "statement", "payment", "bill") }
        return transactions.asSequence()
            .filter { it.id !in assignedTxnIds }
            .filter { tx ->
                // Card-payment confirmations can be represented as credits by some issuers;
                // allow those only when the message itself is clearly a card-payment record.
                val raw = tx.rawText
                val clearCardPayment = tx.category.equals("Card payment", true) || cardPaymentPattern.containsMatchIn(raw)
                if (isCreditCardBill(bill)) tx.type == TxType.DEBIT || clearCardPayment else tx.type == TxType.DEBIT
            }
            .filter { it.timestamp in from..to }
            .filter { tx ->
                val tolerance = maxOf(0.01, expected * 0.005)
                abs(tx.amount - expected) <= tolerance &&
                    (bill.currency.isNullOrBlank() || tx.currency.equals(bill.currency, true))
            }
            .filter { tx ->
                val raw = tx.rawText
                val cardPayment = tx.category.equals("Card payment", true) || cardPaymentPattern.containsMatchIn(raw)
                if (isCreditCardBill(bill)) {
                    cardPayment
                } else {
                    val txText = normalize((tx.merchant.orEmpty()) + " " + raw)
                    val nameMatch = tokens.any { it in txText }
                    paymentPattern.containsMatchIn(raw) || nameMatch || tx.category.equals("Bill payment", true)
                }
            }
            .filter { tx ->
                val txLast4 = lastFour((tx.account ?: "") + " " + tx.rawText)
                billLast4 == null || txLast4 == null || billLast4 == txLast4
            }
            .sortedBy { tx -> if (due == null) -tx.timestamp else abs(tx.timestamp - due) }
            .firstOrNull()
    }

    suspend fun setStatus(db: AppDb, bill: Bill, status: String, at: Long = System.currentTimeMillis()) {
        if (status == "PAID") {
            val allBills = db.bills().all()
            val used = allBills.filter { it.id != bill.id }.mapNotNull { it.paymentTxnId }.toSet()
            val matched = findMatchingPayment(bill, db.tx().all(), used)
            db.bills().setPaymentStatus(
                bill.id, "PAID", matched?.timestamp ?: at, matched?.id,
                matched?.rawText, matched?.bank, matched?.sourceType
            )
            // Create the next occurrence only once the current recurring bill is paid.
            if (bill.recurrence.equals("MONTHLY", true) && bill.dueDate != null) {
                val nextDate = java.time.Instant.ofEpochMilli(bill.dueDate).atZone(java.time.ZoneId.systemDefault()).toLocalDate().plusMonths(1)
                val nextMillis = nextDate.atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
                val nextFingerprint = "RECURRING|${bill.id}|${nextDate}"
                insertIfUnique(db, bill.copy(id = 0, dueDate = nextMillis, status = "PENDING", fingerprint = nextFingerprint, paidAt = null, paymentTxnId = null, paymentRawText = null, paymentBank = null, paymentSourceType = null))
            }
        } else {
            db.bills().setPaymentStatus(bill.id, status, null, null, null, null, null)
        }
    }

    suspend fun reconcileTransactionWithBills(ctx: android.content.Context, db: AppDb, tx: Txn, notify: Boolean = true): List<Bill> {
        val allBills = db.bills().all()
        val pendingBills = allBills.filter { it.status == "PENDING" && (it.amount ?: 0.0) > 0.0 }
        if (pendingBills.isEmpty()) return emptyList()
        val usedTxnIds = allBills.filter { it.status == "PAID" }.mapNotNull { it.paymentTxnId }.toMutableSet()
        if (tx.id in usedTxnIds) return emptyList()
        val matchedBills = mutableListOf<Bill>()
        val txLast4 = lastFour((tx.account ?: "") + " " + tx.rawText)
        val isCardPaymentTx = tx.category.equals("Card payment", true) || tx.category.equals("Credit card payment", true) || cardPaymentPattern.containsMatchIn(tx.rawText)
        for (bill in pendingBills) {
            val expected = bill.amount ?: continue
            if (expected <= 0.0) continue
            val tolerance = maxOf(0.01, expected * 0.005)
            val amountMatches = abs(tx.amount - expected) <= tolerance &&
                (bill.currency.isNullOrBlank() || tx.currency.equals(bill.currency, true))
            if (!amountMatches) continue
            val due = bill.dueDate
            val inWindow = due == null || (tx.timestamp in (due - 60L * 24 * 60 * 60 * 1000)..(due + 45L * 24 * 60 * 60 * 1000))
            if (!inWindow) continue
            val billLast4 = lastFour(bill.title + " " + bill.rawText)
            val last4Compatible = billLast4 == null || txLast4 == null || billLast4 == txLast4
            if (!last4Compatible) continue
            val directionCompatible = tx.type == TxType.DEBIT || isCardPaymentTx
            if (!directionCompatible) continue

            // Mark bill as PAID and link payment evidence
            db.bills().setPaymentStatus(
                bill.id, "PAID", tx.timestamp, tx.id.takeIf { it > 0 },
                tx.rawText, tx.bank, tx.sourceType
            )
            if (bill.recurrence.equals("MONTHLY", true) && bill.dueDate != null) {
                val nextDate = java.time.Instant.ofEpochMilli(bill.dueDate).atZone(java.time.ZoneId.systemDefault()).toLocalDate().plusMonths(1)
                val nextMillis = nextDate.atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
                val nextFingerprint = "RECURRING|${bill.id}|${nextDate}"
                insertIfUnique(db, bill.copy(id = 0, dueDate = nextMillis, status = "PENDING", fingerprint = nextFingerprint, paidAt = null, paymentTxnId = null, paymentRawText = null, paymentBank = null, paymentSourceType = null))
            }
            usedTxnIds += tx.id
            matchedBills += bill
            if (notify) {
                TransactionNotice.showBillPaidConfirmation(ctx, bill, tx)
            }
            break
        }
        if (matchedBills.isEmpty() && isCardPaymentTx && notify) {
            TransactionNotice.showCardPaymentConfirmation(ctx, tx)
        }
        return matchedBills
    }

    private fun normalize(s: String) = s.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun lastFour(s: String): String? {
        val patterns = listOf(
            Regex("(?:card|account|a/c|acct)[^0-9]{0,20}([0-9]{4})", RegexOption.IGNORE_CASE),
            Regex("(?:ending|ends)(?:\\s+with|\\s+in)?\\s*[:#-]?\\s*[xX*•.\\-]*([0-9]{4})", RegexOption.IGNORE_CASE),
            Regex("\\b([0-9]{4})[xX*•.\\-]{2,}", RegexOption.IGNORE_CASE)
        )
        return patterns.firstNotNullOfOrNull { it.find(s)?.groupValues?.get(1) }
    }
}
