package com.example.moneytracker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.moneytracker.data.AppDb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.time.Duration
import java.time.ZonedDateTime
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Shared SAF-backed backup destination for manual and automatic backups. */
object BackupStorage {
    private fun java.util.Enumeration<out java.util.zip.ZipEntry>.asSequenceCompat(): Sequence<java.util.zip.ZipEntry> = sequence {
        while (hasMoreElements()) yield(nextElement())
    }

    suspend fun createBackup(context: Context, kind: String): String = withContext(Dispatchers.IO) {
        val treeUri = Prefs.backupFolderUri(context)?.let { Uri.parse(it) }
            ?: throw IllegalStateException("Choose a backup folder in Settings first.")
        val directory = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("The selected backup folder is no longer available. Choose it again.")
        if (!directory.canWrite()) throw IllegalStateException("The selected backup folder is read-only.")

        AppDb.get(context).openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
        val stamp = java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(java.util.Date())
        val name = "moneytracker-${kind.lowercase()}-$stamp.zip"
        val target = directory.createFile("application/zip", name)
            ?: throw IllegalStateException("Couldn't create a backup in the selected folder.")
        try {
            val output = context.contentResolver.openOutputStream(target.uri, "w")
                ?: throw IllegalStateException("Couldn't open the backup file for writing.")
            output.use { stream ->
                ZipOutputStream(stream).use { zip ->
                    fun add(file: File, entryName: String) {
                        if (!file.isFile) return
                        zip.putNextEntry(ZipEntry(entryName))
                        FileInputStream(file).use { input -> input.copyTo(zip) }
                        zip.closeEntry()
                    }
                    add(context.getDatabasePath("money.db"), "money.db")
                    File(context.applicationInfo.dataDir, "shared_prefs").listFiles()?.filter { it.isFile && it.name.endsWith(".xml") }?.forEach { prefFile ->
                        add(prefFile, "shared_prefs/${prefFile.name}")
                    }
                    add(File(context.filesDir, "model.task"), "model.task")
                }
            }
            if (target.length() <= 0L) throw IllegalStateException("Backup file is empty.")
            prune(directory)
            target.name ?: name
        } catch (t: Throwable) {
            target.delete()
            throw t
        }
    }

    /** Restores a MoneyTracker ZIP backup. Call from a user-selected ZIP URI. */
    suspend fun restoreBackup(context: Context, uri: Uri): String = withContext(Dispatchers.IO) {
        val temp = File(context.cacheDir, "restore-${System.currentTimeMillis()}.tmp")
        context.contentResolver.openInputStream(uri)?.use { input -> temp.outputStream().use { output -> input.copyTo(output) } }
            ?: throw IllegalStateException("Couldn't open the selected backup.")
        val staging = File(context.cacheDir, "moneytracker-restore").apply { deleteRecursively(); mkdirs() }
        try {
            java.util.zip.ZipFile(temp).use { zip ->
                val dbEntry = zip.getEntry("money.db") ?: throw IllegalArgumentException("This ZIP does not contain a MoneyTracker database.")
                val prefsEntries = zip.entries().asSequenceCompat().filter { !it.isDirectory && it.name.startsWith("shared_prefs/") && it.name.endsWith(".xml") }.toList()
                val settingsPresent = prefsEntries.any { it.name == "shared_prefs/settings.xml" } || zip.getEntry("settings.xml") != null
                if (!settingsPresent) throw IllegalArgumentException("This ZIP does not contain MoneyTracker settings and parser rules.")
                fun extract(entry: java.util.zip.ZipEntry, target: File) {
                    target.parentFile?.mkdirs()
                    zip.getInputStream(entry).use { input -> target.outputStream().use { output -> input.copyTo(output) } }
                }
                val stagedDb = File(staging, "money.db")
                extract(dbEntry, stagedDb)
                prefsEntries.forEach { entry -> extract(entry, File(staging, entry.name)) }
                zip.getEntry("settings.xml")?.let { extract(it, File(staging, "shared_prefs/settings.xml")) }
                val stagedModel = zip.getEntry("model.task")?.let { File(staging, "model.task").also { f -> extract(zip.getEntry("model.task"), f) } }
                AppDb.closeCurrent()
                val dbFile = context.getDatabasePath("money.db")
                dbFile.parentFile?.mkdirs()
                File(dbFile.path + "-wal").delete(); File(dbFile.path + "-shm").delete()
                if (dbFile.exists() && !dbFile.delete()) throw IllegalStateException("Couldn't replace the existing database.")
                stagedDb.copyTo(dbFile, overwrite = true)
                val prefsDir = File(context.applicationInfo.dataDir, "shared_prefs")
                prefsDir.mkdirs()
                prefsDir.listFiles()?.filter { it.isFile && it.name.endsWith(".xml") }?.forEach { it.delete() }
                File(staging, "shared_prefs").listFiles()?.filter { it.isFile && it.name.endsWith(".xml") }?.forEach { staged ->
                    staged.copyTo(File(prefsDir, staged.name), overwrite = true)
                }
                val modelTarget = File(context.filesDir, "model.task")
                if (stagedModel != null) stagedModel.copyTo(modelTarget, overwrite = true) else modelTarget.delete()
                "Restore completed. Transactions, bills, settings and saved parser rules have been restored. Please close and reopen MoneyTracker."
            }
        } finally { temp.delete(); staging.deleteRecursively() }
    }

    fun prune(directory: DocumentFile) {
        directory.listFiles().filter { it.isFile && it.name.orEmpty().startsWith("moneytracker-", true) && it.name.orEmpty().endsWith(".zip", true) }
            .sortedByDescending { it.lastModified() }
            .drop(2).forEach { it.delete() }
    }

    fun pruneCsvExports(directory: DocumentFile) {
        directory.listFiles().filter { it.isFile && it.name.orEmpty().startsWith("moneytracker-export-", true) && it.name.orEmpty().endsWith(".csv", true) }
            .sortedByDescending { it.lastModified() }
            .drop(2).forEach { it.delete() }
    }

    fun clearLegacyBackups(context: Context) {
        File(context.filesDir, "auto-backups").listFiles { f -> f.isFile && f.name.endsWith(".zip", true) }
            ?.forEach { it.delete() }
    }
}

/** Local rolling backup; manual and automatic ZIPs share one folder and one two-file retention policy. */
class AutoBackupWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        if (!Prefs.autoBackupEnabled(applicationContext)) return Result.success()
        if (Prefs.backupFolderUri(applicationContext).isNullOrBlank()) return Result.success()
        return try {
            val name = BackupStorage.createBackup(applicationContext, "auto")
            Result.success(workDataOf("backup_name" to name))
        } catch (_: Throwable) { Result.retry() }
    }

    companion object {
        fun schedule(ctx: Context) {
            val wm = WorkManager.getInstance(ctx)
            if (!Prefs.autoBackupEnabled(ctx) || Prefs.backupFolderUri(ctx).isNullOrBlank()) {
                wm.cancelUniqueWork("moneytracker-auto-backup")
                return
            }
            val now = ZonedDateTime.now()
            var target = now.toLocalDate().atTime(2, 0).atZone(now.zone)
            if (!target.isAfter(now)) target = target.plusDays(1)
            val delay = Duration.between(now, target).toMillis().coerceAtLeast(1_000L)
            val request = PeriodicWorkRequestBuilder<AutoBackupWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(delay, TimeUnit.MILLISECONDS).build()
            wm.enqueueUniquePeriodicWork("moneytracker-auto-backup", ExistingPeriodicWorkPolicy.UPDATE, request)
        }
    }
}

/** Optional high-detail notification for each successfully inserted transaction and automatic bill/card payment confirmation. */
object TransactionNotice {
    fun show(context: Context, amount: Double, currency: String, merchant: String?, type: String) {
        if (!Prefs.transactionNotificationsEnabled(context)) return
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel("new-transactions", "New transactions", NotificationManager.IMPORTANCE_DEFAULT))
        val title = if (type == "CREDIT") "New income" else "New expense"
        val value = "%s %,.2f".format(Locale.getDefault(), currency, amount)
        val body = listOf(value, merchant?.takeIf { it.isNotBlank() } ?: "Merchant not identified").joinToString(" · ")
        runCatching {
            val reqCode = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
            val contentIntent = NotificationNavigation.pendingIntent(context, NotificationNavigation.TAB_TRANSACTIONS, reqCode)
            NotificationManagerCompat.from(context).notify(reqCode,
                NotificationCompat.Builder(context, "new-transactions")
                    .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                    .setContentIntent(contentIntent)
                    .setAutoCancel(true).build())
        }
    }

    fun showBillPaidConfirmation(context: Context, bill: com.example.moneytracker.data.Bill, tx: com.example.moneytracker.data.Txn) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel("bills", "Bill reminders & confirmations", NotificationManager.IMPORTANCE_DEFAULT))
        val value = "%s %,.2f".format(Locale.getDefault(), tx.currency, tx.amount)
        val title = "Bill marked paid: ${bill.title}"
        val body = "Matched $value from ${tx.bank}${tx.merchant?.let { " · $it" }.orEmpty()}. Tap to view and confirm in Bills & Payments."
        runCatching {
            val reqCode = ((System.currentTimeMillis() + bill.id) % Int.MAX_VALUE).toInt()
            val contentIntent = NotificationNavigation.pendingIntent(context, NotificationNavigation.TAB_BILLS, reqCode)
            NotificationManagerCompat.from(context).notify(reqCode,
                NotificationCompat.Builder(context, "bills")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                    .setContentIntent(contentIntent)
                    .setAutoCancel(true).build())
        }
    }

    fun showCardPaymentConfirmation(context: Context, tx: com.example.moneytracker.data.Txn) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel("bills", "Bill reminders & confirmations", NotificationManager.IMPORTANCE_DEFAULT))
        val value = "%s %,.2f".format(Locale.getDefault(), tx.currency, tx.amount)
        val cardLabel = tx.account?.let { " ••$it" }.orEmpty()
        val title = "Card payment recorded: ${tx.bank}$cardLabel"
        val body = "Payment of $value marked done. Tap to confirm in Bills & Payments."
        runCatching {
            val reqCode = ((System.currentTimeMillis() + tx.id) % Int.MAX_VALUE).toInt()
            val contentIntent = NotificationNavigation.pendingIntent(context, NotificationNavigation.TAB_BILLS, reqCode)
            NotificationManagerCompat.from(context).notify(reqCode,
                NotificationCompat.Builder(context, "bills")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                    .setContentIntent(contentIntent)
                    .setAutoCancel(true).build())
        }
    }
}
