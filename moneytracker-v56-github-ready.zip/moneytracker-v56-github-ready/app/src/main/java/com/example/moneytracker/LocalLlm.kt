package com.example.moneytracker

import android.content.Context
import android.net.Uri
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** On-device LLM (MediaPipe, Gemma .task file). MediaPipe's LLM API is maintenance-only; swap just this file if you move to LiteRT-LM. */
object LocalLlm {
    private var engine: LlmInference? = null
    fun ready(c: Context) = Prefs.modelFile(c).let { it.exists() && it.length() > 1_000_000 }

    suspend fun install(c: Context, uri: Uri) = withContext(Dispatchers.IO) {
        engine?.close(); engine = null
        c.contentResolver.openInputStream(uri)!!.use { i -> Prefs.modelFile(c).outputStream().use { o -> i.copyTo(o) } }
    }

    suspend fun generate(c: Context, prompt: String): String = withContext(Dispatchers.IO) {
        val e = engine ?: LlmInference.createFromOptions(c.applicationContext,
            LlmInference.LlmInferenceOptions.builder().setModelPath(Prefs.modelFile(c).absolutePath).setMaxTokens(1536).build()).also { engine = it }
        e.generateResponse("<start_of_turn>user\n$prompt<end_of_turn>\n<start_of_turn>model\n")
    }
}
