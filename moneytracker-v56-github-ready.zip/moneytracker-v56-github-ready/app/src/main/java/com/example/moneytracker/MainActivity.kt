package com.example.moneytracker

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AS
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.basicMarquee
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.togetherWith
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import coil.compose.AsyncImage
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.moneytracker.data.*
import com.example.moneytracker.parser.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.math.abs
import kotlin.math.absoluteValue


@Composable
private fun UnparsedSmsReportCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf<List<String>>(emptyList()) }
    var show by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Unparsed SMS report", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text("Find recent SMS messages from bank-like sender IDs that contain an amount but were not recognised as transactions. Only sender and message snippets are shown for reporting.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(enabled = !loading && ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED, onClick = {
                loading = true
                scope.launch {
                    report = withContext(Dispatchers.IO) {
                        val rows = mutableListOf<String>()
                        val since = java.time.LocalDate.now().minusMonths(3).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
                        val amountRx = Regex("(?i)(AED|INR|USD|EUR|GBP|\\$|₹)\\s*[0-9][0-9,]*(?:\\.[0-9]{1,2})?")
                        runCatching {
                            ctx.contentResolver.query(android.provider.Telephony.Sms.Inbox.CONTENT_URI, arrayOf("address", "body", "date"), "date >= ?", arrayOf(since.toString()), "date DESC")?.use { c ->
                                while (c.moveToNext() && rows.size < 50) {
                                    val sender = c.getString(0).orEmpty(); val body = c.getString(1).orEmpty()
                                    if (sender.any { it.isLetter() } && amountRx.containsMatchIn(body) && com.example.moneytracker.parser.BankParser.parse(body) == null) {
                                        rows += "$sender · ${java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault()).format(java.util.Date(c.getLong(2)))}\n${body.take(260)}"
                                    }
                                }
                            }
                        }
                        rows
                    }
                    loading = false; show = true
                }
            }) { Text(if (loading) "Scanning…" else "Show unparsed SMS with amounts") }
        }
    }
    if (show) AlertDialog(onDismissRequest = { show = false }, title = { Text("Unparsed SMS report · ${report.size}") },
        text = { if (report.isEmpty()) Text("No matching unparsed messages found in the last three months.") else Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) { report.forEachIndexed { i, row -> if (i > 0) HorizontalDivider(); Text(row, style = MaterialTheme.typography.bodySmall) } } },
        confirmButton = { TextButton(onClick = { show = false }) { Text("Close") } })
}

private object NetPrivacySession { var revealed: Boolean = false }
private object NavIntentState {
    val targetTab = mutableStateOf<Int?>(null)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        NetPrivacySession.revealed = false
        handleNavigationIntent(intent)
        enableEdgeToEdge()
        setContent { AppTheme { MoneyApp() } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNavigationIntent(intent)
    }

    private fun handleNavigationIntent(intent: Intent?) {
        val tab = intent?.getIntExtra(NotificationNavigation.EXTRA_TARGET_TAB, -1) ?: -1
        if (tab in 0..2) {
            NavIntentState.targetTab.value = tab
            intent?.removeExtra(NotificationNavigation.EXTRA_TARGET_TAB)
        }
    }
}

private object ThemeState {
    val mode = mutableStateOf("System")
    val accent = mutableStateOf("Teal")
}

@Composable fun AppTheme(content: @Composable () -> Unit) {
    val c = LocalContext.current
    LaunchedEffect(Unit) { ThemeState.mode.value = Prefs.themeMode(c); ThemeState.accent.value = Prefs.themeAccent(c) }
    val dark = when (ThemeState.mode.value) { "Dark" -> true; "Light" -> false; else -> isSystemInDarkTheme() }
    val accent = when (ThemeState.accent.value) {
        "Blue" -> if (dark) Color(0xFF82B1FF) else Color(0xFF1565C0)
        "Purple" -> if (dark) Color(0xFFD0BCFF) else Color(0xFF6750A4)
        "Orange" -> if (dark) Color(0xFFFFCC80) else Color(0xFFB45309)
        "Emerald" -> if (dark) Color(0xFF6EE7B7) else Color(0xFF047857)
        "Crimson" -> if (dark) Color(0xFFFDA4AF) else Color(0xFFBE123C)
        else -> if (dark) Color(0xFF80CBC4) else Color(0xFF00695C)
    }
    val scheme = if (dark) {
        darkColorScheme(
            primary = accent,
            secondary = accent,
            tertiary = accent,
            primaryContainer = accent.copy(alpha = 0.22f),
            onPrimaryContainer = Color(0xFFF1F5F9),
            secondaryContainer = Color(0xFF1E242B),
            onSecondaryContainer = Color(0xFFE2E8F0),
            background = Color(0xFF0B0E11),
            surface = Color(0xFF0F1317),
            surfaceVariant = Color(0xFF191F26),
            surfaceContainerLowest = Color(0xFF090C0F),
            surfaceContainerLow = Color(0xFF13181D),
            surfaceContainer = Color(0xFF171C22),
            surfaceContainerHigh = Color(0xFF1C2229),
            surfaceContainerHighest = Color(0xFF242B33),
            outline = Color(0xFF475569),
            outlineVariant = Color(0xFF334155)
        )
    } else {
        lightColorScheme(
            primary = accent,
            secondary = accent,
            tertiary = accent,
            primaryContainer = accent.copy(alpha = 0.15f),
            onPrimaryContainer = Color(0xFF0F172A),
            secondaryContainer = Color(0xFFF1F5F9),
            onSecondaryContainer = Color(0xFF1E293B),
            background = Color(0xFFF8FAFC),
            surface = Color(0xFFF8FAFC),
            surfaceVariant = Color(0xFFEFF4F8),
            surfaceContainerLowest = Color(0xFFFFFFFF),
            surfaceContainerLow = Color(0xFFFFFFFF),
            surfaceContainer = Color(0xFFFFFFFF),
            surfaceContainerHigh = Color(0xFFFFFFFF),
            surfaceContainerHighest = Color(0xFFF1F5F9),
            outline = Color(0xFF94A3B8),
            outlineVariant = Color(0xFFCBD5E1)
        )
    }
    val appShapes = Shapes(
        extraSmall = RoundedCornerShape(8.dp),
        small = RoundedCornerShape(12.dp),
        medium = RoundedCornerShape(16.dp),
        large = RoundedCornerShape(20.dp),
        extraLarge = RoundedCornerShape(28.dp)
    )
    MaterialTheme(colorScheme = scheme, shapes = appShapes, content = content)
}

// Global Flat Card overrides: 0dp elevation, 16dp rounded corners, and crisp 1.5dp borders across the entire app
@Composable
fun Card(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(16.dp),
    colors: CardColors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
    ),
    elevation: CardElevation = CardDefaults.cardElevation(
        defaultElevation = 0.dp,
        pressedElevation = 0.dp,
        focusedElevation = 0.dp,
        hoveredElevation = 0.dp,
        draggedElevation = 0.dp,
        disabledElevation = 0.dp
    ),
    border: BorderStroke? = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.9f)),
    content: @Composable ColumnScope.() -> Unit
) {
    androidx.compose.material3.Card(
        modifier = modifier,
        shape = shape,
        colors = colors,
        elevation = elevation,
        border = border,
        content = content
    )
}

@Composable
fun Card(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    shape: Shape = RoundedCornerShape(16.dp),
    colors: CardColors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
    ),
    elevation: CardElevation = CardDefaults.cardElevation(
        defaultElevation = 0.dp,
        pressedElevation = 0.dp,
        focusedElevation = 0.dp,
        hoveredElevation = 0.dp,
        draggedElevation = 0.dp,
        disabledElevation = 0.dp
    ),
    border: BorderStroke? = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.9f)),
    content: @Composable ColumnScope.() -> Unit
) {
    androidx.compose.material3.Card(
        onClick = onClick,
        modifier = modifier,
        enabled = enabled,
        shape = shape,
        colors = colors,
        elevation = elevation,
        border = border,
        content = content
    )
}

// ---------- helpers ----------
fun todayRange(): Pair<Long, Long> { val z = ZoneId.systemDefault(); val d = LocalDate.now(); return d.atStartOfDay(z).toInstant().toEpochMilli() to d.plusDays(1).atStartOfDay(z).toInstant().toEpochMilli() - 1 }
fun yesterdayRange(): Pair<Long, Long> { val z = ZoneId.systemDefault(); val d = LocalDate.now().minusDays(1); return d.atStartOfDay(z).toInstant().toEpochMilli() to d.plusDays(1).atStartOfDay(z).toInstant().toEpochMilli() - 1 }
fun monthRange(back: Int): Pair<Long, Long> {
    val m = YearMonth.now().minusMonths(back.toLong()); val z = ZoneId.systemDefault()
    return m.atDay(1).atStartOfDay(z).toInstant().toEpochMilli() to m.plusMonths(1).atDay(1).atStartOfDay(z).toInstant().toEpochMilli() - 1
}
fun dayLabel(d: LocalDate): String { val t = LocalDate.now(); return when (d) { t -> "Today"; t.minusDays(1) -> "Yesterday"; else -> d.format(DateTimeFormatter.ofPattern("EEE, d MMM")) } }
fun String.plain() = replace("**", "").replace(Regex("(?m)^#+\\s*"), "").replace(Regex("(?m)^\\s*[-*]\\s+"), "• ")
fun canonicalBankName(bank: String): String = if (Regex("(?i)\\b(?:ENBDX|ENBD|Emirates\\s*NBD)\\b").containsMatchIn(bank)) "Emirates NBD" else bank.trim()
val knownBanksCatalog = listOf(
    "Emirates NBD", "ADCB", "First Abu Dhabi Bank (FAB)", "Mashreq", "Dubai Islamic Bank (DIB)",
    "Abu Dhabi Islamic Bank (ADIB)", "RAKBANK", "Commercial Bank of Dubai (CBD)", "Dubai First",
    "Sharjah Islamic Bank (SIB)", "Ajman Bank", "HSBC", "Citibank", "Standard Chartered",
    "Wio Bank", "Liv.", "YAP", "Al Hilal Bank", "NBF", "UAB",
    "HDFC Bank", "ICICI Bank", "State Bank of India (SBI)", "Axis Bank", "Kotak Mahindra Bank",
    "IDFC FIRST Bank", "Yes Bank", "IndusInd Bank", "Bank of Baroda", "Punjab National Bank", "Canara Bank", "Federal Bank"
)

fun bankDomainOrNull(bankOrName: String): String? {
    val b = bankOrName.lowercase(Locale.ROOT)
    return when {
        "emirates nbd" in b || "enbd" in b -> "emiratesnbd.com"
        "adcb" in b || "abu dhabi commercial" in b -> "adcb.com"
        "fab" in b || "first abu dhabi" in b -> "bankfab.com"
        "mashreq" in b -> "mashreq.com"
        "dib" in b || "dubai islamic" in b -> "dib.ae"
        "adib" in b || "abu dhabi islamic" in b -> "adib.ae"
        "rakbank" in b || "rak bank" in b -> "rakbank.ae"
        "cbd" in b || "commercial bank of dubai" in b -> "cbd.ae"
        "sib" in b || "sharjah islamic" in b -> "sib.ae"
        "ajman" in b -> "ajmanbank.ae"
        "wio" in b -> "wio.io"
        "liv" in b -> "liv.me"
        "yap" in b -> "yap.com"
        "al hilal" in b || "alhilal" in b -> "alhilalbank.ae"
        "nbf" in b || "national bank of fujairah" in b -> "nbf.ae"
        "uab" in b || "united arab bank" in b -> "uab.ae"
        "hsbc" in b -> "hsbc.ae"
        "citi" in b -> "citi.com"
        "standard chartered" in b -> "sc.com"
        "dubai first" in b || "dubaifirst" in b -> "dubaifirst.com"
        "sbi" in b || "state bank" in b -> "sbi.co.in"
        "hdfc" in b -> "hdfcbank.com"
        "icici" in b -> "icicibank.com"
        "axis" in b -> "axisbank.com"
        "kotak" in b -> "kotak.com"
        "idfc" in b -> "idfcfirstbank.com"
        "yes bank" in b || "yesbank" in b -> "yesbank.in"
        "indusind" in b -> "indusind.com"
        "baroda" in b || "bob" in b -> "bankofbaroda.in"
        "punjab national" in b || "pnb" in b -> "pnbindia.in"
        "canara" in b -> "canarabank.com"
        "federal" in b -> "federalbank.co.in"
        else -> null
    }
}

fun bankLogoUrl(bank: String): String {
    val domain = bankDomainOrNull(bank)
    return if (domain.isNullOrBlank()) "https://www.google.com/s2/favicons?domain=bank&sz=128" else "https://www.google.com/s2/favicons?domain=$domain&sz=128"
}

private fun searchBankLogoOnTheFly(bankOrName: String): String? {
    bankDomainOrNull(bankOrName)?.let { return "https://www.google.com/s2/favicons?domain=$it&sz=128" }
    val clean = bankOrName
        .replace(Regex("••\\d+"), " ")
        .replace(Regex("(?i)\\b(account|credit|debit|card|loan|home|car|personal|ending|with|bank & debit)\\b"), " ")
        .replace(Regex("[^A-Za-z0-9 ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
    if (clean.length < 2) return null
    val cacheKey = "BANK|" + clean.lowercase(Locale.ROOT)
    BillIconSearchCache.map[cacheKey]?.let { cached -> return cached.ifBlank { null } }
    val discovered = runCatching {
        val encoded = java.net.URLEncoder.encode(clean, "UTF-8")
        val conn = (java.net.URL("https://autocomplete.clearbit.com/v1/companies/suggest?query=$encoded").openConnection() as java.net.HttpURLConnection).apply {
            connectTimeout = 3500
            readTimeout = 3500
            requestMethod = "GET"
        }
        if (conn.responseCode == 200) {
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = org.json.JSONArray(body)
            if (arr.length() > 0) {
                val obj = arr.getJSONObject(0)
                val dom = obj.optString("domain", "")
                val logo = obj.optString("logo", "")
                when {
                    dom.isNotBlank() -> "https://www.google.com/s2/favicons?domain=$dom&sz=128"
                    logo.isNotBlank() -> logo
                    else -> ""
                }
            } else ""
        } else ""
    }.getOrDefault("")
    BillIconSearchCache.map[cacheKey] = discovered
    return discovered.ifBlank { null }
}

@Composable
fun BankIconAvatar(
    bankOrAccountName: String,
    accountType: String = "Account",
    size: androidx.compose.ui.unit.Dp = 36.dp,
    modifier: Modifier = Modifier
) {
    val knownDomain = remember(bankOrAccountName) { bankDomainOrNull(bankOrAccountName) }
    val iconUrl by produceState<String?>(
        initialValue = knownDomain?.let { "https://www.google.com/s2/favicons?domain=$it&sz=128" },
        key1 = bankOrAccountName,
        key2 = knownDomain
    ) {
        value = withContext(Dispatchers.IO) { searchBankLogoOnTheFly(bankOrAccountName) }
    }
    var loaded by remember(iconUrl) { mutableStateOf(false) }
    val fallbackIcon = when {
        accountType.contains("card", true) -> Icons.Default.CreditCard
        accountType.contains("loan", true) -> Icons.Default.AccountBalanceWallet
        else -> Icons.Default.AccountBalance
    }
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.secondaryContainer,
        modifier = modifier.size(size)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            if (!loaded) {
                Icon(
                    imageVector = fallbackIcon,
                    contentDescription = bankOrAccountName,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(size * 0.58f)
                )
            }
            if (!iconUrl.isNullOrBlank()) {
                AsyncImage(
                    model = iconUrl,
                    contentDescription = "$bankOrAccountName logo",
                    onSuccess = { loaded = true },
                    onError = { loaded = false },
                    modifier = Modifier.size(size * 0.68f)
                )
            }
        }
    }
}

private data class BillVisualStyle(
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val tint: Color,
    val container: Color,
    val knownDomain: String? = null
)

private object BillIconSearchCache {
    val map = java.util.concurrent.ConcurrentHashMap<String, String>()
}

private fun resolveBillVisualStyle(b: Bill): BillVisualStyle {
    val text = "${b.title} ${b.bank} ${b.rawText}".lowercase(Locale.ROOT)
    val domain = when {
        "dewa" in text -> "dewa.gov.ae"
        "sewa" in text -> "sewa.gov.ae"
        "fewa" in text || "etihadwe" in text || "etihad water" in text -> "etihadwe.ae"
        "addc" in text -> "addc.ae"
        "empower" in text -> "empower.ae"
        "tabreed" in text -> "tabreed.ae"
        "emicool" in text -> "emicool.com"
        "sergas" in text -> "sergas.com"
        "lootah" in text -> "lootahbcgas.com"
        "etisalat" in text || "e&" in text -> "etisalat.ae"
        Regex("\\bdu\\b").containsMatchIn(text) -> "du.ae"
        "virgin mobile" in text || "virgin" in text -> "virginmobile.ae"
        "salik" in text -> "salik.ae"
        "darb" in text -> "darb.dmt.gov.ae"
        Regex("\\brta\\b").containsMatchIn(text) -> "rta.ae"
        "emirates nbd" in text || "enbd" in text -> "emiratesnbd.com"
        "adcb" in text || "abu dhabi commercial" in text -> "adcb.com"
        "fab" in text || "first abu dhabi" in text -> "bankfab.com"
        "mashreq" in text -> "mashreq.com"
        "dib" in text || "dubai islamic" in text -> "dib.ae"
        "adib" in text -> "adib.ae"
        "rakbank" in text || "rak bank" in text -> "rakbank.ae"
        "cbd" in text || "commercial bank of dubai" in text -> "cbd.ae"
        "hsbc" in text -> "hsbc.ae"
        "citi" in text -> "citi.com"
        "standard chartered" in text -> "sc.com"
        "dubai first" in text || "dubaifirst" in text -> "dubaifirst.com"
        "sbi" in text || "state bank" in text -> "sbi.co.in"
        "hdfc" in text -> "hdfcbank.com"
        "icici" in text -> "icicibank.com"
        "axis" in text -> "axisbank.com"
        "kotak" in text -> "kotak.com"
        "airtel" in text -> "airtel.in"
        Regex("\\bjio\\b").containsMatchIn(text) -> "jio.com"
        "vodafone" in text || Regex("\\bvi\\b").containsMatchIn(text) -> "myvi.in"
        "bescom" in text -> "bescom.karnataka.gov.in"
        "act fibernet" in text -> "actcorp.in"
        "netflix" in text -> "netflix.com"
        "spotify" in text -> "spotify.com"
        "youtube" in text -> "youtube.com"
        "disney" in text -> "disneyplus.com"
        "osn" in text -> "osn.com"
        "shahid" in text -> "shahid.mbc.net"
        "apple" in text || "icloud" in text -> "apple.com"
        "google" in text -> "google.com"
        "microsoft" in text || "office 365" in text || "xbox" in text -> "microsoft.com"
        "openai" in text || "chatgpt" in text -> "openai.com"
        "claude" in text || "anthropic" in text -> "anthropic.com"
        "amazon" in text || "prime" in text -> "amazon.ae"
        "noon" in text -> "noon.com"
        "careem" in text -> "careem.com"
        "talabat" in text -> "talabat.com"
        "carrefour" in text -> "carrefouruae.com"
        "lulu" in text -> "luluhypermarket.com"
        "tabby" in text -> "tabby.ai"
        "tamara" in text -> "tamara.co"
        "daman" in text -> "damanhealth.ae"
        "sukoon" in text -> "sukoon.com"
        "gems" in text -> "gemseducation.com"
        "gymnation" in text -> "gymnation.com"
        "fitness first" in text -> "fitnessfirstme.com"
        else -> null
    }
    return when {
        Regex("dewa|electric|power|bescom|electricity").containsMatchIn(text) ->
            BillVisualStyle(Icons.Default.Bolt, Color(0xFF00897B), Color(0xFFE0F2F1), domain)
        Regex("sewa|fewa|etihadwe|addc|water").containsMatchIn(text) ->
            BillVisualStyle(Icons.Default.WaterDrop, Color(0xFF0288D1), Color(0xFFE1F5FE), domain)
        Regex("empower|tabreed|emicool|chiller|cooling|district cooling|\bac\b").containsMatchIn(text) ->
            BillVisualStyle(Icons.Default.AcUnit, Color(0xFF039BE5), Color(0xFFE1F5FE), domain)
        Regex("sergas|lootah|\bgas\b|lpg|cooking gas").containsMatchIn(text) ->
            BillVisualStyle(Icons.Default.LocalFireDepartment, Color(0xFFD84315), Color(0xFFFBE9E7), domain)
        Regex("etisalat|e&|\bdu\b|virgin|airtel|\bjio\b|vodafone|act fibernet|internet|wifi|broadband|fiber|telecom").containsMatchIn(text) ->
            BillVisualStyle(Icons.Default.Router, Color(0xFF1565C0), Color(0xFFE3F2FD), domain)
        Regex("mobile|phone|postpaid|prepaid|sim|recharge").containsMatchIn(text) ->
            BillVisualStyle(Icons.Default.Smartphone, Color(0xFF1E88E5), Color(0xFFE3F2FD), domain)
        Regex("salik|darb|\brta\b|toll|parking|car loan|auto finance|vehicle|fuel|petrol").containsMatchIn(text) ->
            BillVisualStyle(Icons.Default.DirectionsCar, Color(0xFFE65100), Color(0xFFFFF3E0), domain)
        BillPayments.isCreditCardBill(b) || Regex("credit card|card bill|card statement|mastercard|visa|amex").containsMatchIn(text) ->
            BillVisualStyle(Icons.Default.CreditCard, Color(0xFF4527A0), Color(0xFFEDE7F6), domain)
        Regex("loan|emi|mortgage|installment|instalment|finance").containsMatchIn(text) ->
            BillVisualStyle(Icons.Default.AccountBalance, Color(0xFF283593), Color(0xFFE8EAF6), domain)
        Regex("rent|housing|ejari|maintenance|apartment|villa|home").containsMatchIn(text) ->
            BillVisualStyle(Icons.Default.Home, Color(0xFF2E7D32), Color(0xFFE8F5E9), domain)
        Regex("school|tuition|education|gems|university|college| nursery|kids|bus fee").containsMatchIn(text) ->
            BillVisualStyle(Icons.Default.School, Color(0xFF00695C), Color(0xFFE0F2F1), domain)
        b.isSubscription || Regex("netflix|spotify|youtube|disney|osn|shahid|prime|apple|icloud|google|microsoft|chatgpt|openai|subscription|membership").containsMatchIn(text) ->
            BillVisualStyle(Icons.Default.PlayCircleFilled, Color(0xFFC62828), Color(0xFFFFEBEE), domain)
        Regex("insurance|health|medical|daman|sukoon|clinic|hospital").containsMatchIn(text) ->
            BillVisualStyle(Icons.Default.HealthAndSafety, Color(0xFFC2185B), Color(0xFFFCE4EC), domain)
        Regex("gym|fitness|gymnation|sport|club").containsMatchIn(text) ->
            BillVisualStyle(Icons.Default.FitnessCenter, Color(0xFF6A1B9A), Color(0xFFF3E5F5), domain)
        Regex("tabby|tamara|noon|amazon|careem|talabat|carrefour|lulu|shopping").containsMatchIn(text) ->
            BillVisualStyle(Icons.Default.ShoppingBag, Color(0xFFF57F17), Color(0xFFFFFDE7), domain)
        else ->
            BillVisualStyle(Icons.Default.ReceiptLong, Color(0xFF455A64), Color(0xFFECEFF1), domain)
    }
}

private fun searchBillIconUrl(b: Bill, knownDomain: String?): String? {
    if (!knownDomain.isNullOrBlank()) {
        return "https://www.google.com/s2/favicons?domain=$knownDomain&sz=128"
    }
    val genericWords = setOf(
        "bill", "payment", "reminder", "monthly", "due", "statement", "credit", "card",
        "account", "bank", "manual", "pasted", "message", "subscription", "loan", "emi",
        "rent", "house", "home", "water", "electricity", "electric", "internet", "mobile",
        "phone", "school", "fees", "fee", "insurance", "gas", "other", "unknown", "aed", "inr", "usd"
    )
    val query = "${b.title} ${if (b.bank.equals("Manual", true) || b.bank.equals("Pasted message", true)) "" else b.bank}"
        .replace(Regex("[^A-Za-z0-9 ]"), " ")
        .split(Regex("\\s+"))
        .map { it.trim() }
        .filter { it.length >= 2 && it.lowercase(Locale.ROOT) !in genericWords && it.none(Char::isDigit) }
        .take(2)
        .joinToString(" ")
        .trim()
    if (query.length < 2) return null
    val cacheKey = query.lowercase(Locale.ROOT)
    BillIconSearchCache.map[cacheKey]?.let { cached -> return cached.ifBlank { null } }
    val discovered = runCatching {
        val encoded = java.net.URLEncoder.encode(query, "UTF-8")
        val conn = (java.net.URL("https://autocomplete.clearbit.com/v1/companies/suggest?query=$encoded").openConnection() as java.net.HttpURLConnection).apply {
            connectTimeout = 3500
            readTimeout = 3500
            requestMethod = "GET"
        }
        if (conn.responseCode == 200) {
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = org.json.JSONArray(body)
            if (arr.length() > 0) {
                val obj = arr.getJSONObject(0)
                val logo = obj.optString("logo", "")
                val dom = obj.optString("domain", "")
                when {
                    dom.isNotBlank() -> "https://www.google.com/s2/favicons?domain=$dom&sz=128"
                    logo.isNotBlank() -> logo
                    else -> ""
                }
            } else ""
        } else ""
    }.getOrDefault("")
    BillIconSearchCache.map[cacheKey] = discovered
    return discovered.ifBlank { null }
}

@Composable
private fun BillIconAvatar(b: Bill, modifier: Modifier = Modifier) {
    val style = remember(b.title, b.bank, b.rawText, b.isSubscription) { resolveBillVisualStyle(b) }
    val iconUrl by produceState<String?>(
        initialValue = style.knownDomain?.let { "https://www.google.com/s2/favicons?domain=$it&sz=128" },
        key1 = b.title,
        key2 = b.bank,
        key3 = style.knownDomain
    ) {
        value = withContext(Dispatchers.IO) { searchBillIconUrl(b, style.knownDomain) }
    }
    var imageLoaded by remember(iconUrl) { mutableStateOf(false) }
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = style.container,
        modifier = modifier.size(40.dp)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            if (!imageLoaded) {
                Icon(
                    imageVector = style.icon,
                    contentDescription = b.title,
                    tint = style.tint,
                    modifier = Modifier.size(22.dp)
                )
            }
            if (!iconUrl.isNullOrBlank()) {
                AsyncImage(
                    model = iconUrl,
                    contentDescription = "${b.title} icon",
                    onSuccess = { imageLoaded = true },
                    onError = { imageLoaded = false },
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}
fun notifAccess(c: Context) = NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)
fun smsGranted(c: Context) = ContextCompat.checkSelfPermission(c, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
fun readSmsGranted(c: Context) = ContextCompat.checkSelfPermission(c, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

private data class InferredBalance(val currency: String, val amount: Double)
private fun inferAvailableBalance(rows: List<Txn>): InferredBalance? {
    val labelFirst = Regex("""(?:available\s+balance|avail(?:able)?\.?|balance|bal\.?)\s*(?:is|:|=|-)?\s*(AED|DHS?|USD|EUR|GBP|INR|SAR|QAR|KWD|BHD|OMR)?\s*([\d,]+(?:\.\d{1,2})?)""", RegexOption.IGNORE_CASE)
    val numberFirst = Regex("""(AED|DHS?|USD|EUR|GBP|INR|SAR|QAR|KWD|BHD|OMR)\s*([\d,]+(?:\.\d{1,2})?)(?=.{0,35}(?:available\s+balance|balance|bal\b))""", RegexOption.IGNORE_CASE)
    return rows.sortedByDescending { it.timestamp }.firstNotNullOfOrNull { tx ->
        val raw = tx.rawText
        if (!Regex("""available\s+balance|available\s+bal|\bbalance\b|\bbal\.""", RegexOption.IGNORE_CASE).containsMatchIn(raw)) return@firstNotNullOfOrNull null
        val m = labelFirst.find(raw) ?: numberFirst.find(raw) ?: return@firstNotNullOfOrNull null
        val groups = m.groupValues
        val currency = groups.getOrNull(1).orEmpty().uppercase().let { if (it.startsWith("DH")) "AED" else it.ifBlank { tx.currency } }
        val amountIndex = if (groups.size > 2 && groups[2].isNotBlank()) 2 else 1
        val amount = groups.getOrNull(amountIndex)?.replace(",", "")?.toDoubleOrNull() ?: return@firstNotNullOfOrNull null
        InferredBalance(currency, amount)
    }
}

/** Bumps every time the app returns to the foreground, so permission status refreshes after visiting system settings. */
@Composable fun rememberResumeTick(): Int {
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) }
    }
    return tick
}

// ---------- shell ----------
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun MoneyApp() {
    val ctx = LocalContext.current; val db = remember { AppDb.get(ctx) }
    var rateVersion by remember { mutableIntStateOf(0) }
    var startupReady by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        Prefs.load(ctx)
        Prefs.seedProvidedHdfcBalance(ctx)
        rateVersion++
        // Don't show lists until duplicate cleanup and past card-payment reconciliation finish.
        try {
            withContext(Dispatchers.IO) { TransactionMaintenance.run(ctx) }
        } catch (_: Throwable) {
            // Don't block the app UI if the maintenance pass cannot complete.
        }
        startupReady = true
        if (runCatching { withContext(Dispatchers.IO) { ExchangeRates.refresh() } }.getOrDefault(false)) rateVersion++
    }
    var tab by remember { mutableIntStateOf(NavIntentState.targetTab.value ?: 0) }; var settings by remember { mutableStateOf(false) }
    val pendingNavTab = NavIntentState.targetTab.value
    LaunchedEffect(pendingNavTab) {
        if (pendingNavTab != null && pendingNavTab in 0..2) {
            settings = false
            tab = pendingNavTab
            NavIntentState.targetTab.value = null
        }
    }
    var launchTransactionAdd by remember { mutableStateOf(false) }
    var launchPasteMessage by remember { mutableStateOf(false) }
    var nameSetup by remember { mutableStateOf(Prefs.userName(ctx).isBlank()) }
    val scope = rememberCoroutineScope(); val snack = remember { SnackbarHostState() }
    var importing by remember { mutableStateOf(false) }
    var refreshing by remember { mutableStateOf(false) }
    var refreshToken by remember { mutableIntStateOf(0) }
    fun importNow() = scope.launch {
        importing = true
        val r = SmsImporter.run(ctx); Prefs.setImported(ctx); importing = false
        snack.showSnackbar(when {
            r == null -> "Couldn't read SMS. Check the SMS permission."
            r.first == 0 -> "No messages matched your sender IDs. Add them in Settings, then tap Import past SMS."
            else -> "Imported ${r.second} new items from ${r.first} bank messages"
        })
    }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.READ_SMS] == true && !Prefs.imported(ctx)) importNow()
    }
    LaunchedEffect(Unit) { perms.launch(arrayOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS, Manifest.permission.POST_NOTIFICATIONS)) }
    val tabs = listOf("Home" to Icons.Default.Home, "Transactions" to Icons.AutoMirrored.Filled.List, "Bills & Payments" to Icons.Default.DateRange)
    if (nameSetup) NameSetupDialog(
        initial = Prefs.userName(ctx),
        onSave = { name -> Prefs.saveUserName(ctx, name); nameSetup = false },
        onDismiss = { if (Prefs.userName(ctx).isNotBlank()) nameSetup = false }
    ) else if (settings) SettingsScreen { settings = false; if (Prefs.userName(ctx).isBlank()) nameSetup = true } else Scaffold(
        topBar = { TopAppBar(title = { Text(tabs[tab].first, fontWeight = FontWeight.SemiBold) },
            actions = {
                val remaining = YearMonth.now().lengthOfMonth() - LocalDate.now().dayOfMonth
                Text("$remaining days left this month", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                IconButton({ settings = true }) { Icon(Icons.Default.AccountCircle, "Profile and settings") }
            }) },
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = { NavigationBar { tabs.forEachIndexed { i, (n, ic) -> NavigationBarItem(tab == i, { tab = i }, { Icon(ic, n) }, label = { Text(n) }) } } }
    ) { pad ->
        val triggerRefresh: () -> Unit = {
            if (startupReady && !refreshing) {
                scope.launch {
                    refreshing = true
                    try {
                        if (readSmsGranted(ctx)) {
                            runCatching { SmsImporter.run(ctx) }
                        }
                        runCatching { withContext(Dispatchers.IO) { TransactionMaintenance.run(ctx) } }
                        if (runCatching { withContext(Dispatchers.IO) { ExchangeRates.refresh() } }.getOrDefault(false)) rateVersion++
                        refreshToken++
                    } finally {
                        refreshing = false
                    }
                }
            }
        }
        var swipeDistance by remember { mutableFloatStateOf(0f) }
        Column(Modifier.padding(pad).fillMaxSize()
            .pointerInput(tab, startupReady) {
            detectHorizontalDragGestures(onHorizontalDrag = { change, dragAmount ->
                swipeDistance += dragAmount
                change.consume()
            }, onDragEnd = {
                if (startupReady && kotlin.math.abs(swipeDistance) > 90f) {
                    if (swipeDistance < 0f) tab = (tab + 1).coerceAtMost(tabs.lastIndex)
                    else tab = (tab - 1).coerceAtLeast(0)
                }
                swipeDistance = 0f
            }, onDragCancel = { swipeDistance = 0f })
        }) {
            if (!startupReady) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        CircularProgressIndicator()
                        Text("Cleaning duplicate transactions…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                if (importing || refreshing) LinearProgressIndicator(Modifier.fillMaxWidth())
                AnimatedContent(
                    targetState = tab,
                    modifier = Modifier.weight(1f),
                    transitionSpec = {
                        val forward = targetState > initialState
                        (slideInHorizontally(tween(280)) { if (forward) it else -it } + androidx.compose.animation.fadeIn(tween(220))) togetherWith
                            (slideOutHorizontally(tween(280)) { if (forward) -it else it } + androidx.compose.animation.fadeOut(tween(180)))
                    }, label = "pageSwipe"
                ) { page ->
                    when (page) {
                        0 -> Dashboard(db, Modifier.fillMaxSize(), { tab = it }, rateVersion, refreshToken, isRefreshing = refreshing, onRefresh = triggerRefresh)
                        1 -> Transactions(db, Modifier.fillMaxSize(), rateVersion, launchTransactionAdd, { launchTransactionAdd = false }, launchPasteMessage, { launchPasteMessage = false }, refreshToken, isRefreshing = refreshing, onRefresh = triggerRefresh)
                        else -> Bills(db, Modifier.fillMaxSize(), onTransactions = { launchTransactionAdd = true; tab = 1 }, onPasteMessage = { launchPasteMessage = true; tab = 1 })
                    }
                }
            }
        }
    }
}

@Composable fun NameSetupDialog(initial: String = "", onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        title = { Text("Welcome to MoneyTracker") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("What should we call you on your home screen?")
            OutlinedTextField(name, { name = it }, label = { Text("Your name") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Person, null) })
        } },
        confirmButton = { Button(onClick = { name.trim().takeIf { it.isNotBlank() }?.let(onSave) }, enabled = name.isNotBlank()) { Text("Continue") } },
        dismissButton = { if (initial.isNotBlank()) TextButton(onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun BalanceEditor(
    title: String,
    initial: String,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit,
    currency: String = "AED",
    initialName: String = title,
    accountType: String = "Account",
    onSaveWithName: ((newName: String, newBalance: String) -> Unit)? = null
) {
    var nameValue by remember(title, initialName) { mutableStateOf(initialName) }
    var selectedBank by remember(title, initialName) {
        val match = knownBanksCatalog.firstOrNull { b -> initialName.contains(b.substringBefore(" ("), ignoreCase = true) }
        mutableStateOf(match ?: "")
    }
    var bankMenuExpanded by remember { mutableStateOf(false) }
    var value by remember(title) { mutableStateOf(initial) }
    val previewQuery = if (selectedBank.isNotBlank()) "$selectedBank $nameValue" else nameValue
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BankIconAvatar(bankOrAccountName = previewQuery, accountType = accountType, size = 40.dp)
                Column {
                    Text("Edit account / card", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Update name, bank icon & balance", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ExposedDropdownMenuBox(expanded = bankMenuExpanded, onExpandedChange = { bankMenuExpanded = !bankMenuExpanded }) {
                    OutlinedTextField(
                        value = selectedBank.ifBlank { "Choose bank (pulls icon on the fly)" },
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        label = { Text("Bank") },
                        leadingIcon = { BankIconAvatar(bankOrAccountName = previewQuery, accountType = accountType, size = 24.dp) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = bankMenuExpanded) },
                        singleLine = true
                    )
                    ExposedDropdownMenu(expanded = bankMenuExpanded, onDismissRequest = { bankMenuExpanded = false }, modifier = Modifier.heightIn(max = 320.dp)) {
                        knownBanksCatalog.forEach { bankOption ->
                            val cleanBank = bankOption.substringBefore(" (").trim()
                            DropdownMenuItem(
                                leadingIcon = { BankIconAvatar(bankOrAccountName = cleanBank, accountType = accountType, size = 24.dp) },
                                text = { Text(bankOption) },
                                onClick = {
                                    selectedBank = cleanBank
                                    if (nameValue.isBlank() || knownBanksCatalog.any { nameValue.startsWith(it.substringBefore(" ("), true) }) {
                                        val suffix = nameValue.substringAfter("·", "").trim()
                                        nameValue = if (suffix.isNotBlank()) "$cleanBank · $suffix" else cleanBank
                                    }
                                    bankMenuExpanded = false
                                }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = nameValue,
                    onValueChange = { nameValue = it },
                    label = { Text("Account / card display name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    label = { Text("Balance ($currency)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton({
                val cleanName = nameValue.trim().ifBlank { title }
                val cleanBal = value.trim().ifBlank { "0.00" }
                if (onSaveWithName != null) onSaveWithName(cleanName, cleanBal) else onSave(cleanBal)
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

// ---------- shared pieces ----------
@Composable fun SectionHeader(title: String, action: String? = null, onAction: () -> Unit = {}) =
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        if (action != null) TextButton(onAction) { Text(action) }
    }

@Composable fun Empty(t: String) = Text(t, Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable fun Avatar(name: String) {
    val hue = (name.hashCode().absoluteValue % 360).toFloat()
    Surface(shape = CircleShape, color = Color.hsv(hue, 0.45f, 0.70f), modifier = Modifier.size(40.dp)) {
        Box(contentAlignment = Alignment.Center) { Text(name.firstOrNull()?.uppercase() ?: "?", color = Color.White, fontWeight = FontWeight.Bold) }
    }
}

@Composable fun CategoryGlyph(category: String, modifier: Modifier = Modifier, tint: Color = MaterialTheme.colorScheme.primary) {
    val icon = when (category.trim().lowercase()) {
        "food and dining", "food", "dining" -> Icons.Default.Restaurant
        "education" -> Icons.Default.School
        "emi" -> Icons.Default.Payments
        "fuel" -> Icons.Default.LocalGasStation
        "groceries", "grocery" -> Icons.Default.ShoppingCart
        "health" -> Icons.Default.LocalHospital
        "house rent" -> Icons.Default.Home
        "investment" -> Icons.Default.TrendingUp
        "kids" -> Icons.Default.ChildCare
        "movies and subscriptions", "subscriptions" -> Icons.Default.Movie
        "shopping" -> Icons.Default.ShoppingBag
        "bills", "bills & utilities" -> Icons.Default.ReceiptLong
        "salary", "income" -> Icons.Default.AccountBalanceWallet
        "cash" -> Icons.Default.AttachMoney
        "card payment" -> Icons.Default.CreditCard
        "transport", "transportation" -> Icons.Default.DirectionsCar
        "unknown", "other" -> Icons.Default.HelpOutline
        else -> Icons.Default.Category
    }
    Icon(icon, contentDescription = category, tint = tint, modifier = modifier)
}

@Composable fun TxRow(t: Txn, pattern: String = "d MMM, HH:mm", onExclude: (() -> Unit)? = null, onEdit: (() -> Unit)? = null, rateVersion: Int = 0, onDelete: (() -> Unit)? = null, runningExpenseTotal: Double? = null) {
    val fmt = remember(pattern) { SimpleDateFormat(pattern, Locale.getDefault()) }
    val ctx = LocalContext.current
    val mainCurrency = Prefs.mainCurrency(ctx)
    val converted = remember(t.amount, t.currency, mainCurrency, rateVersion) { ExchangeRates.cachedRate(t.currency, mainCurrency)?.times(t.amount) }
    val credit = t.type == TxType.CREDIT
    var showSource by remember(t.id) { mutableStateOf(false) }
    var confirmDelete by remember(t.id) { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().clickable { if (onEdit != null) onEdit() else showSource = true }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            AsyncImage(model = bankLogoUrl(t.bank), contentDescription = "${t.bank} logo", modifier = Modifier.size(24.dp))
            Spacer(Modifier.height(2.dp))
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.size(21.dp)) {
                Box(contentAlignment = Alignment.Center) { CategoryGlyph(t.category, Modifier.size(14.dp), MaterialTheme.colorScheme.onSecondaryContainer) }
            }
        }
        Spacer(Modifier.width(10.dp))
        val userNote = remember(t.id, t.timestamp, t.amount, t.category) { Prefs.txNote(ctx, t.id) }
        Column(Modifier.weight(1f)) {
            Text(t.merchant ?: "Unknown", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(fmt.format(Date(t.timestamp)) + " · " + t.category + (if (t.account != null) " · " + t.accountLabel() else ""), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (userNote.isNotBlank()) {
                Text("📝 $userNote", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(if (onEdit != null) "Tap to edit" else "Tap to view captured message", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text((if (credit) "+" else "−") + if (t.currency.equals(mainCurrency, true) || converted == null) "${t.currency} %,.2f".format(t.amount) else "$mainCurrency %,.2f (${t.currency} %,.2f)".format(converted, t.amount), fontWeight = FontWeight.SemiBold,
                color = if (credit) Color(0xFF218A4A) else Color(0xFFC62828))
            if (runningExpenseTotal != null) Text("Expenses: $mainCurrency %,.2f".format(runningExpenseTotal), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { showSource = true }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.Info, "Original message", modifier = Modifier.size(17.dp)) }
            if (onDelete != null) IconButton(onClick = { confirmDelete = true }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.DeleteOutline, "Delete transaction", modifier = Modifier.size(17.dp), tint = MaterialTheme.colorScheme.error) }
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Delete transaction?") },
        text = { Text("${t.currency} %,.2f · ${t.merchant ?: t.category}. This cannot be undone.".format(t.amount)) },
        confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete?.invoke() }) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
    )
    if (showSource) AlertDialog(onDismissRequest = { showSource = false },
        title = { Text("Captured transaction") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${t.bank} · ${SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault()).format(Date(t.timestamp))}", style = MaterialTheme.typography.labelMedium)
            Text("Source: ${t.sourceType?.let { when { it.equals("NOTIFICATION", true) -> "Bank-app notification"; it.equals("SMS", true) -> "SMS"; it.equals("PASTED_NOTIFICATION", true) -> "Pasted SMS / notification"; else -> it } } ?: "Not recorded"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${t.type} · ${t.category} · ${t.currency} %,.2f".format(t.amount))
            Text("Original SMS / notification", fontWeight = FontWeight.SemiBold)
            SelectionContainer { Text(t.rawText.ifBlank { "Original message was not stored." }) }
        } }, confirmButton = { TextButton({ showSource = false }) { Text("Close") } },
        dismissButton = { if (onExclude != null) TextButton({ onExclude(); showSource = false }) { Text("Exclude future") } })
}

@Composable fun RowScope.Stat(label: String, v: Double, color: Color = Color.Unspecified) = Card(Modifier.weight(1f)) {
    Column(Modifier.padding(14.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("%,.2f".format(v), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, color = color)
    }
}

// ---------- Home ----------
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable fun Dashboard(db: AppDb, modifier: Modifier, goTo: (Int) -> Unit, rateVersion: Int = 0, refreshToken: Int = 0, isRefreshing: Boolean = false, onRefresh: () -> Unit = {}) {
    val ctx = LocalContext.current; val tick = rememberResumeTick(); val scope = rememberCoroutineScope()
    val recent by db.tx().recent(7).collectAsState(emptyList())
    val allCaptured by produceState(emptyList<Txn>(), recent, refreshToken) { value = withContext(Dispatchers.IO) { db.tx().between(0L, System.currentTimeMillis()) } }
    val bills by db.bills().pending().collectAsState(emptyList())
    val month by produceState(emptyList<Txn>(), recent, refreshToken) { val r = monthRange(0); value = db.tx().between(r.first, r.second) }
    val mainCurrency = Prefs.mainCurrency(ctx)
    fun mainAmount(t: Txn): Double = (ExchangeRates.cachedRate(t.currency, mainCurrency)?.times(t.amount)) ?: if (t.currency.equals(mainCurrency, true)) t.amount else 0.0
    val inn = month.filter { it.type == TxType.CREDIT && it.counts() }.sumOf { mainAmount(it) }
    val out = Insights.spend(month.map { it.copy(amount = mainAmount(it)) }).sumOf { it.amount }
    val cs = MaterialTheme.colorScheme; val net = inn - out
    val greeting = when (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) {
        in 5..11 -> "Good Morning"
        in 12..16 -> "Good Afternoon"
        else -> "Good Evening"
    }
    var cashWalletRefresh by remember { mutableIntStateOf(0) }
    val currentMonthForCash by produceState(emptyList<Txn>(), recent, refreshToken, cashWalletRefresh) { val r = monthRange(0); value = withContext(Dispatchers.IO) { db.tx().between(r.first, r.second) } }
    val liveCashBalance = remember(currentMonthForCash, mainCurrency, rateVersion) {
        computeLiveCashWalletBalance(currentMonthForCash, mainCurrency) { from, to -> ExchangeRates.cachedRate(from, to) }
    }
    var accountGroup by remember { mutableStateOf<String?>(null) }; var editAccount by remember { mutableStateOf<String?>(null) }; var cashWalletOpen by remember { mutableStateOf(false) }
    var showBudgetEditor by remember { mutableStateOf(false) }
    var budgetDraft by remember { mutableStateOf(Prefs.categoryBudgets(ctx)) }
    var budgetRefresh by remember { mutableIntStateOf(0) }
    var selectedBudgetCategory by remember { mutableStateOf<String?>(null) }
    var monthReviewOpen by remember { mutableStateOf(false) }
    val categoryBudgets = remember(budgetRefresh, showBudgetEditor, monthReviewOpen) { Prefs.categoryBudgets(ctx) }
    var reviewBudgetDraft by remember { mutableStateOf(Prefs.categoryBudgets(ctx)) }
    val monthKey = java.text.SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    LaunchedEffect(monthKey) { if (Prefs.reviewedMonth(ctx) != monthKey) monthReviewOpen = true }
    var showAddAccount by remember { mutableStateOf(false) }
    var newAccountType by remember { mutableStateOf("Home loan") }
    var newAccountName by remember { mutableStateOf("") }
    var accountStatus by remember { mutableStateOf<String?>(null) }
    var accountListRefresh by remember { mutableIntStateOf(0) }
    var editingCustomAccount by remember { mutableStateOf<Pair<String, String>?>(null) }
    var pendingDeleteCustomAccount by remember { mutableStateOf<String?>(null) }
    var pendingDeleteDetectedAccount by remember { mutableStateOf<Triple<String, String?, String>?>(null) }
    var customEditName by remember { mutableStateOf("") }
    var customEditType by remember { mutableStateOf("Bank & debit account") }
    var customEditError by remember { mutableStateOf<String?>(null) }
    val customAccounts = Prefs.customAccounts(ctx)
    val greetingTransition = androidx.compose.animation.core.rememberInfiniteTransition(label = "greetingGradient")
    val greetingShift by greetingTransition.animateFloat(initialValue = 0f, targetValue = 900f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(6500, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse), label = "greetingShift")
    val greetingBrush = Brush.linearGradient(
        colors = listOf(Color(0xFF00695C), Color(0xFF3949AB), Color(0xFF8E24AA), Color(0xFF00897B)),
        start = Offset(greetingShift, 0f), end = Offset(greetingShift + 650f, 160f))
    val access = remember(tick) { notifAccess(ctx) }
    // Keep remember() in the composable scope, not inside LazyListScope.
    val accts = remember(allCaptured, accountListRefresh) {
        allCaptured.filter { it.account != null && !Prefs.isDetectedAccountHidden(ctx, canonicalBankName(it.bank), it.kind, it.account.orEmpty()) }
            .map { "${canonicalBankName(it.bank)} · ${it.accountLabel()}" to (it.kind ?: "Account") }
            .distinctBy { it.first.lowercase() }
            .sortedBy { it.first }
    }
    var revealNet by remember { mutableStateOf(NetPrivacySession.revealed) }
    val netCounter = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(net) { netCounter.snapTo(0f); netCounter.animateTo(abs(net).toFloat(), androidx.compose.animation.core.tween(850)) }
    PullToRefreshBox(isRefreshing = isRefreshing, onRefresh = onRefresh, modifier = modifier.fillMaxSize()) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp).then(if (rateVersion < 0) Modifier.size(1.dp) else Modifier), contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Box(Modifier.fillMaxWidth().border(1.5.dp, Color.White.copy(alpha = 0.45f), RoundedCornerShape(16.dp)).background(greetingBrush, RoundedCornerShape(16.dp)).padding(horizontal = 18.dp, vertical = 16.dp)) {
                    val celestial = androidx.compose.animation.core.rememberInfiniteTransition(label = "dayNight")
                    val celestialDrift by celestial.animateFloat(initialValue = -5f, targetValue = 5f, animationSpec = androidx.compose.animation.core.infiniteRepeatable(animation = androidx.compose.animation.core.tween(1800), repeatMode = androidx.compose.animation.core.RepeatMode.Reverse), label = "celestialDrift")
                    val isDay = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) in 6..17
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("$greeting ${Prefs.userName(ctx).ifBlank { "there" }}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = Color.White)
                            Text("Your money, in focus.", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.92f))
                        }
                        Icon(if (isDay) Icons.Default.WbSunny else Icons.Default.Nightlight,
                            contentDescription = if (isDay) "Sun" else "Moon",
                            tint = if (isDay) Color(0xFFFFE082) else Color(0xFFE1E8FF),
                            modifier = Modifier.offset(y = celestialDrift.dp).size(38.dp))
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("This month, net", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        IconButton(onClick = { revealNet = !revealNet; NetPrivacySession.revealed = revealNet }) { Icon(if (revealNet) Icons.Default.Visibility else Icons.Default.VisibilityOff, contentDescription = if (revealNet) "Hide net amount" else "Show net amount") }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (revealNet) (if (net < 0) "−" else "+") + "$mainCurrency %,.2f".format(netCounter.value) else "••••••", style = MaterialTheme.typography.headlineSmall, fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold, color = if (net >= 0) Color(0xFF218838) else Color(0xFFD93025))
                        Icon(if (net >= 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown, contentDescription = if (net >= 0) "Net up" else "Net down", tint = if (net >= 0) Color(0xFF218838) else Color(0xFFD93025))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text("Total income", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                            Text(if (revealNet) "$mainCurrency ${"%,.2f".format(inn)}" else "••••••", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF218838), maxLines = 1)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Total expense", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                            Text(if (revealNet) "$mainCurrency ${"%,.2f".format(out)}" else "••••••", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFFD93025), maxLines = 1)
                        }
                    }
                }
            }
        }
        if (!access) item {
            Card(colors = CardDefaults.cardColors(containerColor = cs.errorContainer, contentColor = cs.onErrorContainer)) {
                Row(Modifier.padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Notification access is off, so bank app notifications aren't being read.", Modifier.weight(1f))
                    TextButton({ ctx.startActivity(Intent(AS.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) { Text("Enable") }
                }
            }
        }
        item {
            val budget = remember(budgetRefresh, showBudgetEditor, monthReviewOpen) { Prefs.monthlyBudget(ctx).toDoubleOrNull() ?: 0.0 }
            if (budget >= 0) {
                val progress = if (budget > 0) (out / budget).toFloat().coerceIn(0f, 1f) else 0f
                val animatedBudgetProgress by animateFloatAsState(targetValue = progress, animationSpec = tween(durationMillis = 900), label = "monthlyBudgetProgress")
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth().clickable { budgetDraft = Prefs.categoryBudgets(ctx); showBudgetEditor = true }, verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Savings, null, tint = cs.primary); Spacer(Modifier.width(8.dp)); Text("Monthly budget", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold); TextButton(onClick = { budgetDraft = Prefs.categoryBudgets(ctx); showBudgetEditor = true }) { Text("Edit") }; Text("${(progress * 100).toInt()}%", color = if (out > budget) cs.error else cs.primary) }
                    LinearProgressIndicator(progress = { animatedBudgetProgress }, modifier = Modifier.fillMaxWidth(), color = if (out > budget) cs.error else cs.primary)
                    Text("Spent %,.2f of %,.2f".format(out, budget) + if (out > budget) " · over budget" else "", style = MaterialTheme.typography.bodySmall)
                    if (categoryBudgets.isNotEmpty()) {
                        HorizontalDivider()
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Category budgets", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text("Tap a category for monthly note", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        }
                        categoryBudgets.forEach { (category, limitText) ->
                            val limit = limitText.replace(",", "").toDoubleOrNull() ?: 0.0
                            if (limit > 0) {
                                val aliases = when (category.lowercase()) {
                                    "food and dining" -> setOf("food and dining", "food", "dining", "restaurants")
                                    "education" -> setOf("education", "school fees")
                                    "emi" -> setOf("emi", "loan", "loan repayment")
                                    "fuel" -> setOf("fuel", "transportation", "petrol")
                                    "groceries" -> setOf("groceries", "grocery")
                                    "health" -> setOf("health", "medical")
                                    "house rent" -> setOf("house rent", "rent")
                                    "investment" -> setOf("investment", "investments")
                                    "kids" -> setOf("kids", "children")
                                    "movies and subscriptions" -> setOf("movies and subscriptions", "entertainment", "subscriptions")
                                    "shopping" -> setOf("shopping")
                                    "bills" -> setOf("bills", "bills & utilities", "utilities")
                                    else -> setOf(category.lowercase())
                                }
                                val spent = month.filter { it.type == TxType.DEBIT && it.counts() && it.category.lowercase() in aliases }.sumOf(::mainAmount)
                                val ratio = (spent / limit).toFloat().coerceIn(0f, 1f)
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(cs.surfaceVariant.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                                        .clickable { selectedBudgetCategory = category }
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        CategoryGlyph(category, Modifier.size(16.dp), cs.primary)
                                        Spacer(Modifier.width(6.dp))
                                        Text(category, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                                        Text("%,.0f / %,.0f".format(spent, limit), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, color = if (spent > limit) cs.error else cs.onSurfaceVariant)
                                        Spacer(Modifier.width(4.dp))
                                        Icon(Icons.Default.ChevronRight, contentDescription = "View $category transactions", modifier = Modifier.size(15.dp), tint = cs.onSurfaceVariant)
                                    }
                                    LinearProgressIndicator(progress = { ratio }, modifier = Modifier.fillMaxWidth(), color = if (spent > limit) cs.error else cs.secondary)
                                }
                            }
                        }
                    }
                } }
            }
        }
        item { SectionHeader("Accounts") }
        item { Text("Manage bank and debit accounts, credit cards, and home or car loans. Detected accounts are grouped by unique bank and last four digits.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
        item {
            Card(Modifier.fillMaxWidth().clickable { cashWalletOpen = true }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AttachMoney, null, tint = cs.primary, modifier = Modifier.size(28.dp))
                    Column(Modifier.weight(1f).padding(start = 10.dp)) { Text("Cash wallet (this month)", fontWeight = FontWeight.SemiBold); Text("Live balance from this month's withdrawals & cash spend", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
                    Text((if (liveCashBalance < 0) "−" else "") + "$mainCurrency %,.2f".format(abs(liveCashBalance)), fontWeight = FontWeight.Bold, color = if (liveCashBalance < 0) cs.error else Color.Unspecified)
                    Icon(Icons.Default.ChevronRight, "Open cash wallet", tint = cs.primary)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(Triple("Bank & debit", "Accounts", Icons.Default.AccountBalance), Triple("Credit cards", "Credit card", Icons.Default.CreditCard), Triple("Loans", "Loans", Icons.Default.AccountBalanceWallet)).forEach { (label, group, ico) ->
                    Card(Modifier.weight(1f).heightIn(min = 132.dp).clickable { accountGroup = group }) {
                        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Icon(ico, contentDescription = null, tint = cs.primary, modifier = Modifier.size(25.dp))
                            Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            Text(when(group) { "Accounts" -> "${accts.count { !it.second.contains("card", true) && !it.second.contains("loan", true) }} detected"; "Credit card" -> "${allCaptured.filter { (it.kind ?: "").contains("card", true) && it.account != null }.map { "${it.bank.lowercase()}|${it.account}" }.distinct().size + customAccounts.count { it.first.contains("card", true) }} added/detected"; else -> "${customAccounts.count { it.first.contains("loan", true) }} added · Home & car" }, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                            Text("＋ Add", style = MaterialTheme.typography.labelMedium, color = cs.primary, modifier = Modifier.clickable { newAccountType = when(group) { "Accounts" -> "Bank & debit account"; "Credit card" -> "Credit card"; else -> "Home loan" }; newAccountName = ""; accountStatus = null; showAddAccount = true })
                        }
                    }
                }
            }
        }
        if (customAccounts.isNotEmpty()) item {
            Text("Your custom accounts", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                customAccounts.forEach { (type, name) ->
                    val balance = Prefs.manualBalance(ctx, name) ?: "0.00"
                    Card(Modifier.fillMaxWidth().clickable { editingCustomAccount = type to name; customEditType = type; customEditName = name; customEditError = null }) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            BankIconAvatar(bankOrAccountName = name, accountType = type, size = 36.dp)
                            Column(Modifier.weight(1f).padding(start = 10.dp)) { Text(name, fontWeight = FontWeight.SemiBold); Text(type, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
                            Text("${Prefs.manualBalanceCurrency(ctx, name) ?: mainCurrency} $balance", fontWeight = FontWeight.SemiBold)
                            IconButton(onClick = { editingCustomAccount = type to name; customEditType = type; customEditName = name; customEditError = null }) { Icon(Icons.Default.Edit, "Edit account") }
                            IconButton(onClick = { pendingDeleteCustomAccount = name }) { Icon(Icons.Default.DeleteOutline, "Remove account", tint = cs.error) }
                        }
                    }
                }
            }
        }
        item {
            val urgentBills = bills.filter { it.daysLeft()?.let { d -> d in 0..7 } == true }.take(5)
            if (urgentBills.isNotEmpty()) {
                val blink = androidx.compose.animation.core.rememberInfiniteTransition(label = "upcomingBillsBlink")
                val alpha by blink.animateFloat(initialValue = 0.45f, targetValue = 1f, animationSpec = androidx.compose.animation.core.infiniteRepeatable(animation = androidx.compose.animation.core.tween(700), repeatMode = androidx.compose.animation.core.RepeatMode.Reverse), label = "billBlink")
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.NotificationsActive, null, tint = cs.error.copy(alpha = alpha))
                    Column(Modifier.weight(1f)) { SectionHeader("Upcoming bills · next 7 days", "See all") { goTo(2) } }
                }
                urgentBills.forEach { b -> BillRow(b, act = { status -> scope.launch { withContext(Dispatchers.IO) { BillPayments.setStatus(db, b, status) } } }) }
            }
        }
        item { SectionHeader("Recent transactions", "See all") { goTo(1) } }
        if (recent.isEmpty()) item { Empty("No transactions captured yet") }
        else item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(horizontal = 16.dp)) {
            recent.forEachIndexed { i, t -> if (i > 0) HorizontalDivider(color = cs.outlineVariant); TxRow(t, rateVersion = rateVersion) }
        } } }
    }
    }
    if (showAddAccount) {
        var expandedType by remember { mutableStateOf(false) }
        var expandedBank by remember { mutableStateOf(false) }
        var selectedBank by remember { mutableStateOf("") }
        var initialBalance by remember { mutableStateOf("0.00") }
        val previewQuery = if (selectedBank.isNotBlank()) "$selectedBank $newAccountName" else newAccountName
        AlertDialog(
            onDismissRequest = { showAddAccount = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BankIconAvatar(bankOrAccountName = previewQuery, accountType = newAccountType, size = 40.dp)
                    Column {
                        Text("Add account or credit card", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Choose a bank to pull its icon on the fly", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    }
                }
            },
            text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box {
                    OutlinedTextField(value = newAccountType, onValueChange = {}, readOnly = true, enabled = false, label = { Text("Account type") }, trailingIcon = { Icon(Icons.Default.ArrowDropDown, null) }, modifier = Modifier.fillMaxWidth())
                    Box(Modifier.matchParentSize().clickable { expandedType = true })
                    DropdownMenu(expanded = expandedType, onDismissRequest = { expandedType = false }) {
                        listOf("Bank & debit account", "Credit card", "Home loan", "Car loan", "Personal loan", "Other loan").forEach { type -> DropdownMenuItem(text = { Text(type) }, onClick = { newAccountType = type; expandedType = false }) }
                    }
                }
                ExposedDropdownMenuBox(expanded = expandedBank, onExpandedChange = { expandedBank = !expandedBank }) {
                    OutlinedTextField(
                        value = selectedBank.ifBlank { "Choose bank (optional)" },
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        label = { Text("Bank name (pulls icon)") },
                        leadingIcon = { BankIconAvatar(bankOrAccountName = previewQuery, accountType = newAccountType, size = 24.dp) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedBank) },
                        singleLine = true
                    )
                    ExposedDropdownMenu(expanded = expandedBank, onDismissRequest = { expandedBank = false }, modifier = Modifier.heightIn(max = 300.dp)) {
                        knownBanksCatalog.forEach { bankOption ->
                            val cleanBank = bankOption.substringBefore(" (").trim()
                            DropdownMenuItem(
                                leadingIcon = { BankIconAvatar(bankOrAccountName = cleanBank, accountType = newAccountType, size = 24.dp) },
                                text = { Text(bankOption) },
                                onClick = {
                                    selectedBank = cleanBank
                                    if (newAccountName.isBlank() || knownBanksCatalog.any { newAccountName.startsWith(it.substringBefore(" ("), true) }) {
                                        newAccountName = "$cleanBank · ${if (newAccountType.contains("card", true)) "Card" else "Account"}"
                                    }
                                    expandedBank = false
                                }
                            )
                        }
                    }
                }
                OutlinedTextField(value = newAccountName, onValueChange = { newAccountName = it; accountStatus = null }, label = { Text("Display name (e.g. Emirates NBD ••1234)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = initialBalance, onValueChange = { initialBalance = it }, label = { Text("Starting balance ($mainCurrency)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                accountStatus?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }
            } }, confirmButton = { TextButton(onClick = {
                val cleanName = newAccountName.trim()
                val detectedDuplicate = allCaptured.any { tx ->
                    cleanName.equals("${tx.bank} · ${tx.accountLabel()}", true) ||
                        cleanName.equals(tx.accountLabel(), true)
                }
                val saved = !detectedDuplicate && Prefs.addCustomAccount(ctx, newAccountType, cleanName)
                if (saved) { Prefs.saveManualBalance(ctx, cleanName, initialBalance.trim().ifBlank { "0.00" }); accountListRefresh++; showAddAccount = false }
                else accountStatus = "Enter a name that is not already used by another account, card, or detected account."
            }) { Text("Add") } }, dismissButton = { TextButton(onClick = { showAddAccount = false }) { Text("Cancel") } })
    }
    accountGroup?.let { group ->
        val matching = allCaptured.filter { tx ->
            val k = (tx.kind ?: "Account").lowercase()
            when (group) {
                "Credit card" -> k.contains("card") || tx.category.equals("Card payment", true)
                "Cash" -> tx.type == TxType.DEBIT && (tx.category.equals("Cash", true) || Regex("\\batm\\b|cash withdrawal", RegexOption.IGNORE_CASE).containsMatchIn(tx.rawText))
                "Accounts" -> !k.contains("loan") && !k.contains("card")
                "Loans" -> k.contains("loan") || k.contains("mortgage")
                "Car loan" -> k.contains("car") && k.contains("loan")
                else -> false
            }
        }
        val accountRows = matching.filter { it.account != null && !Prefs.isDetectedAccountHidden(ctx, canonicalBankName(it.bank), it.kind, it.account.orEmpty()) }.groupBy { tx ->
            val normalizedKind = when (group) { "Credit card" -> "CARD"; "Loans" -> "LOAN"; else -> "BANK" }
            "${canonicalBankName(tx.bank).lowercase()}|$normalizedKind|${tx.account}"
        }
            .values.mapNotNull { rows ->
                val latest = rows.maxByOrNull { it.timestamp } ?: return@mapNotNull null
                val last4 = latest.account ?: return@mapNotNull null
                val label = "${canonicalBankName(latest.bank)} · ${latest.kind ?: "Account"} ••$last4"
                val inferred = inferAvailableBalance(rows)
                val stored = Prefs.manualBalance(ctx, label) ?: Prefs.manualBalance(ctx, latest.accountLabel())
                val storedCurrency = Prefs.manualBalanceCurrency(ctx, label) ?: mainCurrency
                Triple(latest, label, inferred?.let { "${it.currency} %,.2f".format(it.amount) } ?: stored?.takeIf { it.isNotBlank() }?.let { "$storedCurrency $it" } ?: "$mainCurrency 0.00")
            }.sortedBy { it.second }
        val subscriptions = if (group == "Accounts") bills.filter { it.isSubscription }.map { "Subscription · ${it.title}" } else emptyList()
        AlertDialog(onDismissRequest = { accountGroup = null }, title = { Text(when (group) { "Cash" -> "Cash & ATM withdrawals"; "Credit card" -> "Credit cards"; "Accounts" -> "Bank accounts"; else -> group }) },
            text = { Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (group == "Cash") {
                    val cashRows = matching.take(8)
                    if (cashRows.isEmpty()) Text("No ATM withdrawals found yet.")
                    cashRows.forEach { tx ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AttachMoney, null, tint = cs.primary)
                            Column(Modifier.weight(1f).padding(start = 8.dp)) { Text(tx.bank, fontWeight = FontWeight.SemiBold); Text("${tx.currency} ${"%,.2f".format(tx.amount)} · ${SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(tx.timestamp))}", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                } else if (accountRows.isEmpty() && subscriptions.isEmpty() && customAccounts.none { (type, _) ->
                    when (group) { "Credit card" -> type.contains("card", true); "Loans" -> type.contains("loan", true); "Accounts" -> !type.contains("card", true) && !type.contains("loan", true); else -> false }
                }) {
                    Text("No accounts have been detected yet. You can add a starting balance below.")
                    TextButton(onClick = { editAccount = group; accountGroup = null }) { Text("Set starting balance") }
                } else {
                    customAccounts.filter { (type, _) -> when (group) { "Credit card" -> type.contains("card", true); "Loans" -> type.contains("loan", true); "Accounts" -> !type.contains("card", true) && !type.contains("loan", true); else -> false } }.forEach { (type, name) ->
                        Card(Modifier.fillMaxWidth().clickable { editingCustomAccount = type to name; customEditType = type; customEditName = name; customEditError = null; accountGroup = null }) {
                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                BankIconAvatar(bankOrAccountName = name, accountType = type, size = 34.dp)
                                Column(Modifier.weight(1f).padding(horizontal = 10.dp)) { Text(name, fontWeight = FontWeight.SemiBold); Text(type, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant); Text("${Prefs.manualBalanceCurrency(ctx, name) ?: mainCurrency} ${Prefs.manualBalance(ctx, name) ?: "0.00"}", color = cs.primary, style = MaterialTheme.typography.labelMedium) }
                                Icon(Icons.Default.Edit, contentDescription = "Edit account", tint = cs.primary)
                            }
                        }
                    }
                    accountRows.forEach { (latest, label, amountLabel) ->
                        val canonicalBank = canonicalBankName(latest.bank)
                        val customDisplayName = Prefs.detectedAccountCustomName(ctx, canonicalBank, latest.kind, latest.account.orEmpty())
                        val shownTitle = customDisplayName ?: canonicalBank
                        val inferred = inferAvailableBalance(matching.filter { it.bank == latest.bank && it.account == latest.account })
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth().clickable { editAccount = label; accountGroup = null }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                BankIconAvatar(bankOrAccountName = "$shownTitle ${latest.bank}", accountType = latest.kind ?: "Account", size = 34.dp)
                                Column(Modifier.weight(1f).padding(horizontal = 9.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(shownTitle, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                    Text("${latest.kind ?: "Account"} · ending ${latest.account}", style = MaterialTheme.typography.bodySmall)
                                    Text(if (inferred == null && Prefs.manualBalance(ctx, label).isNullOrBlank()) "$mainCurrency 0.00 · tap to edit name & balance" else amountLabel, style = MaterialTheme.typography.labelMedium, color = cs.primary, fontWeight = FontWeight.SemiBold)
                                }
                                IconButton(onClick = { pendingDeleteDetectedAccount = Triple(canonicalBank, latest.kind, latest.account.orEmpty()); accountGroup = null }) { Icon(Icons.Default.DeleteOutline, contentDescription = "Remove account", tint = cs.error) }
                                Icon(Icons.Default.Edit, contentDescription = "Edit name & balance", tint = cs.primary)
                            }
                        }
                    }
                    subscriptions.forEach { sub -> Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Autorenew, null, tint = cs.primary); Spacer(Modifier.width(10.dp)); Text(sub) } }
                    Text("Balances come from captured available-balance messages when present; otherwise they start at zero until you update them.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            } }, confirmButton = { TextButton({ accountGroup = null }) { Text("Done") } })
    }
    pendingDeleteCustomAccount?.let { name ->
        AlertDialog(onDismissRequest = { pendingDeleteCustomAccount = null },
            title = { Text("Delete account?") },
            text = { Text("Remove $name and its saved balance from Accounts? Existing transactions will remain in your history.") },
            confirmButton = { TextButton(onClick = { Prefs.removeCustomAccount(ctx, name); accountListRefresh++; pendingDeleteCustomAccount = null }) { Text("Delete", color = cs.error) } },
            dismissButton = { TextButton(onClick = { pendingDeleteCustomAccount = null }) { Text("Cancel") } })
    }
    pendingDeleteDetectedAccount?.let { (bank, kind, last4) ->
        AlertDialog(onDismissRequest = { pendingDeleteDetectedAccount = null },
            title = { Text("Remove detected account?") },
            text = { Text("Hide $bank ${kind ?: "account"} ending $last4 from Accounts and card selectors? Existing transactions will remain in your history.") },
            confirmButton = { TextButton(onClick = { Prefs.hideDetectedAccount(ctx, bank, kind, last4); accountListRefresh++; pendingDeleteDetectedAccount = null; accountGroup = null }) { Text("Remove", color = cs.error) } },
            dismissButton = { TextButton(onClick = { pendingDeleteDetectedAccount = null }) { Text("Cancel") } })
    }
    editingCustomAccount?.let { (oldType, oldName) ->
        var expandedCustomType by remember(oldName) { mutableStateOf(false) }
        var expandedCustomBank by remember(oldName) { mutableStateOf(false) }
        var customSelectedBank by remember(oldName) {
            val match = knownBanksCatalog.firstOrNull { b -> oldName.contains(b.substringBefore(" ("), ignoreCase = true) }
            mutableStateOf(match?.substringBefore(" (") ?: "")
        }
        var customBalanceText by remember(oldName) { mutableStateOf(Prefs.manualBalance(ctx, oldName) ?: "0.00") }
        val previewQuery = if (customSelectedBank.isNotBlank()) "$customSelectedBank $customEditName" else customEditName
        AlertDialog(
            onDismissRequest = { editingCustomAccount = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BankIconAvatar(bankOrAccountName = previewQuery, accountType = customEditType, size = 40.dp)
                    Column {
                        Text("Edit account / card", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Choose bank to pull icon on the fly", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    }
                }
            },
            text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box {
                    OutlinedTextField(value = customEditType, onValueChange = {}, readOnly = true, enabled = false, label = { Text("Account type") }, trailingIcon = { Icon(Icons.Default.ArrowDropDown, null) }, modifier = Modifier.fillMaxWidth())
                    Box(Modifier.matchParentSize().clickable { expandedCustomType = true })
                    DropdownMenu(expanded = expandedCustomType, onDismissRequest = { expandedCustomType = false }) {
                        listOf("Bank & debit account", "Credit card", "Home loan", "Car loan", "Personal loan", "Other loan").forEach { type -> DropdownMenuItem(text = { Text(type) }, onClick = { customEditType = type; expandedCustomType = false }) }
                    }
                }
                ExposedDropdownMenuBox(expanded = expandedCustomBank, onExpandedChange = { expandedCustomBank = !expandedCustomBank }) {
                    OutlinedTextField(
                        value = customSelectedBank.ifBlank { "Choose bank (pulls icon on the fly)" },
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        label = { Text("Bank") },
                        leadingIcon = { BankIconAvatar(bankOrAccountName = previewQuery, accountType = customEditType, size = 24.dp) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCustomBank) },
                        singleLine = true
                    )
                    ExposedDropdownMenu(expanded = expandedCustomBank, onDismissRequest = { expandedCustomBank = false }, modifier = Modifier.heightIn(max = 300.dp)) {
                        knownBanksCatalog.forEach { bankOption ->
                            val cleanBank = bankOption.substringBefore(" (").trim()
                            DropdownMenuItem(
                                leadingIcon = { BankIconAvatar(bankOrAccountName = cleanBank, accountType = customEditType, size = 24.dp) },
                                text = { Text(bankOption) },
                                onClick = {
                                    customSelectedBank = cleanBank
                                    val suffix = customEditName.substringAfter("·", "").trim()
                                    customEditName = if (suffix.isNotBlank()) "$cleanBank · $suffix" else cleanBank
                                    customEditError = null
                                    expandedCustomBank = false
                                }
                            )
                        }
                    }
                }
                OutlinedTextField(customEditName, { customEditName = it; customEditError = null }, label = { Text("Account / card name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(customBalanceText, { customBalanceText = it }, label = { Text("Balance (${Prefs.manualBalanceCurrency(ctx, oldName) ?: mainCurrency})") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                customEditError?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }
            } }, confirmButton = { TextButton(onClick = {
                val targetName = customEditName.trim()
                if (Prefs.updateCustomAccount(ctx, oldName, customEditType, targetName)) {
                    Prefs.saveManualBalance(ctx, targetName, customBalanceText.trim().ifBlank { "0.00" }, Prefs.manualBalanceCurrency(ctx, targetName) ?: mainCurrency)
                    accountListRefresh++
                    editingCustomAccount = null
                } else customEditError = "Name is blank or already used by another account."
            }) { Text("Save changes") } }, dismissButton = { TextButton(onClick = { editingCustomAccount = null }) { Text("Cancel") } })
    }
    if (showBudgetEditor) AlertDialog(
        onDismissRequest = { showBudgetEditor = false }, title = { Text("Edit monthly budget") },
        text = { Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Set a limit for each category. The monthly budget is calculated from the values entered.", style = MaterialTheme.typography.bodySmall)
            ExpenseCategories.names.forEach { category -> OutlinedTextField(value = budgetDraft[category].orEmpty(), onValueChange = { v -> budgetDraft = budgetDraft + (category to v.filter { it.isDigit() || it == '.' || it == ',' }) }, label = { Text(category) }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            Text("Total: $mainCurrency %,.2f".format(budgetDraft.values.mapNotNull { it.replace(",", "").toDoubleOrNull() }.sum()), fontWeight = FontWeight.SemiBold)
        } }, confirmButton = { TextButton(onClick = {
            val valid = budgetDraft.values.all { it.isBlank() || (it.replace(",", "").toDoubleOrNull()?.let { n -> n >= 0 } == true) }
            if (valid) { val total = Prefs.saveCategoryBudgets(ctx, budgetDraft); Prefs.saveMonthlyBudget(ctx, total.toString()); budgetRefresh++; showBudgetEditor = false }
        }) { Text("Save budget") } }, dismissButton = { TextButton(onClick = { showBudgetEditor = false }) { Text("Cancel") } })
    selectedBudgetCategory?.let { cat ->
        val aliases = when (cat.lowercase()) {
            "food and dining" -> setOf("food and dining", "food", "dining", "restaurants")
            "education" -> setOf("education", "school fees")
            "emi" -> setOf("emi", "loan", "loan repayment")
            "fuel" -> setOf("fuel", "transportation", "petrol")
            "groceries" -> setOf("groceries", "grocery")
            "health" -> setOf("health", "medical")
            "house rent" -> setOf("house rent", "rent")
            "investment" -> setOf("investment", "investments")
            "kids" -> setOf("kids", "children")
            "movies and subscriptions" -> setOf("movies and subscriptions", "entertainment", "subscriptions")
            "shopping" -> setOf("shopping")
            "bills" -> setOf("bills", "bills & utilities", "utilities")
            else -> setOf(cat.lowercase())
        }
        val catTxs = remember(month, cat) {
            month.filter { it.type == TxType.DEBIT && it.counts() && it.category.lowercase() in aliases }
                .sortedByDescending { it.timestamp }
        }
        val usedAmount = remember(catTxs, mainCurrency, rateVersion) { catTxs.sumOf(::mainAmount) }
        val currentMap = remember(budgetRefresh, cat) { Prefs.categoryBudgets(ctx) }
        val currentLimit = currentMap[cat]?.replace(",", "")?.toDoubleOrNull() ?: 0.0
        var editingLimit by remember(cat) { mutableStateOf(false) }
        var limitInput by remember(cat, currentLimit) { mutableStateOf(if (currentLimit > 0) "%.0f".format(Locale.US, currentLimit) else "") }
        val noteDateFmt = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
        AlertDialog(
            onDismissRequest = { selectedBudgetCategory = null },
            title = {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CategoryGlyph(cat, Modifier.size(22.dp), cs.primary)
                        Column {
                            Text(cat, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Monthly glance note", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        }
                    }
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (currentLimit > 0 && usedAmount > currentLimit) cs.errorContainer else cs.primaryContainer,
                        border = BorderStroke(1.dp, if (currentLimit > 0 && usedAmount > currentLimit) cs.error.copy(alpha = 0.5f) else cs.primary.copy(alpha = 0.4f)),
                        modifier = Modifier.clickable { editingLimit = !editingLimit }
                    ) {
                        Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), horizontalAlignment = Alignment.End) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "$mainCurrency %,.0f / %,.0f".format(usedAmount, currentLimit),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (currentLimit > 0 && usedAmount > currentLimit) cs.onErrorContainer else cs.onPrimaryContainer
                                )
                                Icon(Icons.Default.Edit, contentDescription = "Edit budget", modifier = Modifier.size(13.dp), tint = if (currentLimit > 0 && usedAmount > currentLimit) cs.onErrorContainer else cs.onPrimaryContainer)
                            }
                            Text(
                                text = "Used / Set · Tap to edit",
                                style = MaterialTheme.typography.labelSmall,
                                color = (if (currentLimit > 0 && usedAmount > currentLimit) cs.onErrorContainer else cs.onPrimaryContainer).copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            },
            text = {
                Column(Modifier.heightIn(max = 500.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AnimatedVisibility(visible = editingLimit) {
                        Card(colors = CardDefaults.cardColors(containerColor = cs.secondaryContainer), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Edit $cat monthly budget ($mainCurrency)", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = limitInput,
                                        onValueChange = { v -> limitInput = v.filter { it.isDigit() || it == '.' || it == ',' } },
                                        label = { Text("Budget ($mainCurrency)") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Button(onClick = {
                                        val parsed = limitInput.replace(",", "").toDoubleOrNull()
                                        if (parsed != null && parsed >= 0) {
                                            val updatedMap = Prefs.categoryBudgets(ctx).toMutableMap()
                                            updatedMap[cat] = if (parsed == 0.0) "" else parsed.toString()
                                            val total = Prefs.saveCategoryBudgets(ctx, updatedMap)
                                            Prefs.saveMonthlyBudget(ctx, total.toString())
                                            budgetDraft = Prefs.categoryBudgets(ctx)
                                            budgetRefresh++
                                            editingLimit = false
                                        }
                                    }) { Text("Save") }
                                }
                            }
                        }
                    }
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = cs.surfaceVariant.copy(alpha = 0.55f),
                        border = BorderStroke(1.dp, cs.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.StickyNote2, contentDescription = null, tint = cs.primary, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("This month's transactions (${catTxs.size})", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                            }
                            HorizontalDivider()
                            if (catTxs.isEmpty()) {
                                Text("No transactions recorded in $cat this month.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                            } else {
                                catTxs.forEachIndexed { idx, tx ->
                                    if (idx > 0) HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                                    val conv = mainAmount(tx)
                                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text("• ${tx.merchant ?: tx.bank}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text("${noteDateFmt.format(Date(tx.timestamp))} · ${tx.bank}${tx.account?.let { " ••$it" }.orEmpty()}", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                                        }
                                        Text(
                                            text = if (tx.currency.equals(mainCurrency, true)) "${tx.currency} %,.2f".format(tx.amount) else "$mainCurrency %,.2f (${tx.currency} %,.2f)".format(conv, tx.amount),
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFFC62828)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { selectedBudgetCategory = null }) { Text("Close") } }
        )
    }
    if (monthReviewOpen) AlertDialog(onDismissRequest = { }, title = { Text("New month · confirm budget") },
        text = { Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Review the copied category budgets for this month. Cash wallet automatically tracks this month's withdrawals and cash spending.")
            ExpenseCategories.names.forEach { category -> OutlinedTextField(value = reviewBudgetDraft[category].orEmpty(), onValueChange = { v -> reviewBudgetDraft = reviewBudgetDraft + (category to v.filter { it.isDigit() || it == '.' || it == ',' }) }, label = { Text(category) }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
        } }, confirmButton = { TextButton(onClick = {
            val valid = reviewBudgetDraft.values.all { it.isBlank() || (it.replace(",", "").toDoubleOrNull()?.let { n -> n >= 0 } == true) }
            if (valid) { val total = Prefs.saveCategoryBudgets(ctx, reviewBudgetDraft); Prefs.saveMonthlyBudget(ctx, total.toString()); Prefs.saveReviewedMonth(ctx, monthKey); monthReviewOpen = false }
        }) { Text("Confirm month") } }, dismissButton = { TextButton(onClick = { Prefs.saveReviewedMonth(ctx, monthKey); monthReviewOpen = false }) { Text("Keep current values") } })
    if (cashWalletOpen) CashWalletDialog(db, mainCurrency, rateVersion = rateVersion, onChanged = { cashWalletRefresh++ }, onDismiss = { cashWalletRefresh++; cashWalletOpen = false })
    editAccount?.let { label ->
        val parts = label.split("·").map { it.trim() }
        val rawBank = parts.firstOrNull().orEmpty()
        val tail = parts.getOrNull(1).orEmpty()
        val detectedKind = tail.substringBefore("••").trim().ifBlank { "Account" }
        val detectedLast4 = tail.substringAfter("••", "").trim()
        val currentCustomName = if (detectedLast4.isNotBlank()) Prefs.detectedAccountCustomName(ctx, rawBank, detectedKind, detectedLast4) else null
        BalanceEditor(
            title = label,
            initial = Prefs.manualBalance(ctx, label) ?: "0.00",
            onSave = { value -> Prefs.saveManualBalance(ctx, label, value); accountListRefresh++; editAccount = null },
            onDismiss = { editAccount = null },
            currency = Prefs.manualBalanceCurrency(ctx, label) ?: mainCurrency,
            initialName = currentCustomName ?: label,
            accountType = detectedKind,
            onSaveWithName = { newName, newBal ->
                Prefs.saveManualBalance(ctx, label, newBal)
                if (detectedLast4.isNotBlank()) {
                    Prefs.saveDetectedAccountCustomName(ctx, rawBank, detectedKind, detectedLast4, newName)
                } else {
                    Prefs.updateCustomAccount(ctx, label, detectedKind, newName)
                    Prefs.saveManualBalance(ctx, newName, newBal)
                }
                accountListRefresh++
                editAccount = null
            }
        )
    }
}

// ---------- Transactions ----------
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun Transactions(
    db: AppDb, modifier: Modifier, rateVersion: Int = 0,
    startAddTransaction: Boolean = false, onStartAddConsumed: () -> Unit = {},
    startPasteMessage: Boolean = false, onStartPasteConsumed: () -> Unit = {}, refreshToken: Int = 0,
    isRefreshing: Boolean = false, onRefresh: () -> Unit = {}
) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var label by remember { mutableStateOf("This month") }
    var range by remember { mutableStateOf(monthRange(0)) }
    var picker by remember { mutableStateOf(false) }
    var account by remember { mutableStateOf<String?>(null) }
    var categoryFilter by remember { mutableStateOf("All categories") }
    var searchQuery by remember { mutableStateOf("") }
    var minAmountQuery by remember { mutableStateOf("") }
    var maxAmountQuery by remember { mutableStateOf("") }
    var searchExpanded by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var editingTx by remember { mutableStateOf<Txn?>(null) }
    var addingTx by remember { mutableStateOf(false) }
    var addingBill by remember { mutableStateOf(false) }
    var pastingMessage by remember { mutableStateOf(false) }
    var addOptions by remember { mutableStateOf(false) }
    var chartType by remember { mutableStateOf(Prefs.chartType(ctx)) }
    var refreshAfterEdit by remember { mutableIntStateOf(0) }
    var txViewMode by remember { mutableStateOf("Timeline") } // Timeline | Merchants | Recurring | Select
    var selectedTxIds by remember { mutableStateOf(setOf<Long>()) }
    var showBulkCategoryDialog by remember { mutableStateOf(false) }
    var bulkCategoryChoice by remember { mutableStateOf("Shopping") }
    LaunchedEffect(startAddTransaction) {
        if (startAddTransaction) { addingTx = true; onStartAddConsumed() }
    }
    LaunchedEffect(startPasteMessage) {
        if (startPasteMessage) { pastingMessage = true; onStartPasteConsumed() }
    }
    val all by produceState(emptyList<Txn>(), range, refreshAfterEdit, refreshToken) {
        loading = true
        value = withContext(Dispatchers.IO) { db.tx().between(range.first, range.second) }
        loading = false
    }
    val history by produceState(emptyList<Txn>(), all) { value = db.tx().between(monthRange(5).first, System.currentTimeMillis()) }
    val accounts = remember(all) { all.filter { it.account != null }.map { it.accountLabel() }.distinct().sorted() }
    val list = remember(all, account, categoryFilter, searchQuery, minAmountQuery, maxAmountQuery) {
        val rawQ = searchQuery.trim()
        val inlineRangeMatch = Regex("^\\s*(\\d+(?:\\.\\d+)?)\\s*(?:-+|to|\\.\\.)\\s*(\\d+(?:\\.\\d+)?)\\s*$", RegexOption.IGNORE_CASE).find(rawQ)
        val inlineMinMatch = Regex("^\\s*(?:>=|>|min\\s*)\\s*(\\d+(?:\\.\\d+)?)\\s*$", RegexOption.IGNORE_CASE).find(rawQ)
        val inlineMaxMatch = Regex("^\\s*(?:<=|<|max\\s*)\\s*(\\d+(?:\\.\\d+)?)\\s*$", RegexOption.IGNORE_CASE).find(rawQ)
        val minAmt = minAmountQuery.replace(",", "").trim().toDoubleOrNull()
            ?: inlineRangeMatch?.groupValues?.get(1)?.toDoubleOrNull()
            ?: inlineMinMatch?.groupValues?.get(1)?.toDoubleOrNull()
        val maxAmt = maxAmountQuery.replace(",", "").trim().toDoubleOrNull()
            ?: inlineRangeMatch?.groupValues?.get(2)?.toDoubleOrNull()
            ?: inlineMaxMatch?.groupValues?.get(1)?.toDoubleOrNull()
        val textQuery = if (inlineRangeMatch != null || inlineMinMatch != null || inlineMaxMatch != null) "" else rawQ.lowercase()
        all.filter { tx ->
            val searchable = listOf(tx.merchant.orEmpty(), tx.bank, tx.category, tx.account.orEmpty(), tx.rawText, "%.2f".format(Locale.US, tx.amount)).joinToString(" ").lowercase()
            val fuzzyMatch = textQuery.isBlank() || searchable.contains(textQuery) || textQuery.split(Regex("\\s+")).all { token -> searchable.contains(token) || searchable.split(Regex("[^a-z0-9.]+")).any { word -> word.startsWith(token) || (token.length >= 4 && word.contains(token.take(4))) } }
            val inAmountRange = (minAmt == null || tx.amount >= minAmt) && (maxAmt == null || tx.amount <= maxAmt)
            !tx.isCashMovement() && fuzzyMatch && inAmountRange && (account == null || tx.accountLabel() == account) && when (categoryFilter) {
                "All categories" -> true
                "Payments" -> tx.isPayment() || tx.category.equals("Cash transfer", true)
                else -> tx.category.equals(categoryFilter, true)
            }
        }
    }
    val hist = remember(history, account) { if (account == null) history else history.filter { it.accountLabel() == account } }
    val runningExpenseTotals = remember(list) {
        var total = 0.0
        list.sortedBy { it.timestamp }.associate { tx ->
            if (tx.type == TxType.DEBIT && tx.counts()) total += tx.amount
            tx.id to total
        }
    }
    val groups = remember(list) { list.groupBy { Instant.ofEpochMilli(it.timestamp).atZone(ZoneId.systemDefault()).toLocalDate() } }
    fun pick(l: String, r: Pair<Long, Long>) { label = l; range = r; report = null; account = null }
    val now = System.currentTimeMillis(); val day = 86_400_000L
    Box(modifier.fillMaxSize()) {
    PullToRefreshBox(isRefreshing = isRefreshing, onRefresh = onRefresh, modifier = Modifier.fillMaxSize()) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp).then(if (rateVersion < 0) Modifier.size(1.dp) else Modifier), contentPadding = PaddingValues(top = 6.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (loading) item { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
            Text("Loading transactions…", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } }
        item { Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            val zone = ZoneId.systemDefault()
            val today = LocalDate.now(zone)
            val weekStart = today.with(java.time.DayOfWeek.MONDAY)
            val lastWeekStart = weekStart.minusWeeks(1)
            val startOf = { d: LocalDate -> d.atStartOfDay(zone).toInstant().toEpochMilli() }
            val endOf = { d: LocalDate -> d.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli() - 1L }
            listOf(
                "Today" to todayRange(), "Yesterday" to yesterdayRange(),
                "This week" to (startOf(weekStart) to endOf(today)),
                "Last week" to (startOf(lastWeekStart) to endOf(lastWeekStart.plusDays(6))),
                "This month" to monthRange(0), "Last month" to monthRange(1),
                "6 months" to (startOf(today.minusMonths(6)) to endOf(today))
            ).forEach { (l, r) -> FilterChip(label == l, { pick(l, r) }, { Text("$l (${all.count { it.timestamp in r.first..r.second }})", style = MaterialTheme.typography.labelSmall) }) }
            FilterChip(label == "Custom", { picker = true }, { Text("Custom", style = MaterialTheme.typography.labelSmall) })
        } }
        if (accounts.isNotEmpty()) item { Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            FilterChip(account == null, { account = null; report = null }, { Text("All accounts", style = MaterialTheme.typography.labelSmall) })
            accounts.forEach { a -> FilterChip(account == a, { account = a; report = null }, { Text(a, style = MaterialTheme.typography.labelSmall, maxLines = 1) }) }
        } }
        item { Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            (listOf("All categories", "Payments") + ExpenseCategories.names + listOf("Unknown", "Other", "Cash", "Cash transfer", "Transfers", "Direct debit", "Card payment", "Cash spending", "EMI / Loan repayment", "Income", "Refund")).distinct().forEach { cat ->
                FilterChip(selected = categoryFilter == cat, onClick = { categoryFilter = cat }, label = { Text(cat, style = MaterialTheme.typography.labelSmall, maxLines = 1) })
            }
        } }
        item { Text("Totals for $label${if (categoryFilter != "All categories") " · $categoryFilter" else ""}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat("In", list.filter { it.type == TxType.CREDIT && it.counts() }.sumOf { it.amount }, Color(0xFF2E9E5B))
            Stat("Out", Insights.spend(list).sumOf { it.amount })
        } }
        item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Spending Insights", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("$label · spending by category", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                ChartTypeSelector(chartType) { selected -> chartType = selected; Prefs.saveChartType(ctx, selected) }
            }
            FinanceChart(list, chartType, Prefs.monthlyBudget(ctx).toDoubleOrNull())
        } } }
        item { Button(enabled = !busy && list.isNotEmpty(), modifier = Modifier.fillMaxWidth(), onClick = {
            busy = true; report = null
            scope.launch {
                val facts = Insights.facts(list, hist, label + (account?.let { " · $it" } ?: ""))
                report = try {
                    when {
                        LocalLlm.ready(ctx) -> LocalLlm.generate(ctx, Insights.prompt(facts))
                        Prefs.key(ctx).isNotBlank() -> AiAnalyzer.ask(Prefs.key(ctx), Insights.prompt(facts))
                        else -> "No on-device model installed yet (Settings > On-device AI). Plain summary:\n\n$facts"
                    }
                } catch (e: Throwable) { "AI failed: ${e.message}\n\nPlain summary:\n\n$facts" }
                busy = false
            }
        }) { Icon(Icons.Default.Star, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(if (busy) "Analysing…" else "Analyse spending trend") } }
        if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        report?.let { a -> item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Star, null); Spacer(Modifier.width(8.dp)); Text("Spending analysis", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
                    Spacer(Modifier.height(8.dp)); SelectionContainer { Text(a.plain()) }
                }
            }
        } }
        item {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                listOf("Timeline" to Icons.AutoMirrored.Filled.List, "Merchants" to Icons.Default.Storefront, "Recurring" to Icons.Default.Autorenew, "Select" to Icons.Default.Checklist).forEach { (mode, ico) ->
                    FilterChip(
                        selected = txViewMode == mode,
                        onClick = { txViewMode = mode; if (mode != "Select") selectedTxIds = emptySet() },
                        leadingIcon = { Icon(ico, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text(mode, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }
        if (txViewMode == "Select" && list.isNotEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${selectedTxIds.size} selected", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { selectedTxIds = if (selectedTxIds.size == list.size) emptySet() else list.map { it.id }.toSet() }) {
                            Text(if (selectedTxIds.size == list.size) "None" else "All", style = MaterialTheme.typography.labelSmall)
                        }
                        TextButton(enabled = selectedTxIds.isNotEmpty(), onClick = { showBulkCategoryDialog = true }) {
                            Text("Set category", style = MaterialTheme.typography.labelSmall)
                        }
                        TextButton(enabled = selectedTxIds.isNotEmpty(), onClick = {
                            scope.launch {
                                withContext(Dispatchers.IO) { db.tx().deleteByIds(selectedTxIds.toList()) }
                                selectedTxIds = emptySet()
                                refreshAfterEdit++
                            }
                        }) {
                            Text("Delete", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
        if (list.isEmpty()) item { Empty("No transactions in this period") }
        when (txViewMode) {
            "Merchants" -> {
                val merchantGroups = list.filter { it.type == TxType.DEBIT && it.counts() }
                    .groupBy { (it.merchant ?: it.bank).trim().ifBlank { "Unknown" } }
                    .map { (mName, rows) -> Triple(mName, rows.size, rows.sumOf { it.amount }) to rows.first().category }
                    .sortedByDescending { it.first.third }
                if (merchantGroups.isEmpty()) item { Empty("No merchant expenses in this period") }
                items(merchantGroups, key = { "merch-${it.first.first}" }) { (info, cat) ->
                    val (mName, count, totalAmt) = info
                    val avg = if (count > 0) totalAmt / count else 0.0
                    Card(Modifier.fillMaxWidth().clickable { searchQuery = mName; txViewMode = "Timeline" }) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.size(36.dp)) {
                                Box(contentAlignment = Alignment.Center) { CategoryGlyph(cat, Modifier.size(18.dp), MaterialTheme.colorScheme.onSecondaryContainer) }
                            }
                            Column(Modifier.weight(1f)) {
                                Text(mName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("$count visit(s) · Avg ${Prefs.mainCurrency(ctx)} ${"%,.2f".format(avg)} · $cat", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("−${Prefs.mainCurrency(ctx)} ${"%,.2f".format(totalAmt)}", fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                        }
                    }
                }
            }
            "Recurring" -> {
                val recurringCandidates = hist.filter { it.type == TxType.DEBIT && it.counts() && !it.merchant.isNullOrBlank() }
                    .groupBy { it.merchant!!.trim().lowercase(Locale.ROOT) }
                    .mapNotNull { (_, rows) ->
                        val monthsSeen = rows.map { Instant.ofEpochMilli(it.timestamp).atZone(ZoneId.systemDefault()).let { z -> "${z.year}-${z.monthValue}" } }.distinct()
                        if (monthsSeen.size >= 2 || rows.size >= 2) {
                            val latest = rows.maxByOrNull { it.timestamp }!!
                            Triple(latest, rows.size, rows.map { it.amount }.average())
                        } else null
                    }
                    .sortedByDescending { it.third }
                if (recurringCandidates.isEmpty()) item { Empty("No recurring merchants detected yet") }
                items(recurringCandidates, key = { "rec-${it.first.id}" }) { (latest, occurrences, avgAmt) ->
                    var addedAsBill by remember(latest.id) { mutableStateOf(false) }
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Default.Autorenew, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Column(Modifier.weight(1f)) {
                                Text(latest.merchant ?: latest.bank, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("$occurrences charges · Avg ${latest.currency} ${"%,.2f".format(avgAmt)} · ${latest.category}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            OutlinedButton(
                                enabled = !addedAsBill,
                                onClick = {
                                    scope.launch {
                                        val nextDue = Instant.ofEpochMilli(latest.timestamp).atZone(ZoneId.systemDefault()).toLocalDate().plusMonths(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                                        withContext(Dispatchers.IO) {
                                            BillPayments.insertIfUnique(db, Bill(
                                                title = "${latest.merchant ?: latest.bank} bill",
                                                amount = latest.amount,
                                                currency = latest.currency,
                                                dueDate = nextDue,
                                                bank = latest.bank,
                                                isSubscription = true,
                                                status = "PENDING",
                                                rawText = "Recurring expense from ${latest.merchant}",
                                                fingerprint = "REC_BILL|${(latest.merchant ?: "").lowercase()}|$nextDue",
                                                recurrence = "MONTHLY"
                                            ))
                                        }
                                        addedAsBill = true
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(if (addedAsBill) "Added" else "+ Bill reminder", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
            else -> {
                groups.forEach { (d, rows) ->
                    item(key = "h$d") { Text(dayLabel(d), Modifier.padding(top = 8.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) }
                    items(rows, key = { it.id }) { tx -> AnimatedVisibility(visible = !loading, enter = fadeIn() + slideInVertically { it / 4 }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (txViewMode == "Select") {
                                Checkbox(
                                    checked = tx.id in selectedTxIds,
                                    onCheckedChange = { checked -> selectedTxIds = if (checked) selectedTxIds + tx.id else selectedTxIds - tx.id }
                                )
                            }
                            Column(Modifier.weight(1f)) {
                                TxRow(tx, "HH:mm", runningExpenseTotal = runningExpenseTotals[tx.id], onExclude = {
                                    scope.launch {
                                        db.tx().setExcluded(tx.id, true)
                                        Prefs.addExcludedKey(ctx, Prefs.exclusionKey(tx.account, tx.merchant, tx.category))
                                    }
                                }, onEdit = { if (txViewMode == "Select") { selectedTxIds = if (tx.id in selectedTxIds) selectedTxIds - tx.id else selectedTxIds + tx.id } else editingTx = tx }, rateVersion = rateVersion, onDelete = {
                                    scope.launch { withContext(Dispatchers.IO) { db.tx().deleteById(tx.id) }; refreshAfterEdit++ }
                                })
                            }
                        }
                    } }
                }
            }
        }
    }
    }
    // Search is an independent overlay: it floats above the Add button and never
    // participates in the LazyColumn layout or consumes a row of vertical space.
    AnimatedVisibility(
        visible = searchExpanded,
        modifier = Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = 156.dp),
        enter = fadeIn() + slideInVertically { it / 3 },
        exit = fadeOut() + slideOutVertically { it / 3 }
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            shadowElevation = 12.dp,
            modifier = Modifier
                .widthIn(min = 280.dp, max = 350.dp)
                .border(1.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.85f), RoundedCornerShape(24.dp))
        ) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    singleLine = true,
                    placeholder = { Text("Merchant, keyword or 50-200") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = {
                        IconButton(onClick = { searchQuery = ""; minAmountQuery = ""; maxAmountQuery = ""; searchExpanded = false }) {
                            Icon(Icons.Default.Close, "Close search")
                        }
                    }
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = minAmountQuery,
                        onValueChange = { minAmountQuery = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        singleLine = true,
                        label = { Text("Min amt") }
                    )
                    OutlinedTextField(
                        value = maxAmountQuery,
                        onValueChange = { maxAmountQuery = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        singleLine = true,
                        label = { Text("Max amt") }
                    )
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = { picker = true }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) {
                        Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Date range: $label", style = MaterialTheme.typography.labelSmall)
                    }
                    if (searchQuery.isNotBlank() || minAmountQuery.isNotBlank() || maxAmountQuery.isNotBlank()) {
                        TextButton(onClick = { searchQuery = ""; minAmountQuery = ""; maxAmountQuery = "" }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) {
                            Text("Clear", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
    SmallFloatingActionButton(
        onClick = { searchExpanded = !searchExpanded; if (!searchExpanded) { searchQuery = ""; minAmountQuery = ""; maxAmountQuery = "" } },
        modifier = Modifier.align(Alignment.BottomEnd).padding(end = 28.dp, bottom = 88.dp),
        containerColor = MaterialTheme.colorScheme.secondaryContainer,
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
    ) {
        Icon(if (searchExpanded) Icons.Default.Close else Icons.Default.Search,
            contentDescription = if (searchExpanded) "Close search" else "Search transactions")
    }
    FloatingActionButton(
        onClick = { addOptions = true },
        modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
    ) { Icon(Icons.Default.Add, contentDescription = "Add transaction or bill") }
    }
    val savedLinkedCards by produceState(initialValue = emptyList<String>(), key1 = all) {
        value = withContext(Dispatchers.IO) {
            val detected = db.tx().all().filter { (it.kind ?: "").contains("card", true) && !it.account.isNullOrBlank() && !Prefs.isDetectedAccountHidden(ctx, canonicalBankName(it.bank), it.kind, it.account.orEmpty()) }
                .map { "${canonicalBankName(it.bank)} ••${it.account}" }
            (Prefs.customAccounts(ctx).filter { it.first.contains("card", true) }.map { it.second } + detected).distinct()
        }
    }
    addingTx.takeIf { it }?.let {
        AddTransactionDialog(
            defaultCurrency = Prefs.mainCurrency(ctx),
            linkedCards = savedLinkedCards,
            onDismiss = { addingTx = false },
            onSave = { amount, currency, merchant, category, type, timestamp, payFromCash, linkedCard ->
                scope.launch {
                    withContext(Dispatchers.IO) {
                        val newTx = Txn(
                            amount = amount,
                            currency = currency,
                            type = type,
                            merchant = merchant,
                            account = linkedCard?.let { Regex("(\\d{4})$").find(it)?.groupValues?.get(1) ?: it },
                            bank = linkedCard?.takeIf { it.contains("••") }?.substringBefore(" ••")?.let(::canonicalBankName) ?: "Manual",
                            kind = when { payFromCash || category.equals("Cash withdrawal", true) -> "Cash Wallet"; !linkedCard.isNullOrBlank() -> "Credit card"; else -> null },
                            category = category,
                            timestamp = timestamp,
                            rawText = "Manually added transaction",
                            fingerprint = "MANUAL|${java.util.UUID.randomUUID()}"
                        )
                        val id = db.tx().insert(newTx)
                        if (id > 0) {
                            BillPayments.reconcileTransactionWithBills(ctx, db, newTx.copy(id = id), notify = true)
                        }
                    }
                    refreshAfterEdit++
                    addingTx = false
                }
            }
        )
    }
    if (pastingMessage) PasteMessageDialog(
        defaultCurrency = Prefs.mainCurrency(ctx),
        onDismiss = { pastingMessage = false },
        onSaveRule = { type, category, pattern -> Prefs.addTransactionRule(ctx, type.name, category, pattern) },
        onSaveBill = { title, amount, currency, dueDate, raw ->
            scope.launch {
                withContext(Dispatchers.IO) {
                    BillPayments.insertIfUnique(db, Bill(title = title, amount = amount, currency = currency, dueDate = dueDate,
                        bank = title.substringBefore(" ").ifBlank { "Pasted message" }, isSubscription = false,
                        status = "PENDING", rawText = raw, fingerprint = "PASTED_BILL|${title.lowercase()}|$amount|$dueDate|${raw.hashCode()}"))
                }
                pastingMessage = false
            }
        },
        onSave = { amount, currency, merchant, category, type, timestamp, raw ->
            scope.launch {
                withContext(Dispatchers.IO) {
                    val pastedTx = Txn(
                        amount = amount, currency = currency, type = type, merchant = merchant,
                        account = null, bank = "Pasted message", kind = null, category = category,
                        timestamp = timestamp, rawText = raw, sourceType = "PASTED_NOTIFICATION",
                        fingerprint = "PASTED|${UUID.randomUUID()}"
                    )
                    val id = db.tx().insert(pastedTx)
                    if (id > 0) {
                        BillPayments.reconcileTransactionWithBills(ctx, db, pastedTx.copy(id = id), notify = true)
                    }
                }
                refreshAfterEdit++
                pastingMessage = false
            }
        },
        onSaveBalance = { bank, account, currency, amount ->
            val label = "$bank · Account ••${account ?: "Main"}"
            Prefs.addCustomAccount(ctx, "Bank & debit account", label)
            Prefs.saveManualBalance(ctx, label, amount.toString(), currency)
            refreshAfterEdit++
            pastingMessage = false
        }
    )
    if (addOptions) QuickAddDialog(
        onDismiss = { addOptions = false },
        onAddTransaction = { addOptions = false; addingTx = true },
        onAddBill = { addOptions = false; addingBill = true },
        onAddPastedMessage = { addOptions = false; pastingMessage = true }
    )
    if (addingBill) AddBillDialog(
        defaultCurrency = Prefs.mainCurrency(ctx),
        onDismiss = { addingBill = false },
        onSave = { title, amount, currency, dueDate, monthlyRepeat ->
            scope.launch {
                withContext(Dispatchers.IO) {
                    BillPayments.insertIfUnique(db, Bill(
                        title = title, amount = amount, currency = currency, dueDate = dueDate,
                        bank = "Manual", isSubscription = false, status = "PENDING",
                        rawText = "Manually added bill/reminder", fingerprint = "MANUAL_BILL|${UUID.randomUUID()}", recurrence = if (monthlyRepeat) "MONTHLY" else null
                    ))
                }
                addingBill = false
            }
        }
    )
    editingTx?.let { tx -> EditTransactionDialog(tx, onDismiss = { editingTx = null }, onSave = { updated ->
        scope.launch {
            withContext(Dispatchers.IO) {
                db.tx().update(updated)
                BillPayments.reconcileTransactionWithBills(ctx, db, updated, notify = true)
                val merchant = updated.merchant?.trim().orEmpty()
                // A manual category edit must not overwrite every transaction for this merchant.
                // Keep the edited row as chosen; other rows are changed only by configured keyword rules.
                if (merchant.isNotBlank() && !updated.category.equals(tx.category, true)) {
                    Prefs.addMerchantCategoryRule(ctx, updated.category, merchant)
                }
            }
            refreshAfterEdit++; editingTx = null
        }
    }) }
    if (showBulkCategoryDialog) {
        AlertDialog(
            onDismissRequest = { showBulkCategoryDialog = false },
            title = { Text("Assign category to ${selectedTxIds.size} transaction(s)") },
            text = { CategoryDropdown(bulkCategoryChoice, { bulkCategoryChoice = it }) },
            confirmButton = {
                TextButton(onClick = {
                    val chosen = bulkCategoryChoice
                    val ids = selectedTxIds
                    scope.launch {
                        withContext(Dispatchers.IO) {
                            val allRows = db.tx().all().filter { it.id in ids }
                            allRows.forEach { row -> db.tx().update(row.copy(category = chosen)) }
                        }
                        selectedTxIds = emptySet()
                        showBulkCategoryDialog = false
                        txViewMode = "Timeline"
                        refreshAfterEdit++
                    }
                }) { Text("Apply") }
            },
            dismissButton = { TextButton(onClick = { showBulkCategoryDialog = false }) { Text("Cancel") } }
        )
    }
    if (picker) {
        val st = rememberDateRangePickerState()
        DatePickerDialog(onDismissRequest = { picker = false }, confirmButton = {
            TextButton({
                val s = st.selectedStartDateMillis; val e = st.selectedEndDateMillis
                if (s != null && e != null) pick("Custom", s to e + day - 1); picker = false
            }) { Text("OK") }
        }) {
            Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.padding(horizontal = 8.dp)) {
                Column(Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                    Text("Choose date range", Modifier.padding(start = 16.dp, top = 10.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("Select a start date and an end date", Modifier.padding(start = 16.dp, top = 3.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    DateRangePicker(st, Modifier.height(500.dp), showModeToggle = true)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun CategoryDropdown(value: String, onChange: (String) -> Unit, label: String = "Category") {
    val ctx = LocalContext.current
    val custom = remember(Prefs.expenseCategoryRules(ctx)) { Prefs.expenseCategoryRules(ctx).lineSequence().map { it.substringBefore("=").trim() }.filter { it.isNotBlank() }.toList() }
    val options = remember(value, custom) { (listOf("Unknown") + ExpenseCategories.names + custom + listOf("Other", "Salary", "Income", "Refund", "Cash", "Cash withdrawal", "Cash transfer", "Fees & interest", "Card payment")).distinct().let { base -> if (value !in base) listOf(value) + base else base } }
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(value = value, onValueChange = {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth(), label = { Text(label) }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onChange(option); expanded = false }) }
        }
    }
}

/** Suggests a reusable local regex with named fields understood by BankParser. */
private fun suggestTransactionRegex(sample: String, merchant: String?): String {
    if (sample.isBlank()) return ""
    var generalized = sample.trim()
    val placeholders = linkedMapOf<String, String>()
    fun replaceFirstWithPattern(regex: Regex, pattern: String, key: String) {
        val match = regex.find(generalized) ?: return
        val token = "ZZZ${key}${placeholders.size}ZZZ"
        placeholders[token] = pattern
        generalized = generalized.replaceRange(match.range, token)
    }
    // Named groups let the generic parser extract fields instead of merely matching a message.
    if (!merchant.isNullOrBlank()) {
        val at = generalized.indexOf(merchant, ignoreCase = true)
        if (at >= 0 && merchant.trim().length >= 2) {
            val token = "ZZZMERCHANT${placeholders.size}ZZZ"
            placeholders[token] = "(?<merchant>[A-Za-z0-9][A-Za-z0-9 &.'*/-]{1,40}?)"
            generalized = generalized.replaceRange(at, at + merchant.length, token)
        }
    }
    replaceFirstWithPattern(Regex("(?i)\\b(?:\\d{4}-\\d{2}-\\d{2}|\\d{1,2}[/.-]\\d{1,2}[/.-]\\d{2,4}|\\d{1,2}\\s+[A-Za-z]{3,9}\\s+\\d{2,4})\\s+\\d{1,2}:\\d{2}(?::\\d{2})?\\b"), "(?<datetime>\\d{4}-\\d{2}-\\d{2}\\s+\\d{1,2}:\\d{2}(?::\\d{2})?|\\d{1,2}[/.-]\\d{1,2}[/.-]\\d{2,4}\\s+\\d{1,2}:\\d{2}(?::\\d{2})?|\\d{1,2}\\s+[A-Za-z]{3,9}\\s+\\d{2,4}\\s+\\d{1,2}:\\d{2}(?::\\d{2})?)", "DATETIME")
    replaceFirstWithPattern(Regex("(?i)\\b(?:\\d{4}-\\d{2}-\\d{2}|\\d{1,2}[/.-]\\d{1,2}[/.-]\\d{2,4}|\\d{1,2}\\s+[A-Za-z]{3,9}\\s+\\d{2,4})\\b"), "(?<datetime>\\d{4}-\\d{2}-\\d{2}|\\d{1,2}[/.-]\\d{1,2}[/.-]\\d{2,4}|\\d{1,2}\\s+[A-Za-z]{3,9}\\s+\\d{2,4})", "DATE")
    val cardPattern = Regex("(?i)\\b(?:card|account|a/c|acct)(?:\\s+(?:ending|ends|number|no\\.?|with|in))*\\s*[:#-]?\\s*[xX*•.\\-]*(\\d{4,16})\\b")
    cardPattern.find(generalized)?.let { match ->
        val digits = match.groupValues.last()
        val prefix = match.value.substringBeforeLast(digits)
        val token = "ZZZCARD${placeholders.size}ZZZ"
        placeholders[token] = Regex.escape(prefix) + "(?<card>\\d{4,16})"
        generalized = generalized.replaceRange(match.range, token)
    }
    replaceFirstWithPattern(Regex("(?i)(?:\\bAED\\b|\\bUSD\\b|\\bEUR\\b|\\bGBP\\b|\\bINR\\b|\\bSAR\\b|\\bQAR\\b|\\bKWD\\b|\\bBHD\\b|\\bOMR\\b|\\bDHS?\\b|\\bRs\\.?|₹|\\$|€|£)"), "(?<currency>AED|USD|EUR|GBP|INR|SAR|QAR|KWD|BHD|OMR|DHS?|Rs\\.?|₹|\\$|€|£)", "CUR")
    replaceFirstWithPattern(Regex("(?<![A-Za-z])\\d{1,3}(?:,\\d{3})*(?:\\.\\d{1,2})?(?![A-Za-z])"), "(?<amount>\\d+(?:,\\d{3})*(?:\\.\\d{1,2})?)", "AMOUNT")
    var result = generalized.split(Regex("\\s+")).filter { it.isNotEmpty() }.joinToString("\\s+") { Regex.escape(it) }
    placeholders.forEach { (token, pattern) -> result = result.replace(Regex.escape(token), pattern) }
    return result
}

@Composable fun EditTransactionDialog(tx: Txn, onDismiss: () -> Unit, onSave: (Txn) -> Unit) {
    val ctx = LocalContext.current
    val savedCards by produceState(initialValue = emptyList<String>(), key1 = tx.id) {
        value = withContext(Dispatchers.IO) {
            val detected = AppDb.get(ctx).tx().all().filter { (it.kind ?: "").contains("card", true) && !it.account.isNullOrBlank() && !Prefs.isDetectedAccountHidden(ctx, canonicalBankName(it.bank), it.kind, it.account.orEmpty()) }
                .map { "${canonicalBankName(it.bank)} ••${it.account}" }
            (Prefs.customAccounts(ctx).filter { it.first.contains("card", true) }.map { it.second } + detected).distinct()
        }
    }
    var cardMenu by remember(tx.id) { mutableStateOf(false) }
    var amount by remember(tx.id) { mutableStateOf(tx.amount.toString()) }
    var merchant by remember(tx.id) { mutableStateOf(tx.merchant.orEmpty()) }
    var note by remember(tx.id) { mutableStateOf(Prefs.txNote(ctx, tx.id)) }
    var linkedCard by remember(tx.id) { mutableStateOf(tx.account.orEmpty()) }
    var category by remember(tx.id) { mutableStateOf(tx.category) }
    var currency by remember(tx.id) { mutableStateOf(tx.currency) }
    var type by remember(tx.id) { mutableStateOf(tx.type) }
    var payFromCash by remember(tx.id) { mutableStateOf(tx.kind.equals("Cash Wallet", true)) }
    var date by remember(tx.id) { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(tx.timestamp))) }
    var time by remember(tx.id) { mutableStateOf(SimpleDateFormat("HH:mm", Locale.US).format(Date(tx.timestamp))) }
    var invalidDate by remember(tx.id) { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Edit transaction") }, text = { Column(Modifier.heightIn(max = 500.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(amount, { amount = it }, label = { Text("Amount") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(date, { date = it; invalidDate = false }, modifier = Modifier.weight(1f), label = { Text("Date (yyyy-MM-dd)") }, singleLine = true)
            OutlinedTextField(time, { time = it; invalidDate = false }, modifier = Modifier.weight(0.7f), label = { Text("Time (HH:mm)") }, singleLine = true)
        }
        if (invalidDate) Text("Enter a valid date and time, e.g. 2026-10-27 and 18:45.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(currency, { currency = it.uppercase().filter { ch -> ch.isLetter() }.take(3) }, label = { Text("Currency") }, singleLine = true)
        Box {
            OutlinedButton(onClick = { cardMenu = true }, modifier = Modifier.fillMaxWidth()) {
                Text(savedCards.firstOrNull { it.endsWith("••${linkedCard}") || it.equals(linkedCard, true) } ?: linkedCard.ifBlank { "Select account / credit card" }, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Icon(Icons.Default.ArrowDropDown, null)
            }
            DropdownMenu(expanded = cardMenu, onDismissRequest = { cardMenu = false }) {
                savedCards.forEach { card -> DropdownMenuItem(text = { Text(card) }, onClick = { linkedCard = Regex("(\\d{4})$").find(card)?.groupValues?.get(1) ?: card; cardMenu = false }) }
                DropdownMenuItem(text = { Text("Clear selection") }, onClick = { linkedCard = ""; cardMenu = false })
            }
        }
        OutlinedTextField(merchant, { merchant = it }, label = { Text("Merchant / description") }, singleLine = true)
        OutlinedTextField(note, { note = it }, label = { Text("Personal note / warranty / memo (optional)") }, singleLine = true)
        CategoryDropdown(category, { category = it })
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = payFromCash, onCheckedChange = { payFromCash = it }); Text("Paid/received through Cash Wallet") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(type == TxType.DEBIT, { type = TxType.DEBIT }, label = { Text("Expense") }); FilterChip(type == TxType.CREDIT, { type = TxType.CREDIT }, label = { Text("Income") }) }
    } }, confirmButton = { TextButton(onClick = {
        val parsedDate = runCatching { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { isLenient = false }.parse("${date.trim()} ${time.trim()}")?.time }.getOrNull()
        val parsedAmount = amount.trim().replace(",", "").toDoubleOrNull()
        if (parsedDate == null) invalidDate = true
        if (parsedDate != null && parsedAmount != null && parsedAmount > 0) {
            val selectedCard = savedCards.firstOrNull { it.endsWith("••${linkedCard}") || it.equals(linkedCard, true) }
            val accountValue = linkedCard.trim().takeIf { it.isNotBlank() }?.let { Regex("(\\d{4})$").find(selectedCard ?: it)?.groupValues?.get(1) ?: it }
            val bankValue = selectedCard?.takeIf { it.contains("••") }?.substringBefore(" ••")?.let(::canonicalBankName) ?: tx.bank
            Prefs.saveTxNote(ctx, tx.id, note)
            onSave(tx.copy(amount = parsedAmount, timestamp = parsedDate, currency = currency.trim().ifBlank { tx.currency }, merchant = merchant.trim().ifBlank { null }, account = accountValue, bank = bankValue, category = category.trim().ifBlank { "Unknown" }, type = type, kind = if (payFromCash) "Cash Wallet" else if (category.contains("card", true) && category.contains("payment", true)) "Credit card" else if (tx.kind.equals("Cash Wallet", true)) null else tx.kind))
        }
    }) { Text("Save") } }, dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddTransactionDialog(
    defaultCurrency: String,
    onDismiss: () -> Unit,
    linkedCards: List<String> = emptyList(),
    onSave: (Double, String, String, String, TxType, Long, Boolean, String?) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var linkedCard by remember { mutableStateOf<String?>(null) }
    var cardMenu by remember { mutableStateOf(false) }
    var payFromCash by remember { mutableStateOf(false) }
    var merchant by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Unknown") }
    var currency by remember { mutableStateOf(defaultCurrency) }
    var type by remember { mutableStateOf(TxType.DEBIT) }
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var time by remember { mutableStateOf(SimpleDateFormat("HH:mm", Locale.US).format(Date())) }
    var invalidDateTime by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }
    var invalidEntry by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add transaction") },
        text = { Column(Modifier.heightIn(max = 500.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(amount, { amount = it; invalidEntry = false }, label = { Text("Amount") }, singleLine = true)
            OutlinedTextField(currency, { currency = it.uppercase(); invalidEntry = false }, label = { Text("Currency (e.g. AED)") }, singleLine = true)
            OutlinedTextField(merchant, { merchant = it }, label = { Text("Description / merchant") }, singleLine = true)
            CategoryDropdown(category, { category = it })
            Box {
                OutlinedButton(onClick = { cardMenu = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(linkedCard ?: "Link a saved credit card (optional)", Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Icon(Icons.Default.ArrowDropDown, null)
                }
                DropdownMenu(expanded = cardMenu, onDismissRequest = { cardMenu = false }) {
                    linkedCards.forEach { card -> DropdownMenuItem(text = { Text(card) }, onClick = { linkedCard = card; cardMenu = false }) }
                    if (linkedCards.isEmpty()) DropdownMenuItem(text = { Text("No saved credit cards — add one in Accounts") }, onClick = { cardMenu = false })
                    if (!linkedCard.isNullOrBlank()) DropdownMenuItem(text = { Text("Clear selection") }, onClick = { linkedCard = null; cardMenu = false })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = category.equals("Cash withdrawal", true), onClick = { category = "Cash withdrawal"; type = TxType.DEBIT; payFromCash = false }, label = { Text("Cash withdrawal") })
                FilterChip(selected = payFromCash, onClick = { payFromCash = !payFromCash; if (payFromCash) category = "Cash" }, label = { Text("Cash wallet spend") })
            }
            val dialogCtx = LocalContext.current
            val liveWalletBal by produceState(0.0, payFromCash, category) {
                val r = monthRange(0)
                val rows = withContext(Dispatchers.IO) { AppDb.get(dialogCtx).tx().between(r.first, r.second) }
                val mainCur = Prefs.mainCurrency(dialogCtx)
                value = computeLiveCashWalletBalance(rows, mainCur) { from, to -> ExchangeRates.cachedRate(from, to) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = payFromCash, onCheckedChange = { payFromCash = it }); Text("Pay from cash wallet (current: ${if (liveWalletBal < 0) "−" else ""}${Prefs.mainCurrency(dialogCtx)} %,.2f)".format(abs(liveWalletBal))) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(type == TxType.DEBIT, { type = TxType.DEBIT }, label = { Text("Expense") })
                FilterChip(type == TxType.CREDIT, { type = TxType.CREDIT }, label = { Text("Income") })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(date, { date = it; invalidDateTime = false }, Modifier.weight(1f), label = { Text("Date (yyyy-MM-dd)") }, singleLine = true, readOnly = true, trailingIcon = { IconButton(onClick = { showDatePicker = true }) { Icon(Icons.Default.CalendarMonth, "Choose date") } })
                OutlinedTextField(time, { time = it; invalidDateTime = false }, Modifier.weight(0.62f), label = { Text("Time (HH:mm)") }, singleLine = true)
            }
            if (invalidDateTime) Text("Enter a valid date and 24-hour time, for example 2026-10-27 and 18:45.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            if (invalidEntry) Text(if (category.contains("card", true) && category.contains("payment", true) && linkedCard.isNullOrBlank()) "Select the credit card used for this payment." else "Enter a positive amount and a 3-letter currency code, such as AED.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { Button(onClick = {
            val parsed = amount.trim().replace(",", "").toDoubleOrNull()
            val cur = currency.trim().uppercase()
            val timestamp = runCatching { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { isLenient = false }.parse("${date.trim()} ${time.trim()}")?.time }.getOrNull()
            if (parsed != null && parsed > 0 && cur.matches(Regex("[A-Z]{3}") ) && timestamp != null && (!(category.contains("card", true) && category.contains("payment", true)) || !linkedCard.isNullOrBlank())) {
                onSave(parsed, cur, merchant.trim().ifBlank { "Manual transaction" }, if (payFromCash && category == "Unknown") "Cash" else category.trim().ifBlank { "Unknown" }, type, timestamp, payFromCash, linkedCard)
            } else {
                invalidDateTime = timestamp == null
                invalidEntry = parsed == null || parsed <= 0 || !cur.matches(Regex("[A-Z]{3}")) || (category.contains("card", true) && category.contains("payment", true) && linkedCard.isNullOrBlank())
            }
        }) { Text("Save transaction") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
    if (showDatePicker) {
        val initial = runCatching { SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date)?.time }.getOrNull() ?: System.currentTimeMillis()
        val state = rememberDatePickerState(initialSelectedDateMillis = initial)
        DatePickerDialog(onDismissRequest = { showDatePicker = false }, confirmButton = { TextButton(onClick = { state.selectedDateMillis?.let { date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it)); invalidDateTime = false }; showDatePicker = false }) { Text("Apply date") } }, dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("Cancel") } }) { DatePicker(state) }
    }
}

@Composable fun PasteMessageDialog(
    defaultCurrency: String,
    onDismiss: () -> Unit,
    onSaveRule: (TxType, String, String) -> Unit,
    onSaveBill: (String, Double?, String?, Long?, String) -> Unit,
    onSave: (Double, String, String, String, TxType, Long, String) -> Unit,
    onSaveBalance: (String, String?, String, Double) -> Unit = { _, _, _, _ -> }
) {
    var message by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf(defaultCurrency) }
    var merchant by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Unknown") }
    var type by remember { mutableStateOf(TxType.DEBIT) }
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var time by remember { mutableStateOf(SimpleDateFormat("HH:mm", Locale.US).format(Date())) }
    var rulePattern by remember { mutableStateOf("") }
    var ruleSaved by remember { mutableStateOf(false) }
    var invalid by remember { mutableStateOf(false) }
    var aiRuleStatus by remember { mutableStateOf<String?>(null) }
    var generatingRule by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val parsed = remember(message) { BankParser.parse(message) }
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("Paste SMS / notification", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("We'll guess the type, amount and category as you paste it.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        } },
        text = { Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            OutlinedTextField(
                message,
                { value ->
                    message = value
                    ruleSaved = false
                    val detected = BankParser.parse(value)
                    if (detected is Parsed.Tx) {
                        amount = detected.amount.toString(); currency = detected.currency
                        merchant = detected.merchant.orEmpty(); category = detected.category; type = detected.type
                        rulePattern = suggestTransactionRegex(value, detected.merchant)
                    } else {
                        amount = ""; merchant = ""; category = "Unknown"; type = TxType.DEBIT
                        rulePattern = suggestTransactionRegex(value, null)
                    }
                },
                modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 6,
                label = { Text("Paste the complete message") },
                placeholder = { Text("Bank SMS or copied bank-app notification…") }
            )
            when (val result = parsed) {
                is Parsed.Tx -> Card(colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Detected ${if (result.type == TxType.CREDIT) "income / credit" else "expense / debit"}", fontWeight = FontWeight.Bold, color = cs.onPrimaryContainer)
                        Text("${result.currency} ${"%,.2f".format(result.amount)} · ${result.category}" + (result.merchant?.let { " · $it" } ?: ""), color = cs.onPrimaryContainer, style = MaterialTheme.typography.bodySmall)
                    }
                }
                is Parsed.BillInfo -> Text("This looks like a bill or due reminder, not a confirmed transaction. Check the details before saving it as a payment.", color = cs.tertiary, style = MaterialTheme.typography.bodySmall)
                is Parsed.BalanceInfo -> Card(colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)) {
                    Column(Modifier.padding(10.dp)) {
                        Text("Available balance detected", fontWeight = FontWeight.Bold, color = cs.onPrimaryContainer)
                        Text("${result.bank} · ${result.account?.let { "••$it" } ?: "Account"} · ${result.currency} ${"%,.2f".format(result.amount)}", color = cs.onPrimaryContainer, style = MaterialTheme.typography.bodySmall)
                    }
                }
                null -> Text("No confident match yet. You can still enter the amount and choose the correct type below.", color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            if (parsed !is Parsed.BillInfo && parsed !is Parsed.BalanceInfo) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(type == TxType.DEBIT, { type = TxType.DEBIT }, label = { Text("Expense / payment") })
                FilterChip(type == TxType.CREDIT, { type = TxType.CREDIT }, label = { Text("Income / refund") })
            }
            if (parsed !is Parsed.BillInfo && parsed !is Parsed.BalanceInfo) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(amount, { amount = it; invalid = false }, Modifier.weight(1f), label = { Text("Amount") }, singleLine = true)
                OutlinedTextField(currency, { currency = it.uppercase(); invalid = false }, Modifier.weight(0.7f), label = { Text("Currency") }, singleLine = true)
            }
            if (parsed !is Parsed.BillInfo && parsed !is Parsed.BalanceInfo) {
                OutlinedTextField(merchant, { merchant = it }, Modifier.fillMaxWidth(), label = { Text("Description / merchant") }, singleLine = true)
                CategoryDropdown(category, { category = it })
            }
            if (parsed !is Parsed.BillInfo && parsed !is Parsed.BalanceInfo) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(date, { date = it; invalid = false }, Modifier.weight(1f), label = { Text("Date (yyyy-MM-dd)") }, singleLine = true)
                OutlinedTextField(time, { time = it; invalid = false }, Modifier.weight(0.62f), label = { Text("Time (HH:mm)") }, singleLine = true)
            }
            HorizontalDivider()
            Text("Suggested rule for future SMS / notifications", fontWeight = FontWeight.SemiBold)
            Text("This is a local regex suggestion based on the sample. Review or edit it, then save only if it looks right.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            OutlinedTextField(rulePattern, { rulePattern = it; ruleSaved = false }, Modifier.fillMaxWidth(), label = { Text("Suggested regex (editable)") }, supportingText = { Text("Review the pattern before saving. It is applied locally to future SMS and notification messages.") }, singleLine = true)
            OutlinedButton(onClick = {
                if (!LocalLlm.ready(ctx)) {
                    aiRuleStatus = "No on-device model is installed. The local template above is available to edit and save."
                } else if (message.isBlank()) {
                    aiRuleStatus = "Paste a sample message first."
                } else {
                    scope.launch {
                        generatingRule = true; aiRuleStatus = "Generating with the on-device model…"
                        val prompt = "Create one Java/Kotlin-compatible case-insensitive regex for future transaction SMS/notifications. It MUST match this sample and use unique named capture groups where possible: (?<amount>number), (?<currency>currency code), (?<merchant>merchant/payee text), (?<card>card/account digits), (?<datetime>date and time). Generalize variable values while preserving stable wording. Use Java/Kotlin named-group syntax and no duplicate group names. Output only regex, no markdown or explanation. Sample message: ${message.take(1500)}"
                        val candidate = runCatching { LocalLlm.generate(ctx, prompt).trim().removePrefix("```").removeSuffix("```").trim() }.getOrNull()
                        val valid = candidate?.let { runCatching { Regex(it, RegexOption.IGNORE_CASE).containsMatchIn(message) }.getOrDefault(false) } ?: false
                        if (valid && !candidate.isNullOrBlank()) { rulePattern = candidate.orEmpty(); ruleSaved = false; aiRuleStatus = "On-device regex generated and matches this sample. Review it before saving." }
                        else aiRuleStatus = "The model did not return a valid regex matching this sample. Use or edit the local suggestion instead."
                        generatingRule = false
                    }
                }
            }, enabled = !generatingRule, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(6.dp)); Text(if (generatingRule) "Generating…" else "Improve with on-device AI")
            }
            aiRuleStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = if (it.startsWith("On-device regex")) Color(0xFF218A4A) else cs.onSurfaceVariant) }
            OutlinedButton(onClick = {
                if (rulePattern.isNotBlank() && runCatching { Regex(rulePattern, RegexOption.IGNORE_CASE) }.isSuccess) {
                    onSaveRule(type, category.trim().ifBlank { "Unknown" }, rulePattern.trim())
                    ruleSaved = true
                }
            }, enabled = rulePattern.isNotBlank()) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(6.dp)); Text(if (ruleSaved) "Rule saved" else "Approve and save rule") }
            if (invalid) Text("Enter a valid positive amount, 3-letter currency, date and time.", color = cs.error, style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { Button(onClick = {
            if (parsed is Parsed.BillInfo) {
                val bill = parsed as Parsed.BillInfo
                onSaveBill(bill.title, bill.amount, bill.currency, bill.dueDate, message.trim())
            } else if (parsed is Parsed.BalanceInfo) {
                onSaveBalance(parsed.bank, parsed.account, parsed.currency, parsed.amount)
            } else {
                val value = amount.trim().replace(",", "").toDoubleOrNull()
                val cur = currency.trim().uppercase()
                val timestamp = runCatching { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { isLenient = false }.parse("${date.trim()} ${time.trim()}")?.time }.getOrNull()
                if (!message.isBlank() && value != null && value > 0 && cur.matches(Regex("[A-Z]{3}") ) && timestamp != null) {
                    onSave(value, cur, merchant.trim().ifBlank { "Pasted bank message" }, category.trim().ifBlank { "Unknown" }, type, timestamp, message.trim())
                } else invalid = true
            }
        }) { Text(when (parsed) { is Parsed.BillInfo -> "Save pending bill / reminder"; is Parsed.BalanceInfo -> "Save account balance"; else -> "Save transaction" }) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

@Composable fun QuickAddDialog(
    onDismiss: () -> Unit,
    onAddTransaction: () -> Unit,
    onAddBill: () -> Unit,
    onAddPastedMessage: () -> Unit = {}
) {
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Quick add", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("What would you like to keep track of?", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Card(Modifier.fillMaxWidth().clickable { onAddTransaction() }, colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Surface(shape = CircleShape, color = cs.primary, modifier = Modifier.size(48.dp)) {
                            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.AddCard, contentDescription = null, tint = cs.onPrimary, modifier = Modifier.size(25.dp)) }
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("Transaction", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = cs.onPrimaryContainer)
                            Text("Add an expense, salary or other income", style = MaterialTheme.typography.bodySmall, color = cs.onPrimaryContainer)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = cs.onPrimaryContainer)
                    }
                }
                Card(Modifier.fillMaxWidth().clickable { onAddBill() }, colors = CardDefaults.cardColors(containerColor = cs.tertiaryContainer)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Surface(shape = CircleShape, color = cs.tertiary, modifier = Modifier.size(48.dp)) {
                            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.EventNote, contentDescription = null, tint = cs.onTertiary, modifier = Modifier.size(25.dp)) }
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("Bill or reminder", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = cs.onTertiaryContainer)
                            Text("Track a due date and mark it paid later", style = MaterialTheme.typography.bodySmall, color = cs.onTertiaryContainer)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = cs.onTertiaryContainer)
                    }
                }
                Card(Modifier.fillMaxWidth().clickable { onAddPastedMessage() }, colors = CardDefaults.cardColors(containerColor = cs.secondaryContainer)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Surface(shape = CircleShape, color = cs.secondary, modifier = Modifier.size(48.dp)) {
                            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.ContentPaste, contentDescription = null, tint = cs.onSecondary, modifier = Modifier.size(25.dp)) }
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("Paste SMS / notification", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = cs.onSecondaryContainer)
                            Text("Preview the guessed transaction and save it or learn a rule", style = MaterialTheme.typography.bodySmall, color = cs.onSecondaryContainer)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = cs.onSecondaryContainer)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddBillDialog(
    defaultCurrency: String,
    onDismiss: () -> Unit,
    onSave: (String, Double?, String?, Long?, Boolean) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf(defaultCurrency) }
    var date by remember { mutableStateOf("") }
    var invalidDate by remember { mutableStateOf(false) }
    var showDueDatePicker by remember { mutableStateOf(false) }
    var monthlyRepeat by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("New bill or reminder", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Keep the next due date from slipping through.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        text = { Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("Bill / reminder name") }, singleLine = true, leadingIcon = { Icon(Icons.Default.ReceiptLong, null) })
            OutlinedTextField(amount, { amount = it }, label = { Text("Amount (optional)") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Payments, null) })
            OutlinedTextField(currency, { currency = it.uppercase() }, label = { Text("Currency") }, singleLine = true)
            OutlinedTextField(date, { date = it; invalidDate = false }, label = { Text("Due date · yyyy-MM-dd (optional)") }, singleLine = true, readOnly = true, trailingIcon = { IconButton(onClick = { showDueDatePicker = true }) { Icon(Icons.Default.CalendarMonth, "Choose due date") } }, isError = invalidDate, supportingText = { if (invalidDate) Text("Choose a valid due date") })
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(monthlyRepeat, { monthlyRepeat = it }); Text("Repeat every month (rent, phone, etc.)") }
        } },
        confirmButton = { Button(onClick = {
            val due = if (date.isBlank()) null else runCatching { SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }.parse(date)?.time }.getOrNull()
            val amountValue = amount.trim().replace(",", "").toDoubleOrNull()
            val currencyValue = currency.trim().uppercase()
            if (title.isNotBlank() && (date.isBlank() || due != null) && (amount.isBlank() || (amountValue != null && amountValue >= 0)) && (currencyValue.isBlank() || currencyValue.matches(Regex("[A-Z]{3}")))) {
                onSave(title.trim(), amountValue, currencyValue.ifBlank { null }, due, monthlyRepeat)
            } else if (date.isNotBlank() && due == null) invalidDate = true
        }) { Text("Add reminder") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
    if (showDueDatePicker) {
        val initial = runCatching { SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date)?.time }.getOrNull() ?: System.currentTimeMillis()
        val state = rememberDatePickerState(initialSelectedDateMillis = initial)
        DatePickerDialog(onDismissRequest = { showDueDatePicker = false }, confirmButton = { TextButton(onClick = { state.selectedDateMillis?.let { date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it)); invalidDate = false }; showDueDatePicker = false }) { Text("Apply date") } }, dismissButton = { TextButton(onClick = { showDueDatePicker = false }) { Text("Cancel") } }) { DatePicker(state) }
    }
}


@Composable fun EditBillDialog(bill: Bill, onDismiss: () -> Unit, onSave: (Bill) -> Unit) {
    var title by remember(bill.id) { mutableStateOf(bill.title) }
    var amount by remember(bill.id) { mutableStateOf(bill.amount?.toString().orEmpty()) }
    var currency by remember(bill.id) { mutableStateOf(bill.currency ?: "AED") }
    var date by remember(bill.id) { mutableStateOf(bill.dueDate?.let { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it)) }.orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Edit reminder") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(title, { title = it }, label = { Text("Reminder title") }, singleLine = true)
        OutlinedTextField(amount, { amount = it }, label = { Text("Amount (optional)") }, singleLine = true)
        OutlinedTextField(currency, { currency = it.uppercase() }, label = { Text("Currency") }, singleLine = true)
        OutlinedTextField(date, { date = it }, label = { Text("Due date (yyyy-MM-dd, optional)") }, singleLine = true)
    } }, confirmButton = { TextButton(onClick = {
        val due = if (date.isBlank()) null else runCatching { SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }.parse(date)?.time }.getOrNull()
        if (date.isBlank() || due != null) onSave(bill.copy(title = title.trim().ifBlank { bill.title }, amount = amount.toDoubleOrNull(), currency = currency.trim().ifBlank { null }, dueDate = due))
    }) { Text("Save") } }, dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}

// ---------- Bills ----------
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun Bills(db: AppDb, modifier: Modifier, onTransactions: () -> Unit = {}, onPasteMessage: () -> Unit = {}) {
    val allBills by db.bills().allFlow().collectAsState(emptyList())
    val paymentRows by db.tx().recent(1000).collectAsState(emptyList())
    val cardPayments = remember(paymentRows) { paymentRows.filter { it.category.equals("Card payment", true) || it.category.equals("Credit card payment", true) }.sortedByDescending { it.timestamp } }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var filter by remember { mutableStateOf("Pending") }
    var contentMode by remember { mutableStateOf("Bills") }
    var editingBill by remember { mutableStateOf<Bill?>(null) }
    var addOptions by remember { mutableStateOf(false) }
    var addingBill by remember { mutableStateOf(false) }
    var deletingBill by remember { mutableStateOf<Bill?>(null) }
    var selectedPaidBills by remember { mutableStateOf(setOf<Long>()) }
    var selectedPaymentMonth by remember { mutableStateOf("This month") }
    val thisMonthLabel = remember { SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date()) }
    val sixMonthsAgo = remember { java.util.Calendar.getInstance().apply { add(java.util.Calendar.MONTH, -6) }.timeInMillis }
    val recentCardPayments = remember(cardPayments, sixMonthsAgo) { cardPayments.filter { it.timestamp >= sixMonthsAgo } }
    val monthOptions = remember(recentCardPayments) { (listOf("This month") + recentCardPayments.map { SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(it.timestamp)) }.distinct()).distinct() }
    val currentMonthPayments = remember(recentCardPayments, selectedPaymentMonth, thisMonthLabel) { val target = if (selectedPaymentMonth == "This month") thisMonthLabel else selectedPaymentMonth; recentCardPayments.filter { SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(it.timestamp)) == target } }
    val shown = remember(allBills, filter) { when (filter) {
        "Paid" -> allBills.filter { it.status == "PAID" && (it.paidAt ?: it.dueDate ?: 0L) >= sixMonthsAgo }
        "All" -> allBills.filterNot { it.status == "DISMISSED" }.filter { it.status == "PENDING" || (it.paidAt ?: it.dueDate ?: 0L) >= sixMonthsAgo }
        else -> allBills.filter { it.status == "PENDING" }
    } }
    Box(modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Bills", "Credit Card Payments").forEach { mode -> FilterChip(selected = contentMode == mode, onClick = { contentMode = mode }, label = { Text(mode) }) }
            }
            if (contentMode == "Bills") Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Pending", "Paid", "All").forEach { label -> FilterChip(selected = filter == label, onClick = { filter = label }, label = { Text(label) }) }
            }
            if (contentMode == "Bills" && filter == "Paid" && shown.isNotEmpty()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { selectedPaidBills = if (selectedPaidBills.size == shown.size) emptySet() else shown.map { it.id }.toSet() }) { Text(if (selectedPaidBills.size == shown.size) "Deselect all" else "Select all") }
                    Spacer(Modifier.weight(1f))
                    TextButton(enabled = selectedPaidBills.isNotEmpty(), onClick = { scope.launch { withContext(Dispatchers.IO) { db.bills().deleteByIds(selectedPaidBills.toList()) }; selectedPaidBills = emptySet() } }) { Text("Delete selected (${selectedPaidBills.size})", color = MaterialTheme.colorScheme.error) }
                }
            }
            LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), contentPadding = PaddingValues(top = 4.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (contentMode == "Bills") {
                item { Text("Bills & reminders", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
                if (shown.isEmpty()) item { Empty(when (filter) { "Paid" -> "No paid bills recorded yet"; "All" -> "No bills or reminders yet"; else -> "No pending bills or subscriptions" }) }
                items(shown, key = { it.id }) { b ->
                    if (filter == "Paid") Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = b.id in selectedPaidBills, onCheckedChange = { checked -> selectedPaidBills = if (checked) selectedPaidBills + b.id else selectedPaidBills - b.id })
                        Box(Modifier.weight(1f)) { BillRow(b, onDelete = { deletingBill = b }) }
                    } else BillRow(
                        b,
                        onEdit = if (b.status == "PAID") null else ({ editingBill = b }),
                        act = if (b.status == "PENDING") ({ status -> scope.launch { withContext(Dispatchers.IO) { BillPayments.setStatus(db, b, status) } } }) else null,
                        onDelete = { deletingBill = b }
                    )
                }
                } else {
                item { Text("Credit card payments", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
                item { Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                    Text("Month", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(end = 10.dp))
                    monthOptions.forEach { month -> FilterChip(selected = selectedPaymentMonth == month, onClick = { selectedPaymentMonth = month }, label = { Text(month) }, modifier = Modifier.padding(end = 6.dp)) }
                } }
                if (currentMonthPayments.isEmpty()) item { Text("No credit card payments for this month. Payments will appear here and will not count as expenses.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(currentMonthPayments, key = { "card-payment-${it.id}" }) { payment ->
                    var editingPayment by remember(payment.id) { mutableStateOf(false) }
                    TxRow(payment, pattern = "d MMM yyyy, HH:mm", onEdit = { editingPayment = true })
                    if (editingPayment) EditTransactionDialog(payment, onDismiss = { editingPayment = false }, onSave = { updated ->
                        scope.launch { withContext(Dispatchers.IO) { db.tx().update(updated) }; editingPayment = false }
                    })
                }
                }
            }
        }
        FloatingActionButton(onClick = { addOptions = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) {
            Icon(Icons.Default.Add, contentDescription = "Add transaction or bill")
        }
    }
    if (addOptions) QuickAddDialog(
        onDismiss = { addOptions = false },
        onAddTransaction = { addOptions = false; onTransactions() },
        onAddBill = { addOptions = false; addingBill = true },
        onAddPastedMessage = { addOptions = false; onPasteMessage() }
    )
    if (addingBill) AddBillDialog(
        defaultCurrency = Prefs.mainCurrency(ctx),
        onDismiss = { addingBill = false },
        onSave = { title, amount, currency, dueDate, monthlyRepeat ->
            scope.launch {
                withContext(Dispatchers.IO) {
                    BillPayments.insertIfUnique(db, Bill(title = title, amount = amount, currency = currency, dueDate = dueDate,
                        bank = "Manual", isSubscription = false, status = "PENDING", rawText = "Manually added bill/reminder",
                        fingerprint = "MANUAL_BILL|${UUID.randomUUID()}", recurrence = if (monthlyRepeat) "MONTHLY" else null))
                }
                addingBill = false
            }
        }
    )
    editingBill?.let { bill -> EditBillDialog(bill, onDismiss = { editingBill = null }, onSave = { updated ->
        scope.launch { withContext(Dispatchers.IO) { db.bills().update(updated) }; editingBill = null }
    }) }
    deletingBill?.let { bill -> AlertDialog(
        onDismissRequest = { deletingBill = null }, title = { Text("Delete bill or reminder?") },
        text = { Text("${bill.title} will be removed permanently. This does not delete related transactions.") },
        confirmButton = { TextButton(onClick = { scope.launch { withContext(Dispatchers.IO) { db.bills().deleteById(bill.id) }; deletingBill = null } }) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = { deletingBill = null }) { Text("Cancel") } }
    ) }
}

@Composable fun BillRow(b: Bill, onEdit: (() -> Unit)? = null, act: ((String) -> Unit)? = null, onDelete: (() -> Unit)? = null) {
    val d = b.daysLeft()
    val cs = MaterialTheme.colorScheme
    val urgent = b.status == "PENDING" && d != null && d in 0..5
    val pulse = androidx.compose.animation.core.rememberInfiniteTransition(label = "billPulse")
    val pulseAlpha by pulse.animateFloat(initialValue = 0.45f, targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(animation = androidx.compose.animation.core.tween(750), repeatMode = androidx.compose.animation.core.RepeatMode.Reverse), label = "billPulseAlpha")
    val (bg, fg) = when {
        b.status == "PAID" -> Color(0xFFDDF4DF) to Color(0xFF17663A)
        b.status == "PENDING" && d != null && d < 0 -> Color(0xFFFFCDD2) to Color(0xFF9F111B)
        b.status == "PENDING" && d != null && d < 2 -> Color(0xFFFFCDD2) to Color(0xFF9F111B)
        b.status == "PENDING" && d != null && d <= 5 -> Color(0xFFFFE0B2) to Color(0xFF8A4700)
        b.status == "PENDING" -> Color(0xFFD9DDE3) to Color(0xFF374151)
        else -> cs.surfaceVariant to cs.onSurfaceVariant
    }
    var showSource by remember(b.id) { mutableStateOf(false) }
    var confirmDelete by remember(b.id) { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Box {
        if (b.status == "PAID" || (b.status == "PENDING" && d != null && d < 0)) {
            Text(if (b.status == "PAID") "PAID" else "OVERDUE", modifier = Modifier.align(Alignment.Center).padding(start = 44.dp), color = fg.copy(alpha = 0.12f), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, maxLines = 1)
        }
        Row(Modifier.fillMaxWidth().clickable { if (onEdit != null) onEdit() else showSource = true }.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            BillIconAvatar(b)
            Column(Modifier.weight(1f).padding(start = 10.dp, end = 4.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text(b.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(listOfNotNull(b.currency, b.amount?.let { "%,.2f".format(it) }).joinToString(" ").ifEmpty { "Amount unknown" }, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (b.status == "PAID") b.paidAt?.let { Text("Paid " + SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(it)), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant) }
                else b.dueDate?.let { Text("Due " + SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(it)), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant) }
            }
            IconButton(onClick = { showSource = true }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.Info, "Bill details", modifier = Modifier.size(17.dp)) }
            if (act != null) {
                IconButton(onClick = { act("PAID") }, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.CheckCircle, "Mark paid", tint = Color(0xFF218A4A), modifier = Modifier.size(19.dp)) }
                IconButton(onClick = { act("DISMISSED") }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.Close, "Dismiss bill", modifier = Modifier.size(17.dp), tint = cs.onSurfaceVariant) }
            }
            if (onDelete != null) IconButton(onClick = { confirmDelete = true }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.DeleteOutline, "Delete bill", modifier = Modifier.size(17.dp), tint = cs.error) }
            Spacer(Modifier.width(6.dp))
            Surface(shape = RoundedCornerShape(12.dp), color = bg, contentColor = fg, modifier = Modifier.size(width = 46.dp, height = 43.dp)) {
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    if (b.status == "PAID") Icon(Icons.Default.Check, contentDescription = "Paid", modifier = Modifier.size(19.dp))
                    else Text(if (d == null) "—" else abs(d).toString(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = if (urgent) cs.error.copy(alpha = pulseAlpha) else fg)
                    Text(if (b.status == "PAID") "Paid" else when { d == null -> "No date"; d < 0 -> "Late"; d == 0 -> "Today"; d == 1 -> "Day"; else -> "Days" }, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                }
            }
        }
        }
    }
    if (showSource) AlertDialog(
        onDismissRequest = { showSource = false },
        title = { Text(if (b.status == "PAID") "Payment record" else "Captured reminder") },
        text = { Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${b.bank} · ${b.title}", fontWeight = FontWeight.SemiBold)
            Text("Original bill SMS / notification", style = MaterialTheme.typography.labelMedium)
            SelectionContainer { Text(b.rawText.ifBlank { "Original message was not stored." }) }
            if (b.status == "PAID") {
                HorizontalDivider()
                Text("Payment evidence", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text("Recorded at: " + (b.paidAt?.let { SimpleDateFormat("d MMM yyyy, HH:mm:ss", Locale.getDefault()).format(Date(it)) } ?: "Time not stored"))
                b.paymentTxnId?.let { Text("Matched transaction ID: $it") }
                b.paymentBank?.let { Text("Payment source: $it") }
                b.paymentSourceType?.let { source -> Text("Channel: ${if (source.equals("NOTIFICATION", true)) "Bank-app notification" else if (source.equals("SMS", true)) "SMS" else source}") }
                Text("Matched SMS / notification", style = MaterialTheme.typography.labelMedium)
                SelectionContainer { Text(b.paymentRawText?.takeIf { it.isNotBlank() } ?: "No matching payment message was found. The bill was marked paid manually.") }
            }
        } },
        confirmButton = { TextButton({ showSource = false }) { Text("Close") } }
    )
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false }, title = { Text("Delete bill or reminder?") },
        text = { Text("${b.title} will be removed permanently.") },
        confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete?.invoke() }) { Text("Delete", color = cs.error) } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
    )
}

fun parseCsv(line: String): List<String> {
    val out = mutableListOf<String>(); val cell = StringBuilder(); var quoted = false; var i = 0
    while (i < line.length) { val c = line[i]; if (c == '"') { if (quoted && i + 1 < line.length && line[i + 1] == '"') { cell.append('"'); i++ } else quoted = !quoted } else if (c == ',' && !quoted) { out += cell.toString(); cell.setLength(0) } else cell.append(c); i++ }
    out += cell.toString(); return out
}
fun csv(value: String): String = "\"" + value.replace("\"", "\"\"").replace("\n", " ").replace("\r", " ") + "\""

/** Applies local category patterns to historical expense rows, preferring the first matching configured category. */
suspend fun applyExpenseCategoryRules(ctx: Context, rawRules: String): Int {
    val rules = ExpenseCategories.parseRules(rawRules)
    val dao = AppDb.get(ctx).tx()
    val rows = dao.all()
    var changed = 0
    rows.filter { it.type == TxType.DEBIT && it.category != "Card payment" && it.category != "Excluded" }.forEach { tx ->
        val haystack = listOfNotNull(tx.merchant, tx.rawText).joinToString(" ")
        val category = rules.firstOrNull { (_, regex) -> regex.containsMatchIn(haystack) }?.first
        if (category != null && !category.equals(tx.category, true)) {
            dao.update(tx.copy(category = category))
            changed++
        }
    }
    return changed
}

// ---------- Settings (full screen) ----------
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable fun SettingsScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current; val tick = rememberResumeTick(); val cs = MaterialTheme.colorScheme
    var activeSection by remember { mutableStateOf<String?>(null) }
    var currencyError by remember { mutableStateOf<String?>(null) }
    var userName by remember { mutableStateOf(Prefs.userName(ctx)) }
    var reminderEnabled by remember { mutableStateOf(Prefs.dailyReminderEnabled(ctx)) }
    var reminderHourText by remember { mutableStateOf(Prefs.dailyReminderHour(ctx).toString().padStart(2, '0')) }
    var reminderMinuteText by remember { mutableStateOf(Prefs.dailyReminderMinute(ctx).toString().padStart(2, '0')) }
    var reminderStatus by remember { mutableStateOf<String?>(null) }
    var showReminderTimePicker by remember { mutableStateOf(false) }
    var billReminderEnabled by remember { mutableStateOf(Prefs.billReminderEnabled(ctx)) }
    var billReminderHourText by remember { mutableStateOf(Prefs.billReminderHour(ctx).toString().padStart(2, '0')) }
    var billReminderMinuteText by remember { mutableStateOf(Prefs.billReminderMinute(ctx).toString().padStart(2, '0')) }
    var billReminderStatus by remember { mutableStateOf<String?>(null) }
    var showBillReminderTimePicker by remember { mutableStateOf(false) }
    var autoBackupEnabled by remember { mutableStateOf(Prefs.autoBackupEnabled(ctx)) }
    var transactionNotificationsEnabled by remember { mutableStateOf(Prefs.transactionNotificationsEnabled(ctx)) }
    var screenshotText by remember { mutableStateOf<String?>(null) }
    var screenshotStatus by remember { mutableStateOf<String?>(null) }
    var screenshotBusy by remember { mutableStateOf(false) }
    var latestNotification by remember { mutableStateOf(LatestNotificationDebug.read(ctx)) }
    var test by remember { mutableStateOf("") }
    var customRules by remember { mutableStateOf(Prefs.categoryRules(ctx)) }
    var expenseCategoryRules by remember { mutableStateOf(Prefs.expenseCategoryRules(ctx).ifBlank { ExpenseCategories.defaultRules() }) }
    var categoryStatus by remember { mutableStateOf<String?>(null) }
    var newCategoryName by remember { mutableStateOf("") }
    var newCategoryWords by remember { mutableStateOf("") }
    var transactionRules by remember { mutableStateOf(Prefs.transactionRules(ctx)) }
    var rulesSaved by remember { mutableStateOf<String?>(null) }
    var showAdvancedRules by remember { mutableStateOf(false) }
    var customRuleSample by remember { mutableStateOf("") }
    var customRuleAmount by remember { mutableStateOf("") }
    var customRuleCurrency by remember { mutableStateOf("") }
    var customRuleMerchant by remember { mutableStateOf("") }
    var customRuleDate by remember { mutableStateOf("") }
    var customRuleCard by remember { mutableStateOf("") }
    var customRulePattern by remember { mutableStateOf("") }
    var customRuleType by remember { mutableStateOf(TxType.DEBIT) }
    var customRuleCategory by remember { mutableStateOf("Unknown") }
    var customRuleAiStatus by remember { mutableStateOf<String?>(null) }
    var generatingCustomRule by remember { mutableStateOf(false) }
    var exportStatus by remember { mutableStateOf<String?>(null) }
    var mainCurrency by remember { mutableStateOf(Prefs.mainCurrency(ctx)) }
    var monthlyBudget by remember { mutableStateOf(Prefs.monthlyBudget(ctx)) }
    var categoryBudgetValues by remember { mutableStateOf(Prefs.categoryBudgets(ctx)) }
    var categoryBudgetStatus by remember { mutableStateOf<String?>(null) }
    var rateStatus by remember { mutableStateOf("Rates not refreshed yet") }
    val scope = rememberCoroutineScope()
    val backupFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            Prefs.saveBackupFolderUri(ctx, uri.toString())
            BackupStorage.clearLegacyBackups(ctx)
            androidx.documentfile.provider.DocumentFile.fromTreeUri(ctx, uri)?.let { BackupStorage.prune(it); BackupStorage.pruneCsvExports(it) }
            AutoBackupWorker.schedule(ctx)
            exportStatus = "Backup folder selected. Manual and automatic backups will use this folder; only the latest two ZIP backups are kept."
        }
    }
    var importMsg by remember { mutableStateOf<String?>(null) }
    var folderCsvFiles by remember { mutableStateOf<List<androidx.documentfile.provider.DocumentFile>>(emptyList()) }
    var showFolderCsvImport by remember { mutableStateOf(false) }

    fun importCsvUri(uri: android.net.Uri) {
        scope.launch {
            importMsg = "Importing backup…"
            try {
                val lines = withContext(Dispatchers.IO) { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readLines() ?: error("Couldn't open file") }
                var txCount = 0; var billCount = 0
                val db = AppDb.get(ctx)
                lines.drop(1).forEach { line ->
                    val cols = parseCsv(line)
                    if (cols.size < 9) return@forEach
                    val type = cols[0].trim().lowercase()
                    if (type == "setting") {
                        val settingValue = cols.getOrNull(5).orEmpty().toBooleanStrictOrNull() ?: return@forEach
                        when (cols.getOrNull(4).orEmpty()) {
                            "auto_backup_enabled" -> { Prefs.saveAutoBackupEnabled(ctx, settingValue); AutoBackupWorker.schedule(ctx) }
                            "transaction_notifications_enabled" -> Prefs.saveTransactionNotificationsEnabled(ctx, settingValue)
                        }
                    } else if (type == "transaction") {
                        val date = runCatching { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).parse(cols[1])?.time }.getOrNull() ?: return@forEach
                        val amount = cols[2].toDoubleOrNull() ?: return@forEach
                        val category = cols.getOrNull(4).orEmpty().ifBlank { "Other" }
                        val direction = cols.getOrNull(9).orEmpty().uppercase()
                        val txType = if (direction == "CREDIT" || direction == "INCOME" || category.contains("salary", true) || category.equals("income", true)) TxType.CREDIT else TxType.DEBIT
                        val account = cols.getOrNull(6)?.takeIf { it.isNotBlank() && it != "Unknown account" }?.takeLast(4)
                        val bank = canonicalBankName(cols.getOrNull(7).orEmpty().ifBlank { "Imported" })
                        val raw = cols.getOrNull(8).orEmpty()
                        val fingerprint = "CSV-T|" + listOf(date.toString(), amount.toString(), cols[3], category, cols.getOrNull(5).orEmpty(), account.orEmpty(), bank).joinToString("|")
                        val inserted = withContext(Dispatchers.IO) { db.tx().insert(Txn(amount = amount, currency = cols[3].ifBlank { "AED" }, type = txType, merchant = cols.getOrNull(5)?.ifBlank { null }, account = account, bank = bank, kind = if (account == null) null else "Account", category = category, timestamp = date, rawText = raw, fingerprint = fingerprint)) }
                        if (inserted > 0) txCount++
                    } else if (type == "reminder") {
                        val amount = cols[2].toDoubleOrNull(); val date = cols[1].takeIf { it.isNotBlank() }?.let { runCatching { SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(it)?.time }.getOrNull() }
                        val title = cols.getOrNull(5).orEmpty().ifBlank { "Imported reminder" }; val bank = cols.getOrNull(7).orEmpty().ifBlank { "Imported" }; val raw = cols.getOrNull(8).orEmpty()
                        val fingerprint = "CSV-B|${title.lowercase()}|$date|$amount|${cols[3]}"
                        val inserted = withContext(Dispatchers.IO) { BillPayments.insertIfUnique(db, Bill(title = title, amount = amount, currency = cols[3].ifBlank { null }, dueDate = date, bank = bank, isSubscription = false, status = "PENDING", rawText = raw, fingerprint = fingerprint)) }
                        if (inserted > 0) billCount++
                    }
                }
                importMsg = "Backup imported: $txCount transactions and $billCount reminders added. Existing rows were kept."
            } catch (e: Throwable) { importMsg = "Import failed: ${e.message}" }
        }
    }

    fun exportCsvToSelectedFolder() {
        scope.launch {
            try {
                val treeUri = Prefs.backupFolderUri(ctx)?.let { android.net.Uri.parse(it) } ?: error("Choose the backup folder first.")
                val directory = androidx.documentfile.provider.DocumentFile.fromTreeUri(ctx, treeUri) ?: error("Backup folder unavailable. Choose it again.")
                val allTx = withContext(Dispatchers.IO) { AppDb.get(ctx).tx().between(0L, System.currentTimeMillis()) }
                val allBills = withContext(Dispatchers.IO) { AppDb.get(ctx).bills().all() }
                val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
                val file = directory.createFile("text/csv", "moneytracker-export-$stamp.csv") ?: error("Couldn't create the CSV in the selected folder.")
                withContext(Dispatchers.IO) {
                    ctx.contentResolver.openOutputStream(file.uri)?.bufferedWriter()?.use { w ->
                        w.appendLine("type,date,amount,currency,category,merchant_or_title,account,source,original_message,direction")
                        allTx.forEach { t -> w.appendLine(listOf("transaction", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(t.timestamp)), t.amount.toString(), t.currency, t.category, t.merchant.orEmpty(), t.account.orEmpty(), t.bank, t.rawText, t.type.name).joinToString(",") { csv(it) }) }
                        allBills.forEach { b -> w.appendLine(listOf("reminder", b.dueDate?.let { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it)) }.orEmpty(), b.amount?.toString().orEmpty(), b.currency.orEmpty(), "", b.title, "", b.bank, b.rawText).joinToString(",") { csv(it) }) }
                        w.appendLine(listOf("setting", "", "", "", "auto_backup_enabled", Prefs.autoBackupEnabled(ctx).toString(), "", "", "").joinToString(",") { csv(it) })
                        w.appendLine(listOf("setting", "", "", "", "transaction_notifications_enabled", Prefs.transactionNotificationsEnabled(ctx).toString(), "", "", "").joinToString(",") { csv(it) })
                    } ?: error("Couldn't open the CSV destination.")
                }
                BackupStorage.pruneCsvExports(directory)
                exportStatus = "CSV exported to the selected folder: ${allTx.size} transactions and ${allBills.size} reminders. Latest two CSV exports are kept."
            } catch (e: Throwable) { exportStatus = "Export failed: ${e.message}" }
        }
    }

    val restoreZipLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            exportStatus = "Restoring backup…"
            exportStatus = try { BackupStorage.restoreBackup(ctx, uri) } catch (e: Throwable) { "Restore failed: ${e.message}" }
        }
    }
    val importCsvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) importCsvUri(uri) }
    val screenshotLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            screenshotBusy = true; screenshotStatus = "Reading screenshot on this device…"
            try {
                val image = InputImage.fromFilePath(ctx, uri)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                    .addOnSuccessListener { result -> screenshotText = result.text; screenshotStatus = if (result.text.isBlank()) "No readable text found. Try a clearer screenshot." else "Review the extracted text before importing."; screenshotBusy = false }
                    .addOnFailureListener { e -> screenshotStatus = "Screenshot reading failed: ${e.localizedMessage ?: "unknown error"}"; screenshotBusy = false }
            } catch (e: Exception) { screenshotStatus = "Could not open screenshot: ${e.localizedMessage ?: "unknown error"}"; screenshotBusy = false }
        }
    }
    val sms = remember(tick) { smsGranted(ctx) }; val notif = remember(tick) { notifAccess(ctx) }
    val postNotifications = remember(tick) { Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED }
    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val smsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val readLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val readSms = remember(tick) { readSmsGranted(ctx) }
    var found by remember { mutableStateOf<List<Pair<String, Int>>>(emptyList()) }
    var modelTick by remember { mutableIntStateOf(0) }; var modelMsg by remember { mutableStateOf<String?>(null) }
    val modelReady = remember(modelTick) { LocalLlm.ready(ctx) }
    val modelMb = remember(modelTick) { Prefs.modelFile(ctx).length() / 1_000_000 }
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            modelMsg = "Copying the model into the app, this can take a minute…"
            modelMsg = try { LocalLlm.install(ctx, uri); modelTick++; "Model ready." } catch (e: Throwable) { "Couldn't copy the model: ${e.message}" }
        }
    }
    val persistSettings: () -> Boolean = {
        val code = mainCurrency.trim().uppercase()
        val validCode = code.matches(Regex("[A-Z]{3}")) && runCatching { java.util.Currency.getInstance(code) }.isSuccess
        if (!validCode) { currencyError = "Enter a valid 3-letter ISO currency code (for example AED, USD or EUR)."; false } else {
        currencyError = null
        Prefs.saveUserName(ctx, userName)
        Prefs.saveAutoBackupEnabled(ctx, autoBackupEnabled)
        AutoBackupWorker.schedule(ctx)
        Prefs.saveTransactionNotificationsEnabled(ctx, transactionNotificationsEnabled)
        Prefs.saveMainCurrency(ctx, code)
        Prefs.saveMonthlyBudget(ctx, monthlyBudget.trim())
        Prefs.saveCategoryRules(ctx, customRules)
        val expenseRulesChanged = expenseCategoryRules != Prefs.expenseCategoryRules(ctx)
        Prefs.saveExpenseCategoryRules(ctx, expenseCategoryRules)
        if (expenseRulesChanged) scope.launch {
            val updatedCount = withContext(Dispatchers.IO) { applyExpenseCategoryRules(ctx, expenseCategoryRules) }
            categoryStatus = "Saved categories and updated $updatedCount existing transactions."
        }
        Prefs.saveTransactionRules(ctx, transactionRules)
        val hh = reminderHourText.toIntOrNull(); val mm = reminderMinuteText.toIntOrNull()
        if (hh != null && hh in 0..23 && mm != null && mm in 0..59) {
            Prefs.saveDailyReminder(ctx, reminderEnabled, hh, mm)
        }
        val bhh = billReminderHourText.toIntOrNull(); val bmm = billReminderMinuteText.toIntOrNull()
        if (bhh != null && bhh in 0..23 && bmm != null && bmm in 0..59) {
            Prefs.saveBillReminder(ctx, billReminderEnabled, bhh, bmm)
        }
        ReminderWorker.schedule(ctx)
        true
        }
    }
    if (showReminderTimePicker) {
        val initialHour = reminderHourText.toIntOrNull()?.coerceIn(0, 23) ?: 20
        val initialMinute = reminderMinuteText.toIntOrNull()?.coerceIn(0, 59) ?: 0
        val pickerState = rememberTimePickerState(initialHour = initialHour, initialMinute = initialMinute, is24Hour = false)
        AlertDialog(onDismissRequest = { showReminderTimePicker = false },
            title = { Text("Choose daily spending reminder time") },
            text = { TimePicker(state = pickerState) },
            confirmButton = { TextButton(onClick = { reminderHourText = pickerState.hour.toString().padStart(2, '0'); reminderMinuteText = pickerState.minute.toString().padStart(2, '0'); reminderStatus = null; showReminderTimePicker = false }) { Text("Apply") } },
            dismissButton = { TextButton(onClick = { showReminderTimePicker = false }) { Text("Cancel") } })
    }
    if (showBillReminderTimePicker) {
        val initialHour = billReminderHourText.toIntOrNull()?.coerceIn(0, 23) ?: 9
        val initialMinute = billReminderMinuteText.toIntOrNull()?.coerceIn(0, 59) ?: 0
        val pickerState = rememberTimePickerState(initialHour = initialHour, initialMinute = initialMinute, is24Hour = false)
        AlertDialog(onDismissRequest = { showBillReminderTimePicker = false },
            title = { Text("Choose morning bill reminder time") },
            text = { TimePicker(state = pickerState) },
            confirmButton = { TextButton(onClick = { billReminderHourText = pickerState.hour.toString().padStart(2, '0'); billReminderMinuteText = pickerState.minute.toString().padStart(2, '0'); billReminderStatus = null; showBillReminderTimePicker = false }) { Text("Apply") } },
            dismissButton = { TextButton(onClick = { showBillReminderTimePicker = false }) { Text("Cancel") } })
    }
    BackHandler {
        if (activeSection != null) {
            if (persistSettings()) activeSection = null
        } else if (persistSettings()) onClose()
    }

    @Composable fun Perm(name: String, on: Boolean, fix: String, onFix: () -> Unit) = Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(name, Modifier.weight(1f)); Text(if (on) "On" else "Off", color = if (on) Color(0xFF2E9E5B) else cs.error, fontWeight = FontWeight.SemiBold)
        if (!on) TextButton(onFix) { Text(fix) } else Spacer(Modifier.width(8.dp))
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text(activeSection ?: "Settings", fontWeight = FontWeight.SemiBold) }, navigationIcon = { IconButton({ if (activeSection != null) { if (persistSettings()) activeSection = null } else if (persistSettings()) onClose() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).consumeWindowInsets(pad).imePadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (activeSection == null) {
                item { Text("Choose a settings area", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant) }
                listOf(
                    Triple("Appearance", "Choose a theme and accent colour, update your profile, and set a daily reminder", Icons.Default.Palette),
                    Triple("Accounts", "Set your main currency, monthly budget, and exchange rates", Icons.Default.AccountBalanceWallet),
                    Triple("Permissions", "Manage SMS and bank notification permissions", Icons.Default.Security),
                    Triple("AI", "Import past SMS messages, manage the AI model and parsing rules, and test the parser", Icons.Default.AutoAwesome),
                    Triple("Expense categories", "Manage categories and merchant-matching rules on your device", Icons.Default.Category),
                    Triple("Export and import", "Back up or restore your transactions and reminders", Icons.Default.ImportExport),
                    Triple("About", "App version and application information", Icons.Default.Info)
                ).forEach { (name, description, sectionIcon) ->
                    item { Card(onClick = { activeSection = name }, modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(sectionIcon, contentDescription = null, tint = cs.primary, modifier = Modifier.size(28.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(description, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = "Open $name")
                    } } }
                }
            }
            if (activeSection == "Appearance") {
            item { Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Profile", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                OutlinedTextField(userName, { userName = it }, Modifier.fillMaxWidth(), label = { Text("Name shown on Home") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Person, null) })
                Text("If this is empty, MoneyTracker will ask for your name the next time it starts.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            } } }
            item { Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Appearance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Theme", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("System", "Light", "Dark").forEach { option -> FilterChip(ThemeState.mode.value == option, { ThemeState.mode.value = option; Prefs.saveTheme(ctx, option, ThemeState.accent.value) }, label = { Text(option) }) } }
                Text("Accent colour", style = MaterialTheme.typography.labelLarge)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Teal", "Blue", "Purple", "Orange", "Emerald", "Crimson").forEach { option -> FilterChip(ThemeState.accent.value == option, { ThemeState.accent.value = option; Prefs.saveTheme(ctx, ThemeState.mode.value, option) }, label = { Text(option) }) } }
            } } }
            }
            if (activeSection == "Accounts") {
            item {
                var currencyDropdownExpanded by remember { mutableStateOf(false) }
                var rateRefreshTick by remember { mutableIntStateOf(0) }
                val accountCurrencies by produceState(initialValue = listOf(mainCurrency.ifBlank { "AED" }), key1 = mainCurrency, key2 = rateRefreshTick) {
                    val found = withContext(Dispatchers.IO) {
                        val db = AppDb.get(ctx)
                        val txCurs = db.tx().all().mapNotNull { it.currency.trim().uppercase().takeIf { c -> c.matches(Regex("[A-Z]{3}")) } }
                        val billCurs = db.bills().all().mapNotNull { it.currency?.trim()?.uppercase()?.takeIf { c -> c.matches(Regex("[A-Z]{3}")) } }
                        val customAcctCurs = Prefs.customAccounts(ctx).mapNotNull { (_, name) -> Prefs.manualBalanceCurrency(ctx, name)?.trim()?.uppercase()?.takeIf { c -> c.matches(Regex("[A-Z]{3}")) } }
                        (txCurs + billCurs + customAcctCurs + listOf(Prefs.mainCurrency(ctx), "AED", "INR", "USD", "EUR", "GBP")).distinct()
                    }
                    value = found
                }
                LaunchedEffect(Unit) {
                    if (ExchangeRates.updatedAt == 0L) {
                        if (withContext(Dispatchers.IO) { ExchangeRates.refresh() }) rateRefreshTick++
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Currency & budget", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Select your main currency from the currencies detected across your accounts and transactions.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                ExposedDropdownMenuBox(expanded = currencyDropdownExpanded, onExpandedChange = { currencyDropdownExpanded = !currencyDropdownExpanded }) {
                    OutlinedTextField(
                        value = mainCurrency,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        label = { Text("Main currency (from detected accounts)") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = currencyDropdownExpanded) },
                        isError = currencyError != null,
                        singleLine = true
                    )
                    ExposedDropdownMenu(expanded = currencyDropdownExpanded, onDismissRequest = { currencyDropdownExpanded = false }) {
                        accountCurrencies.forEach { cur ->
                            val rateToMain = remember(cur, mainCurrency, rateRefreshTick) { ExchangeRates.cachedRate(cur, mainCurrency.ifBlank { "AED" }) }
                            val rateFromMain = remember(cur, mainCurrency, rateRefreshTick) { ExchangeRates.cachedRate(mainCurrency.ifBlank { "AED" }, cur) }
                            DropdownMenuItem(
                                text = {
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(cur, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            text = if (cur.equals(mainCurrency, true)) "Selected main"
                                            else if (rateToMain != null && rateFromMain != null) "1 $cur = ${"%,.4f".format(rateToMain)} $mainCurrency"
                                            else "Sync rates to view",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = cs.onSurfaceVariant
                                        )
                                    }
                                },
                                onClick = {
                                    mainCurrency = cur
                                    currencyError = null
                                    Prefs.saveMainCurrency(ctx, cur)
                                    currencyDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = cs.surfaceVariant.copy(alpha = 0.5f),
                    border = BorderStroke(1.dp, cs.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CurrencyExchange, contentDescription = null, tint = cs.primary, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Exchange rates for detected account currencies", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                        }
                        val otherCurrencies = accountCurrencies.filterNot { it.equals(mainCurrency, true) }
                        if (otherCurrencies.isEmpty()) {
                            Text("All detected accounts use $mainCurrency.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        } else {
                            otherCurrencies.forEach { cur ->
                                val rToMain = ExchangeRates.cachedRate(cur, mainCurrency.ifBlank { "AED" })
                                val rFromMain = ExchangeRates.cachedRate(mainCurrency.ifBlank { "AED" }, cur)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("$cur ↔ $mainCurrency", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                                    Text(
                                        text = if (rToMain != null && rFromMain != null) "1 $cur = ${"%,.4f".format(rToMain)} $mainCurrency  ·  1 $mainCurrency = ${"%,.4f".format(rFromMain)} $cur"
                                        else "Rate unavailable (tap sync below)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = cs.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
                currencyError?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }
                Button(onClick = { val code = mainCurrency.trim().uppercase(); val valid = code.matches(Regex("[A-Z]{3}")) && runCatching { java.util.Currency.getInstance(code) }.isSuccess; if (valid) { currencyError = null; Prefs.saveMainCurrency(ctx, code); scope.launch { val ok = withContext(Dispatchers.IO) { ExchangeRates.refresh() }; rateRefreshTick++; rateStatus = if (ok) "Reference rates updated ${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())}" else "Could not update rates; cached rates remain available" } } else currencyError = "Unknown currency. Enter a valid 3-letter ISO currency code (for example AED, USD or EUR)." }, modifier = Modifier.fillMaxWidth()) { Text("Save currency & sync exchange rates") }
                Text(rateStatus, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                OutlinedTextField(monthlyBudget, { monthlyBudget = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Monthly spending budget (${mainCurrency.ifBlank { "AED" }})") }, singleLine = true)
                OutlinedButton(onClick = { val code = mainCurrency.trim().uppercase(); val valid = code.matches(Regex("[A-Z]{3}")) && runCatching { java.util.Currency.getInstance(code) }.isSuccess; if (valid) { currencyError = null; Prefs.saveMainCurrency(ctx, code); Prefs.saveMonthlyBudget(ctx, monthlyBudget.trim()); exportStatus = "Currency and budget saved" } else currencyError = "Unknown currency. Enter a valid 3-letter ISO currency code (for example AED, USD or EUR)." }, modifier = Modifier.fillMaxWidth()) { Text("Save budget") }
                HorizontalDivider()
                Text("Detailed monthly budgets", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Set individual limits for school fees, rent, fuel, DEWA and other expense categories. The overall monthly budget is automatically calculated as the sum of the limits you enter.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                ExpenseCategories.names.forEach { category ->
                    OutlinedTextField(
                        value = categoryBudgetValues[category].orEmpty(),
                        onValueChange = { value -> categoryBudgetValues = categoryBudgetValues + (category to value.filter { it.isDigit() || it == '.' || it == ',' }); categoryBudgetStatus = null },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text("$category budget (${mainCurrency.ifBlank { "AED" }})") },
                        leadingIcon = { CategoryGlyph(category) }
                    )
                }
                val invalidBudget = categoryBudgetValues.values.any { it.isNotBlank() && (it.replace(",", "").toDoubleOrNull()?.let { v -> v < 0 } != false) }
                val categoryBudgetTotal = categoryBudgetValues.values.mapNotNull { it.replace(",", "").toDoubleOrNull() }.sum()
                Text("Category budget total: ${mainCurrency.ifBlank { "AED" }} %,.2f".format(categoryBudgetTotal), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Button(onClick = {
                    if (invalidBudget) categoryBudgetStatus = "Enter valid non-negative amounts for each category."
                    else {
                        val total = Prefs.saveCategoryBudgets(ctx, categoryBudgetValues)
                        monthlyBudget = if (categoryBudgetValues.values.any { it.isNotBlank() }) total.toString() else monthlyBudget
                        categoryBudgetStatus = "Saved detailed budgets. Overall monthly budget: ${mainCurrency.ifBlank { "AED" }} %,.2f".format(total)
                    }
                }, enabled = !invalidBudget, modifier = Modifier.fillMaxWidth()) { Text("Save detailed budgets and calculate total") }
                categoryBudgetStatus?.let { Text(it, color = if (it.startsWith("Saved")) Color(0xFF218A4A) else cs.error, style = MaterialTheme.typography.bodySmall) }
                Text("Rates are indicative reference rates from a public exchange-rate feed, refreshed on app launch or when synced here. Google does not provide a supported public currency API; card/bank settlement rates may differ. Currencies without a returned rate are omitted from converted totals.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            } } }
            }
            if (activeSection == "Appearance") {
            item { Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Transaction notifications", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Show the amount and merchant when a new transaction is captured from SMS or a bank-app notification.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Show amount and merchant", Modifier.weight(1f)); Switch(transactionNotificationsEnabled, { transactionNotificationsEnabled = it }) }
            } } }
            item { Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(horizontal = 14.dp, vertical = 11.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Daily spending reminder", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text("Daily spending summary (tapping opens Transactions)", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                    Switch(checked = reminderEnabled, onCheckedChange = { reminderEnabled = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { showReminderTimePicker = true }, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)) {
                        Icon(Icons.Default.AccessTime, null, Modifier.size(18.dp)); Spacer(Modifier.width(7.dp))
                        val h = reminderHourText.toIntOrNull()?.coerceIn(0, 23) ?: 20
                        val m = reminderMinuteText.toIntOrNull()?.coerceIn(0, 59) ?: 0
                        Text(String.format(Locale.getDefault(), "%d:%02d %s", if (h % 12 == 0) 12 else h % 12, m, if (h < 12) "AM" else "PM"))
                    }
                    Text("Reminder time", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    Spacer(Modifier.weight(1f))
                    Button(onClick = {
                        val hh = reminderHourText.toIntOrNull(); val mm = reminderMinuteText.toIntOrNull()
                        if (hh != null && hh in 0..23 && mm != null && mm in 0..59) {
                            Prefs.saveDailyReminder(ctx, reminderEnabled, hh, mm); ReminderWorker.schedule(ctx)
                            reminderStatus = if (reminderEnabled) "Daily reminder saved." else "Daily reminder disabled."
                        } else reminderStatus = "Choose a valid reminder time."
                    }, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)) { Text("Save") }
                }
                reminderStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
                HorizontalDivider()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Pending bill morning reminder (3 days)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text("Reminds you once every morning if a bill is due within 3 days (tapping opens Bills)", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                    Switch(checked = billReminderEnabled, onCheckedChange = { billReminderEnabled = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { showBillReminderTimePicker = true }, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)) {
                        Icon(Icons.Default.AccessTime, null, Modifier.size(18.dp)); Spacer(Modifier.width(7.dp))
                        val bh = billReminderHourText.toIntOrNull()?.coerceIn(0, 23) ?: 9
                        val bm = billReminderMinuteText.toIntOrNull()?.coerceIn(0, 59) ?: 0
                        Text(String.format(Locale.getDefault(), "%d:%02d %s", if (bh % 12 == 0) 12 else bh % 12, bm, if (bh < 12) "AM" else "PM"))
                    }
                    Text("Morning time", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    Spacer(Modifier.weight(1f))
                    Button(onClick = {
                        val bhh = billReminderHourText.toIntOrNull(); val bmm = billReminderMinuteText.toIntOrNull()
                        if (bhh != null && bhh in 0..23 && bmm != null && bmm in 0..59) {
                            Prefs.saveBillReminder(ctx, billReminderEnabled, bhh, bmm); BillReminderWorker.schedule(ctx)
                            billReminderStatus = if (billReminderEnabled) "Morning bill reminder saved." else "Morning bill reminder disabled."
                        } else billReminderStatus = "Choose a valid morning reminder time."
                    }, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)) { Text("Save") }
                }
                billReminderStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
            } } }
            }
            if (activeSection == "Permissions") {
            item { Perm("Receive new SMS", sms, "Allow") { smsLauncher.launch(Manifest.permission.RECEIVE_SMS) } }
            item { Perm("Read existing SMS", readSms, "Allow") { readLauncher.launch(Manifest.permission.READ_SMS) } }
            if (Build.VERSION.SDK_INT >= 33) item { Perm("Post notifications", postNotifications, "Allow") { notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) } }
            item { Perm("Notification access", notif, "Open") { ctx.startActivity(Intent(AS.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } }
            item { UnparsedSmsReportCard() }
            item { Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Latest notification (debug)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Reads currently visible Android notifications, including alerts posted before MoneyTracker was opened. Select the Dubai First entry and share its raw details for troubleshooting.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { latestNotification = BankNotificationListener.refreshActiveNotifications(ctx) ?: LatestNotificationDebug.read(ctx) }, modifier = Modifier.weight(1f)) { Text("Read active notifications") }
                    Button(onClick = {
                        val payload = latestNotification ?: "No notification captured yet. Enable Notification access and wait for a bank alert."
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, payload) }
                        ctx.startActivity(Intent.createChooser(send, "Share latest notification"))
                    }, enabled = latestNotification != null, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(6.dp)); Text("Share") }
                }
                if (latestNotification == null) Text("No active notifications have been read yet. Tap Read active notifications to check again.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                else SelectionContainer { Text(latestNotification!!, style = MaterialTheme.typography.bodySmall) }
            } } }
            item { Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Test bank notification reading", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("""1. Turn Notification access on above and return to MoneyTracker.
2. Open your bank app and trigger a genuine low-value transaction or another bank alert that includes a debit/credit amount.
3. Check Home / Transactions for the new entry. Open it and confirm Source says Bank-app notification.
4. OTPs, promotional alerts and declined transactions are intentionally ignored.""", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                Text(if (notif) "Status: Android reports Notification access is enabled." else "Status: Notification access is OFF, so bank notifications cannot be read.", color = if (notif) Color(0xFF2E9E5B) else cs.error, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                Text("If a bank alert is not captured, turn notification access off and back on in Android settings. Keep MoneyTracker installed and make sure notifications are enabled in your bank app. Some banks do not include transaction details in notifications.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            } } }

            }
            if (activeSection == "AI") {
            item { Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                SectionHeader("Custom parsing rules")
                Text("Teach MoneyTracker a new bank notification format yourself. Paste a sample and use Automatic rule learning to extract reusable fields and save a local parsing rule. This avoids waiting for bank-specific parser patches.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            } } }
            item {
                OutlinedTextField(
                    value = customRuleSample,
                    onValueChange = { value ->
                        customRuleSample = value
                        customRuleAiStatus = null
                        rulesSaved = null
                        val money = Regex("(?i)(AED|DHS?|USD|EUR|GBP|INR|SAR|QAR|KWD|BHD|OMR|Rs\\.?|₹|\\$|€|£)\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)|([0-9][0-9,]*(?:\\.[0-9]{1,2})?)\\s*(AED|INR|USD|EUR|GBP)").find(value)
                        customRuleCurrency = money?.groups?.get(1)?.value ?: money?.groups?.get(4)?.value.orEmpty()
                        customRuleAmount = money?.groups?.get(2)?.value ?: money?.groups?.get(3)?.value.orEmpty()
                        customRuleDate = Regex("(?i)\\b(?:\\d{4}-\\d{2}-\\d{2}|\\d{1,2}[/.-]\\d{1,2}[/.-]\\d{2,4}|\\d{1,2}\\s+[A-Za-z]{3,9}\\s+\\d{2,4})\\b").find(value)?.value.orEmpty()
                        customRuleCard = Regex("(?i)(?:card|account|a/c|acct)[^0-9]{0,18}[xX*•.\\-]*([0-9]{4,})|[xX*•]{2,}([0-9]{4})").find(value)?.let { it.groupValues.drop(1).firstOrNull { v -> v.isNotBlank() }?.takeLast(4) }.orEmpty()
                        customRuleMerchant = (BankParser.parse(value) as? Parsed.Tx)?.merchant.orEmpty()
                        customRulePattern = suggestTransactionRegex(value, customRuleMerchant)
                        (BankParser.parse(value) as? Parsed.Tx)?.let { parsedTx ->
                            customRuleType = parsedTx.type
                            customRuleCategory = parsedTx.category
                        }
                    },
                    modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 6,
                    label = { Text("Paste sample SMS / notification") },
                    placeholder = { Text("Example: Card purchase at Example Store AED 42.50…") }
                )
            }
            if (customRuleSample.isNotBlank()) item {
                Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Check and correct the detected details", fontWeight = FontWeight.SemiBold)
                        Text("These fields are suggestions from the sample. Correct anything that is wrong before creating the rule.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        OutlinedTextField(customRuleAmount, { customRuleAmount = it }, label = { Text("Amount") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(customRuleCurrency, { customRuleCurrency = it.uppercase() }, label = { Text("Currency (AED, INR, Rs, USD…)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(customRuleMerchant, { customRuleMerchant = it }, label = { Text("Merchant / recipient") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(customRuleDate, { customRuleDate = it }, label = { Text("Transaction date") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(customRuleCard, { customRuleCard = it.filter(Char::isDigit).takeLast(4) }, label = { Text("Card / account last 4 digits") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = customRuleType == TxType.DEBIT, onClick = { customRuleType = TxType.DEBIT }, label = { Text("Expense / payment") })
                FilterChip(selected = customRuleType == TxType.CREDIT, onClick = { customRuleType = TxType.CREDIT }, label = { Text("Income / refund") })
            } }
            item { CategoryDropdown(customRuleCategory, { customRuleCategory = it }, "Category for matching messages") }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = cs.secondaryContainer), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Automatic rule learning", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = cs.onSecondaryContainer)
                        Text("Paste a real notification above. MoneyTracker will generalize the amount, date, card digits and merchant into a reusable local rule, then save it for future notifications and SMS. No bank-specific app update or internet connection is required.", style = MaterialTheme.typography.bodySmall, color = cs.onSecondaryContainer)
                        Button(onClick = {
                            val sample = customRuleSample.trim()
                            if (sample.isBlank()) {
                                rulesSaved = "Paste a real notification sample first."
                            } else {
                                val parsed = BankParser.parse(sample)
                                val inferredType = (parsed as? Parsed.Tx)?.type ?: when {
                                    Regex("(?i)salary|credited|received|refund|cashback|deposit|transfer from").containsMatchIn(sample) -> TxType.CREDIT
                                    else -> TxType.DEBIT
                                }
                                val inferredCategory = (parsed as? Parsed.Tx)?.category ?: when (inferredType) {
                                    TxType.CREDIT -> if (Regex("(?i)salary").containsMatchIn(sample)) "Salary" else "Income"
                                    else -> "Unknown"
                                }
                                val candidate = suggestTransactionRegex(sample, customRuleMerchant.ifBlank { (parsed as? Parsed.Tx)?.merchant.orEmpty() })
                                val valid = candidate.isNotBlank() && runCatching { Regex(candidate, RegexOption.IGNORE_CASE).containsMatchIn(sample) }.getOrDefault(false)
                                if (!valid) {
                                    rulesSaved = "Could not create a safe rule from this sample. Please check that it contains a transaction amount and stable wording."
                                } else {
                                    customRuleType = inferredType
                                    customRuleCategory = inferredCategory
                                    customRulePattern = candidate
                                    Prefs.addTransactionRule(ctx, inferredType.name, inferredCategory, candidate)
                                    transactionRules = Prefs.transactionRules(ctx)
                                    rulesSaved = "Learned and saved automatically. Future matching notifications and SMS will use this rule. Please verify the type and category below."
                                }
                            }
                        }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(6.dp)); Text("Automatically learn & save rule")
                        }
                    }
                }
            }
            item { OutlinedTextField(value = customRulePattern, onValueChange = { customRulePattern = it; customRuleAiStatus = null; rulesSaved = null }, modifier = Modifier.fillMaxWidth(), minLines = 2, label = { Text("Generated rule (optional manual edit)") }, supportingText = { Text("You can inspect or adjust the generated rule. Rules are matched locally against future SMS and notifications.") }) }
            item { OutlinedButton(
                onClick = {
                    if (customRuleSample.isBlank()) customRuleAiStatus = "Paste a sample message first."
                    else if (!LocalLlm.ready(ctx)) customRuleAiStatus = "No on-device AI model is installed. The local regex suggestion is ready to review or edit."
                    else scope.launch {
                        generatingCustomRule = true
                        customRuleAiStatus = "Generating a regex on this device…"
                        val prompt = "Create one Java/Kotlin-compatible case-insensitive regex for future bank transaction SMS/notifications. It MUST match this sample and use unique named capture groups where possible: (?<amount>number), (?<currency>currency code), (?<merchant>merchant/payee text), (?<card>card/account digits), (?<datetime>date and time). Generalize variable digits, amount, currency and date/time while preserving stable message wording. Use Java/Kotlin named-group syntax and no duplicate group names. Output only regex, no markdown or explanation. Sample: ${customRuleSample.take(1500)}"
                        val candidate = runCatching { LocalLlm.generate(ctx, prompt).trim().removePrefix("```").removeSuffix("```").trim() }.getOrNull()
                        val valid = candidate?.let { runCatching { Regex(it, RegexOption.IGNORE_CASE).containsMatchIn(customRuleSample) }.getOrDefault(false) } ?: false
                        if (valid && !candidate.isNullOrBlank()) {
                            customRulePattern = candidate
                            customRuleAiStatus = "AI suggestion matches the sample. Review it before saving."
                        } else customRuleAiStatus = "AI did not return a valid regex that matches this sample. Keep or edit the local suggestion."
                        generatingCustomRule = false
                    }
                }, enabled = !generatingCustomRule, modifier = Modifier.fillMaxWidth()
            ) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(6.dp)); Text(if (generatingCustomRule) "Generating…" else "Improve regex with on-device AI") } }
            customRuleAiStatus?.let { status -> item { Text(status, style = MaterialTheme.typography.bodySmall, color = if (status.startsWith("AI suggestion")) Color(0xFF218A4A) else cs.onSurfaceVariant) } }
            item { Button(
                onClick = {
                    val valid = customRulePattern.isNotBlank() && customRuleSample.isNotBlank() && runCatching { Regex(customRulePattern, RegexOption.IGNORE_CASE).containsMatchIn(customRuleSample) }.getOrDefault(false)
                    if (!valid) rulesSaved = "The regex must be valid and match the pasted sample."
                    else {
                        Prefs.addTransactionRule(ctx, customRuleType.name, customRuleCategory.trim().ifBlank { "Unknown" }, customRulePattern.trim())
                        transactionRules = Prefs.transactionRules(ctx)
                        rulesSaved = "Rule approved and saved. It will be checked for future SMS and notifications."
                    }
                }, modifier = Modifier.fillMaxWidth()
            ) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(6.dp)); Text("Approve and save custom rule") } }
            rulesSaved?.let { item { Text(it, color = if (it.startsWith("Rule approved")) Color(0xFF218A4A) else cs.error, style = MaterialTheme.typography.bodySmall) } }
            item { OutlinedButton(onClick = { test = customRuleSample }, modifier = Modifier.fillMaxWidth(), enabled = customRuleSample.isNotBlank()) { Icon(Icons.Default.Science, null); Spacer(Modifier.width(6.dp)); Text("Use sample in parser tester") } }

            item { OutlinedButton(onClick = { showAdvancedRules = !showAdvancedRules }, modifier = Modifier.fillMaxWidth()) {
                Text(if (showAdvancedRules) "Hide advanced saved rules" else "Advanced: view saved rules (${transactionRules.lineSequence().count { it.isNotBlank() }})")
            } }
            if (showAdvancedRules) item { Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Advanced users only", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text("You normally don't need to edit these technical patterns. Paste a transaction above to teach the app.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                OutlinedTextField(value = transactionRules, onValueChange = { transactionRules = it }, modifier = Modifier.fillMaxWidth(), minLines = 2, label = { Text("Saved rules") })
                Button(onClick = { Prefs.saveTransactionRules(ctx, transactionRules); rulesSaved = "Saved custom rules updated." }, modifier = Modifier.fillMaxWidth()) { Text("Save advanced edits") }
            } } }

            }
            if (activeSection == "Expense categories") {
                item { Text("Expense categories", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
                item { Text("These rules run locally on your phone before the general category fallback. Edit the merchant keywords or regular expressions for each category. Saving updates existing matching transactions and guides future SMS/notification parsing.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { Icon(Icons.Default.AddCircle, null, tint = cs.primary); Text("Add a category", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
                            OutlinedTextField(newCategoryName, { newCategoryName = it; categoryStatus = null }, Modifier.fillMaxWidth(), label = { Text("Category name") }, singleLine = true)
                            OutlinedTextField(newCategoryWords, { newCategoryWords = it; categoryStatus = null }, Modifier.fillMaxWidth(), label = { Text("Matching words or regex") }, supportingText = { Text("Use | between alternatives, e.g. bookstore|tuition") }, minLines = 1)
                            Button(onClick = {
                                val name = newCategoryName.trim()
                                val words = newCategoryWords.trim()
                                val existing = ExpenseCategories.parseRules(expenseCategoryRules)
                                val tokens = { raw: String -> Regex("[A-Za-z0-9]+").findAll(raw.replace(Regex("\\\\[bBsSdDwW]"), " ")).map { it.value.trim().lowercase() }.filter { it.length >= 2 }.toSet() }
                                val candidateTokens = tokens(words)
                                val overlap = existing.firstOrNull { (cat, pattern) -> cat.equals(name, true) || candidateTokens.any { word -> tokens(pattern.pattern).contains(word) || runCatching { Regex("\\b" + Regex.escape(word) + "\\b", RegexOption.IGNORE_CASE).containsMatchIn(pattern.pattern) }.getOrDefault(false) } }
                                when { name.isBlank() || words.isBlank() -> categoryStatus = "Enter both a category name and matching words."
                                    name.equals("Unknown", true) || (ExpenseCategories.names + existing.map { it.first }).any { it.equals(name, true) } -> categoryStatus = "That category name already exists."
                                    runCatching { Regex(words, RegexOption.IGNORE_CASE) }.isFailure -> categoryStatus = "The matching pattern is not a valid regex."
                                    overlap != null -> categoryStatus = "Matching words may already belong to '${overlap.first}'. Use unique words or edit that category instead."
                                    else -> { expenseCategoryRules = (expenseCategoryRules.trimEnd() + "\n" + name + "=" + words).trim(); newCategoryName = ""; newCategoryWords = ""; categoryStatus = "Category added. Save categories to apply it." }
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add category and rule") }
                        }
                    }
                }
                (ExpenseCategories.names + ExpenseCategories.parseRules(expenseCategoryRules).map { it.first }).distinctBy { it.lowercase() }.forEach { category ->
                    item {
                        val currentPattern = expenseCategoryRules.lineSequence().firstOrNull { it.substringBefore("=").trim().equals(category, true) }?.substringAfter("=", "") ?: ExpenseCategories.defaults[category].orEmpty()
                        Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { CategoryGlyph(category, Modifier.size(22.dp), cs.primary); Text(category, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold) }
                                OutlinedTextField(currentPattern, { expenseCategoryRules = ExpenseCategories.replaceRule(expenseCategoryRules, category, it); categoryStatus = null }, modifier = Modifier.fillMaxWidth(), minLines = 1, maxLines = 3, label = { Text("Merchant keywords / regex") }, supportingText = { Text("Examples are prefilled; separate alternatives with |.") })
                            }
                        }
                    }
                }
                item { Button(onClick = {
                    val valid = ExpenseCategories.parseRules(expenseCategoryRules)
                    val names = valid.map { it.first.lowercase() }.toSet()
                    val missing = ExpenseCategories.names.filter { it.lowercase() !in names }
                    val duplicateKeyword = ExpenseCategories.duplicateKeywords(expenseCategoryRules).firstOrNull()
                    if (missing.isNotEmpty()) {
                        categoryStatus = "Add a valid pattern for: ${missing.joinToString(", ")}"
                    } else if (duplicateKeyword != null) {
                        categoryStatus = "'${duplicateKeyword.first}' is assigned to both '${duplicateKeyword.second}' and '${duplicateKeyword.third}'. Each keyword must belong to one category only."
                    } else {
                        Prefs.saveExpenseCategoryRules(ctx, expenseCategoryRules)
                        scope.launch {
                            val updatedCount = withContext(Dispatchers.IO) { applyExpenseCategoryRules(ctx, expenseCategoryRules) }
                            categoryStatus = "Saved. Updated $updatedCount existing transactions. Future matching transactions will use these categories."
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Save categories & update transactions") } }
                categoryStatus?.let { msg -> item { Text(msg, style = MaterialTheme.typography.bodySmall, color = if (msg.startsWith("Saved") || msg.startsWith("Category added")) Color(0xFF218A4A) else cs.error) } }
                item { Text("Category refresh checks each transaction against the configured words. Transactions with no matching words keep their existing category; manual category choices are preserved.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
            }
            if (activeSection == "About") {
                item { Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = cs.primary, modifier = Modifier.size(52.dp))
                        Text("MoneyTracker", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        val appVersion = remember(ctx) { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0" }
                        Text("Version $appVersion", style = MaterialTheme.typography.titleMedium)
                        Text("Track your finances, transactions, cash wallet, bills, and payments.", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    }
                } }
            }
            if (activeSection == "Export and import") {
            item { Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { SectionHeader("Backup & export"); Text("Keep a backup of your financial data on your device.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) } } }
            item { Text("Choose one folder for manual and automatic backups. ZIP backups include the database, settings and on-device model. Only the latest two ZIP backups are retained.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
            item { OutlinedButton(onClick = { backupFolderPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text(if (Prefs.backupFolderUri(ctx).isNullOrBlank()) "Choose backup folder" else "Change backup folder") } }
            item {
                val tree = Prefs.backupFolderUri(ctx)?.let { runCatching { androidx.documentfile.provider.DocumentFile.fromTreeUri(ctx, android.net.Uri.parse(it)) }.getOrNull() }
                val zipFiles = tree?.listFiles()?.filter { it.isFile && it.name.orEmpty().startsWith("moneytracker-", true) && it.name.orEmpty().endsWith(".zip", true) }.orEmpty()
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Folder: ${tree?.name ?: "Not selected"}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    Text("${zipFiles.size.coerceAtMost(2)} of 2 backup slots used · Automatic backup at 2:00 AM", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    Text(if (autoBackupEnabled && tree != null) "Automatic backup: Enabled" else if (!autoBackupEnabled) "Automatic backup: Disabled" else "Choose a folder to enable automatic backup", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
            item { Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Automatic daily backup", fontWeight = FontWeight.SemiBold); Text("Uses the selected folder · maximum 2 ZIPs", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }; Switch(autoBackupEnabled, { autoBackupEnabled = it; Prefs.saveAutoBackupEnabled(ctx, it); AutoBackupWorker.schedule(ctx) }) } }
            item { OutlinedButton(onClick = {
                scope.launch {
                    exportStatus = "Creating backup…"
                    exportStatus = try { "Backup created: ${BackupStorage.createBackup(ctx, "manual")}" } catch (e: Throwable) { "Backup failed: ${e.message}" }
                }
            }, enabled = !Prefs.backupFolderUri(ctx).isNullOrBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Backup, null); Spacer(Modifier.width(8.dp)); Text("Create backup now") } }
            item { OutlinedButton(onClick = { restoreZipLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Restore, null); Spacer(Modifier.width(8.dp)); Text("Restore from ZIP backup") } }
            item { Text("Restore replaces the current database and settings with the selected backup. Make a fresh backup first. Close and reopen the app after a successful restore.", style = MaterialTheme.typography.bodySmall, color = cs.error) }
            item { OutlinedButton(onClick = { exportCsvToSelectedFolder() }, enabled = !Prefs.backupFolderUri(ctx).isNullOrBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(8.dp)); Text("Export CSV to selected folder") } }
            item { OutlinedButton(onClick = {
                val tree = Prefs.backupFolderUri(ctx)?.let { androidx.documentfile.provider.DocumentFile.fromTreeUri(ctx, android.net.Uri.parse(it)) }
                folderCsvFiles = tree?.listFiles()?.filter { it.isFile && it.name.orEmpty().endsWith(".csv", true) }?.sortedByDescending { it.lastModified() }.orEmpty()
                showFolderCsvImport = true
            }, enabled = !Prefs.backupFolderUri(ctx).isNullOrBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FileUpload, null); Spacer(Modifier.width(8.dp)); Text("Import CSV from selected folder") } }
            item { TextButton(onClick = { importCsvLauncher.launch(arrayOf("text/*", "application/csv", "application/vnd.ms-excel")) }) { Text("Import CSV from another location") } }
            importMsg?.let { item { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) } }
            exportStatus?.let { item { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) } }

            }
            if (activeSection == "AI") {
            item { SectionHeader("Test the parser") }
            item { OutlinedTextField(test, { test = it }, Modifier.fillMaxWidth(), minLines = 3, label = { Text("Paste a bank message") }) }
            if (test.isNotBlank()) item {
                LaunchedEffect(customRules) { BankParser.setCustomRules(customRules) }
                val r = BankParser.parse(test)
                val fmt = SimpleDateFormat("d MMM yyyy", Locale.getDefault())
                Card(Modifier.fillMaxWidth()) { Text(when (r) {
                    null -> "Not recognised, so it would be ignored."
                    is Parsed.Tx -> "${r.type} ${r.currency} %,.2f".format(r.amount) + " · ${r.category}" + (r.merchant?.let { " · $it" } ?: "") + (r.account?.let { " · ${r.kind ?: "Account"} ••$it" } ?: "")
                    is Parsed.BillInfo -> "Bill: ${r.title}" + (r.amount?.let { " · ${r.currency} %,.2f".format(it) } ?: "") + (r.dueDate?.let { " · due ${fmt.format(Date(it))}" } ?: " · no due date found") + (if (r.subscription) " · subscription" else "")
                    is Parsed.BalanceInfo -> "Available balance: ${r.bank} · ${r.currency} %,.2f".format(r.amount) + (r.account?.let { " · account ending $it" } ?: "")
                }, Modifier.padding(12.dp)) }
            }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }
    }
    if (showFolderCsvImport) {
        AlertDialog(onDismissRequest = { showFolderCsvImport = false },
            title = { Text("Import from selected folder") },
            text = { Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (folderCsvFiles.isEmpty()) Text("No CSV exports found in the selected folder.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                folderCsvFiles.forEach { file ->
                    TextButton(onClick = { showFolderCsvImport = false; importCsvUri(file.uri) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Description, null); Spacer(Modifier.width(8.dp)); Text(file.name ?: "CSV file", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            } },
            confirmButton = { TextButton(onClick = { showFolderCsvImport = false }) { Text("Close") } })
    }
    screenshotText?.let { extracted ->
        var editableText by remember(extracted) { mutableStateOf(extracted) }
        val candidates = remember(editableText) { parseScreenshotTransactions(editableText) }
        var selectedTransactions by remember(editableText) { mutableStateOf(candidates.indices.toSet()) }
        val selectedCandidates = candidates.filterIndexed { index, _ -> index in selectedTransactions }
        AlertDialog(onDismissRequest = { screenshotText = null },
            title = { Text("Review screenshot transactions") },
            text = { Column(Modifier.heightIn(max = 500.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Review each detected transaction. Uncheck any entry you do not want to add. Processing percentages and page totals are ignored.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                candidates.forEachIndexed { index, item ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = index in selectedTransactions, onCheckedChange = { checked ->
                            selectedTransactions = if (checked) selectedTransactions + index else selectedTransactions - index
                        })
                        Column(Modifier.weight(1f)) {
                            Text(item.merchant, fontWeight = FontWeight.SemiBold)
                            Text(item.category, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        }
                        Text("−${"%,.2f".format(item.amount)} AED", color = cs.error, fontWeight = FontWeight.SemiBold)
                    }
                    HorizontalDivider()
                }
                Text("${selectedCandidates.size} selected of ${candidates.size}", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                OutlinedTextField(value = editableText, onValueChange = { editableText = it }, modifier = Modifier.fillMaxWidth(), minLines = 3, label = { Text("OCR text — edit if needed") })
                if (candidates.isEmpty()) Text("No merchant/amount rows found. Choose a clearer screenshot or edit the OCR text.", style = MaterialTheme.typography.bodySmall, color = cs.error)
            } },
            confirmButton = { TextButton(enabled = selectedCandidates.isNotEmpty(), onClick = {
                scope.launch {
                    try {
                        val db = AppDb.get(ctx)
                        val inserted: Int = withContext(Dispatchers.IO) {
                            selectedCandidates.fold(0) { count: Int, item: ScreenshotTransactionCandidate ->
                                val fingerprint = "SCREENSHOT|${item.timestamp}|${"%.2f".format(Locale.US, item.amount)}|${item.merchant.lowercase(Locale.ROOT).replace(Regex("\\s+"), " ").trim()}"
                                val id = db.tx().insert(Txn(amount = item.amount, currency = "AED", type = TxType.DEBIT, merchant = item.merchant, account = null, bank = "Screenshot import", kind = null, category = item.category, timestamp = item.timestamp, rawText = editableText, sourceType = "SCREENSHOT", fingerprint = fingerprint))
                                count + if (id > 0) 1 else 0
                            }
                        }
                        screenshotStatus = "Added $inserted of ${selectedCandidates.size} selected transactions${if (inserted < selectedCandidates.size) "; duplicates skipped" else ""}."
                    } catch (e: Exception) { screenshotStatus = "Import failed: ${e.localizedMessage ?: "unknown error"}" }
                    screenshotText = null
                }
            }) { Text("Add ${selectedCandidates.size} selected") } },
            dismissButton = { TextButton(onClick = { screenshotText = null }) { Text("Cancel") } })
    }
}


private data class ScreenshotTransactionCandidate(val merchant: String, val amount: Double, val timestamp: Long, val category: String)

/**
 * Parses transaction-list screenshots conservatively. OCR sometimes puts the
 * processing label on the same visual line as the purchase; remove that label
 * rather than discarding the whole transaction row. A page/day summary has no
 * merchant and is therefore never imported.
 */
private fun parseScreenshotTransactions(raw: String): List<ScreenshotTransactionCandidate> {
    val monthNames = "JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER"
    val dateMatch = Regex("(?i)\\b($monthNames)\\s+(\\d{1,2})(?:,?\\s+(\\d{4}))?\\b").find(raw)
    val month = dateMatch?.groupValues?.get(1)?.uppercase(Locale.US)?.let { runCatching { Month.valueOf(it) }.getOrNull() } ?: LocalDate.now().month
    val parsedDay = dateMatch?.groupValues?.get(2)?.toIntOrNull() ?: LocalDate.now().dayOfMonth
    val year = dateMatch?.groupValues?.get(3)?.toIntOrNull() ?: LocalDate.now().year
    val safeDay = parsedDay.coerceIn(1, YearMonth.of(year, month).lengthOfMonth())
    val timestamp = runCatching { LocalDate.of(year, month, safeDay).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() }.getOrElse { System.currentTimeMillis() }

    // Do not let the percent in "Processing 5%" become a number candidate,
    // and do not throw away a purchase if OCR combines both on one line.
    val lines = raw.replace('\u00A0', ' ').lines().map { line ->
        line.replace(Regex("(?i)\\s*processing\\s*[:：]?\\s*\\d+(?:\\.\\d+)?\\s*%?"), " ")
            .replace(Regex("\\s+"), " ").trim()
    }.filter { it.isNotBlank() }

    val amountRx = Regex("(?<![\\d.])[-−]?\\s*([0-9]{1,3}(?:,[0-9]{3})*|[0-9]+)\\.([0-9]{2})(?!\\d)")
    val headerOrNoise = Regex("(?i)^\\s*(?:($monthNames)\\b.*|total(?:\\s+spent)?|daily\\s+total|available\\s+balance|balance|transactions?)\\s*$")
    val out = linkedMapOf<String, ScreenshotTransactionCandidate>()
    var pendingMerchant: String? = null

    for (line in lines) {
        // A date/header row may also contain the day's running total (for
        // example: "OCTOBER 30  -597.15"). It must break any pending
        // merchant association so that the summary can never be assigned to
        // the last merchant when OCR returns lines in an unexpected order.
        if (headerOrNoise.matches(line)) {
            pendingMerchant = null
            continue
        }
        val match = amountRx.find(line)
        if (match == null) {
            // Keep only plausible merchant labels. Ignore standalone dates,
            // percentages, currencies and page-summary text.
            val candidate = line.replace(Regex("(?i)\\b(?:AED|DHS?|PROCESSING)\\b"), " ")
                .replace(Regex("[^A-Za-z0-9 &'()./_-]"), " ")
                .replace(Regex("\\s+"), " ").trim(' ', '-', ':')
            if (candidate.any(Char::isLetter) && candidate.length >= 3 &&
                !candidate.matches(Regex("(?i)(?:AED|DHS?|\\d{1,2}[/.-]\\d{1,2}[/.-]\\d{2,4})"))) {
                pendingMerchant = candidate
            }
            continue
        }

        val amount = (match.groupValues[1].replace(",", "") + "." + match.groupValues[2]).toDoubleOrNull() ?: continue
        if (amount <= 0.0 || amount > 10000000.0) continue

        // If merchant and amount share a line, use that pair. Otherwise attach
        // the amount to the immediately preceding merchant line only.
        val inlineMerchant = line.removeRange(match.range)
            .replace(Regex("(?i)\\b(?:AED|DHS?)\\b"), " ")
            .replace(Regex("[^A-Za-z0-9 &'()./_-]"), " ")
            .replace(Regex("\\s+"), " ").trim(' ', '-', ':')
        val merchant = inlineMerchant.takeIf { it.any(Char::isLetter) && it.length >= 3 } ?: pendingMerchant
        pendingMerchant = null
        if (merchant.isNullOrBlank()) continue

        val cleanMerchant = merchant.replace(Regex("\\s+"), " ").trim().take(70)
        val category = when {
            Regex("(?i)foodstuff|grocery|supermarket|market").containsMatchIn(cleanMerchant) -> "Groceries"
            Regex("(?i)mcdonald|tim\\s*hortons|restaurant|cafe|coffee|food").containsMatchIn(cleanMerchant) -> "Food and dining"
            Regex("(?i)crocs|shop|store|retail").containsMatchIn(cleanMerchant) -> "Shopping"
            else -> "Other"
        }
        val key = cleanMerchant.lowercase(Locale.ROOT) + "|" + String.format(Locale.US, "%.2f", amount)
        out.putIfAbsent(key, ScreenshotTransactionCandidate(cleanMerchant, amount, timestamp, category))
    }
    return out.values.toList()
}

@Composable private fun CashWalletDialog(
    db: AppDb,
    currency: String,
    rateVersion: Int = 0,
    onChanged: () -> Unit = {},
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var monthRows by remember { mutableStateOf<List<Txn>>(emptyList()) }
    var amount by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var entryType by remember { mutableStateOf("Cash spending") }
    var refresh by remember { mutableIntStateOf(0) }
    LaunchedEffect(refresh) {
        val r = monthRange(0)
        monthRows = withContext(Dispatchers.IO) {
            db.tx().between(r.first, r.second).sortedByDescending { it.timestamp }
        }
    }
    val rows = remember(monthRows) { monthRows.filter { it.isCashWalletEntry() } }
    val liveBalance = remember(monthRows, currency, rateVersion) {
        computeLiveCashWalletBalance(monthRows, currency) { from, to -> ExchangeRates.cachedRate(from, to) }
    }
    val withdrawalsTotal = remember(rows, currency, rateVersion) {
        rows.filter { it.isCashMovement() || (it.kind.equals("Cash Wallet", true) && it.type == TxType.CREDIT) }
            .sumOf { tx -> (ExchangeRates.cachedRate(tx.currency, currency) ?: if (tx.currency.equals(currency, true)) 1.0 else 1.0) * tx.amount }
    }
    val cashSpendTotal = remember(rows, currency, rateVersion) {
        rows.filter { !it.isCashMovement() && !(it.kind.equals("Cash Wallet", true) && it.type == TxType.CREDIT) }
            .sumOf { tx -> (ExchangeRates.cachedRate(tx.currency, currency) ?: if (tx.currency.equals(currency, true)) 1.0 else 1.0) * tx.amount }
    }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Cash Wallet · This Month") }, text = {
        Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "Balance: ${if (liveBalance < 0) "−" else ""}$currency ${"%,.2f".format(abs(liveBalance))}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (liveBalance < 0) MaterialTheme.colorScheme.error else Color.Unspecified
            )
            Text(
                text = "Withdrawals / added: +$currency ${"%,.2f".format(withdrawalsTotal)} · Cash spend: −$currency ${"%,.2f".format(cashSpendTotal)}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text("Calculated live from this month's cash withdrawals and cash spending. Deleting a withdrawal or adding cash spend without a withdrawal adjusts the balance automatically (including negative balances).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(entryType == "Cash spending", { entryType = "Cash spending" }, label = { Text("Spend cash") })
                FilterChip(entryType == "Add cash", { entryType = "Add cash" }, label = { Text("Add cash / withdrawal") })
            }
            OutlinedTextField(amount, { amount = it }, label = { Text("Amount") }, singleLine = true)
            OutlinedTextField(description, { description = it }, label = { Text("Description") }, singleLine = true)
            Button(onClick = {
                val a = amount.replace(",", "").toDoubleOrNull()
                if (a != null && a > 0) scope.launch {
                    withContext(Dispatchers.IO) {
                        val isAdd = entryType == "Add cash"
                        val txn = Txn(amount = a, currency = currency, type = if (isAdd) TxType.CREDIT else TxType.DEBIT,
                            merchant = description.ifBlank { if (isAdd) "Cash withdrawal" else "Cash spending" }, account = null, bank = "Cash Wallet", kind = "Cash Wallet",
                            category = if (isAdd) "Cash withdrawal" else "Cash spending", timestamp = System.currentTimeMillis(), rawText = "Manual Cash Wallet entry", fingerprint = "CASHWALLET|${UUID.randomUUID()}")
                        db.tx().insert(txn)
                    }
                    amount = ""; description = ""; refresh++; onChanged()
                }
            }, enabled = amount.replace(",", "").toDoubleOrNull()?.let { it > 0 } == true, modifier = Modifier.fillMaxWidth()) { Text("Save entry") }
            HorizontalDivider()
            Text("This month's wallet activity", style = MaterialTheme.typography.titleSmall)
            if (rows.isEmpty()) Text("No cash wallet activity in the current month.", style = MaterialTheme.typography.bodySmall)
            rows.forEach { tx ->
                val isPositive = tx.type == TxType.CREDIT || tx.isCashMovement()
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tx.merchant ?: tx.category, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(tx.timestamp)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${tx.category} • ${if (isPositive) "withdrawal / top-up" else "cash spend"}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        "${if (isPositive) "+" else "−"}${tx.currency} ${"%,.2f".format(tx.amount)}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isPositive) Color(0xFF218A4A) else Color(0xFFC62828)
                    )
                    IconButton(onClick = { scope.launch {
                        withContext(Dispatchers.IO) { db.tx().deleteById(tx.id) }
                        refresh++; onChanged()
                    } }) { Icon(Icons.Default.Delete, "Delete cash entry", tint = MaterialTheme.colorScheme.error) }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } })
}
