package com.example.moneytracker

import com.example.moneytracker.data.*
import java.time.*
import java.time.format.TextStyle
import java.util.Locale

/** Does the maths in plain Kotlin; the LLM only has to explain the numbers (small on-device models are poor at arithmetic). */
object Insights {
    fun spend(l: List<Txn>) = l.filter { it.type == TxType.DEBIT && it.counts() }
    private fun ym(t: Txn) = YearMonth.from(Instant.ofEpochMilli(t.timestamp).atZone(ZoneId.systemDefault()))

    /** Total spending for the last n months, oldest first. */
    fun monthly(all: List<Txn>, n: Int = 6): List<Pair<String, Double>> {
        val now = YearMonth.now(); val by = spend(all).groupBy { ym(it) }
        return (n - 1 downTo 0).map { now.minusMonths(it.toLong()) }
            .map { m -> m.month.getDisplayName(TextStyle.SHORT, Locale.getDefault()) to (by[m]?.sumOf { it.amount } ?: 0.0) }
    }

    private fun top(l: List<Txn>, n: Int, key: (Txn) -> String) =
        l.groupBy(key).mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }.take(n)

    fun facts(period: List<Txn>, history: List<Txn>, label: String): String {
        val out = spend(period); val inc = period.filter { it.type == TxType.CREDIT && it.counts() }
        val months = monthly(history); val last = months.last().second; val prev = months.dropLast(1).lastOrNull()?.second ?: 0.0
        val change = if (prev > 0) "%+.0f%% vs the month before".format((last - prev) / prev * 100) else "no earlier month to compare"
        val spent = out.sumOf { it.amount }; val earned = inc.sumOf { it.amount }
        fun List<Map.Entry<String, Double>>.fmt() = joinToString(", ") { "${it.key} %,.0f".format(it.value) }
        return buildString {
            appendLine("Period: $label. Currency: ${period.firstOrNull()?.currency ?: "AED"}.")
            appendLine("Spent %,.0f over %d purchases, income %,.0f, net %,.0f.".format(spent, out.size, earned, earned - spent))
            appendLine("Monthly spend, oldest to newest: " + months.joinToString(", ") { "${it.first} %,.0f".format(it.second) } + ". Latest month: $change.")
            appendLine("Top categories: " + top(out, 5) { it.category }.fmt())
            appendLine("Top merchants: " + top(out, 5) { it.merchant ?: "Unknown" }.fmt())
            appendLine("By card/account: " + top(out, 6) { it.accountLabel() }.fmt())
            out.maxByOrNull { it.amount }?.let { appendLine("Largest purchase: ${it.merchant ?: "Unknown"} %,.0f.".format(it.amount)) }
        }
    }

    fun prompt(facts: String) = "You are a personal finance assistant. Using only the figures below, write 4 short bullet points: " +
        "the spending trend, what drives it, anything unusual, and one practical tip. Never invent numbers.\n\n$facts"
}
