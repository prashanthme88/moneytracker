package com.example.moneytracker

import android.app.Notification
import android.content.*
import android.provider.Telephony
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.example.moneytracker.data.*
import com.example.moneytracker.parser.*
import kotlinx.coroutines.*
import java.util.Locale
import java.text.SimpleDateFormat

object Ingest {
    private fun fallbackMerchant(text: String): String? {
        val pattern = Regex("""(?i)\b(?:merchant(?: name)?|purchase at|spent at|paid to|payment to|at|to)\s*[:#-]?\s*([A-Za-z][A-Za-z0-9 &.'*/-]{1,35}?)(?=\s+(?:AED|DHS?|USD|EUR|GBP|INR|SAR|QAR|KWD|BHD|OMR|CAD|AUD|NZD|SGD|MYR|IDR|PHP|THB|JPY|CNY|HKD|CHF|ZAR|PKR|BDT|LKR|NPR|TRY|RUB|KRW|SEK|NOK|DKK|PLN|CZK|HUF|BRL|MXN|on|using|via|with|card|ending|date|time|ref|auth|balance|available)\b|[,;.]|$)""")
        return pattern.find(text)?.groupValues?.get(1)?.trim()?.takeIf { it.any(Char::isLetter) }
    }
    /** Dubai First has one fixed, labelled notification format. Keep it independent of the generic bank parser. */
    private fun parseDubaiFirst(text: String): Parsed.Tx? {
        val amount = Regex("(?i)\\bAmount\\s*:\\s*AED\\s*([0-9,]+(?:\\.[0-9]{1,2})?)")
            .find(text)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: return null
        val merchant = Regex("(?i)\\bAt\\s*:\\s*(.+?)(?=\\s+Date\\s*:|\\s+Available\\s+Balance\\s*:|$)")
            .find(text)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotBlank() } ?: return null
        val card = Regex("(?i)\\bCard\\s+ending\\s+with\\s*:\\s*(\\d{4})\\b")
            .find(text)?.groupValues?.get(1)
        val dateText = Regex("(?i)\\bDate\\s*:\\s*(\\d{2}/\\d{2}/\\d{4})")
            .find(text)?.groupValues?.get(1)
        val date = dateText?.let { value ->
            runCatching { SimpleDateFormat("dd/MM/yyyy", Locale.US).apply { isLenient = false }.parse(value)?.time }.getOrNull()
        }
        return Parsed.Tx(amount, "AED", TxType.DEBIT, merchant, card, "Card", "Shopping", date)
    }

    /** True if a new row was stored. historic = imported from the inbox. strict = unknown source (notifications). */
    suspend fun handle(ctx: Context, source: String, text: String, ts: Long, historic: Boolean = false, strict: Boolean = false, sourceType: String = "SMS"): Boolean {
        // Filter ad/marketing sender IDs before looking at message contents. This also protects
        // against promotional SMS whose text happens to contain a currency amount.
        if (sourceType.equals("SMS", ignoreCase = true) && source.trim().startsWith("AD-", ignoreCase = true)) return false
        val isDubaiFirst = source.contains("Dubai First", ignoreCase = true) || source.contains("dubaifirst", ignoreCase = true)
        val p = if (isDubaiFirst) parseDubaiFirst(text) else BankParser.parse(text, strict)
        if (p == null) return false
        val db = AppDb.get(ctx)
        val bucket = ts / 300_000 // 5-min window so the SMS and the push for one payment collapse into one row
        return when (p) {
            is Parsed.BalanceInfo -> {
                val label = "${p.bank} · Account ••${p.account ?: "Main"}"
                Prefs.addCustomAccount(ctx, "Bank & debit account", label)
                Prefs.saveManualBalance(ctx, label, p.amount.toString(), p.currency)
                true
            }
            is Parsed.Tx -> {
                val resolvedMerchant = p.merchant ?: fallbackMerchant(text)
                val exclusionKey = Prefs.exclusionKey(p.account, resolvedMerchant, p.category)
                if (Prefs.isExcluded(ctx, exclusionKey)) return false
                val canonicalBank = if (Regex("(?i)\\b(?:ENBDX|ENBD|Emirates\\s*NBD)\\b").containsMatchIn(source + " " + text)) "Emirates NBD" else source
                val txObj = Txn(amount = p.amount, currency = p.currency, type = p.type, merchant = resolvedMerchant,
                    account = p.account, bank = canonicalBank, kind = p.kind, category = p.category, timestamp = ts, rawText = text, sourceType = sourceType.uppercase(Locale.ROOT),
                    fingerprint = if (isDubaiFirst) "DF|${p.amount}|$ts|${p.account.orEmpty()}|${(resolvedMerchant ?: "").trim().lowercase().replace(Regex("\\s+"), " ")}" else "T|${p.amount}|${p.type}|$bucket|${(p.account ?: resolvedMerchant ?: p.category).trim().lowercase().replace(Regex("\\s+"), " ")}")
                val insertedId = db.tx().insert(txObj)
                val inserted = insertedId > 0
                if (inserted) {
                    val savedTx = txObj.copy(id = insertedId)
                    BillPayments.reconcileTransactionWithBills(ctx, db, savedTx, notify = !historic)
                    if (!historic) TransactionNotice.show(ctx, p.amount, p.currency, resolvedMerchant, p.type.name)
                }
                inserted
            }
            is Parsed.BillInfo -> {
                val today = java.time.LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
                val old = historic && (p.dueDate == null || p.dueDate < today)
                BillPayments.insertIfUnique(db, Bill(title = p.title, amount = p.amount, currency = p.currency, dueDate = p.dueDate, bank = source,
                    isSubscription = p.subscription, status = if (old) "DISMISSED" else "PENDING", rawText = text,
                    fingerprint = "B|${p.amount}|${p.dueDate}|${p.title}")) > 0
            }
        }
    }
}

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i)
        val sender = msgs.firstOrNull()?.originatingAddress ?: return
        if (!BankParser.isBankSender(sender)) return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val pending = goAsync()
        val receivedAt = msgs.maxOfOrNull { it.timestampMillis }?.takeIf { it > 0L } ?: System.currentTimeMillis()
        CoroutineScope(Dispatchers.IO).launch {
            try { Ingest.handle(c.applicationContext, sender, body, receivedAt) } finally { pending.finish() }
        }
    }
}

/** Listens to every app's notifications, but only keeps ones that read like a bank transaction or bill. No app list to maintain. */
object LatestNotificationDebug {
    private const val PREFS = "latest_notification_debug"
    fun save(ctx: Context, app: String, pkg: String, raw: String, time: Long) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("app", app).putString("package", pkg).putString("raw", raw)
            .putLong("time", time).apply()
    }
    fun read(ctx: Context): String? {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = p.getString("raw", null)?.takeIf { it.isNotBlank() } ?: return null
        val app = p.getString("app", "Unknown app") ?: "Unknown app"
        val pkg = p.getString("package", "") ?: ""
        val time = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(java.util.Date(p.getLong("time", 0L)))
        return "App: $app\nPackage: $pkg\nReceived: $time\n\nNotification text:\n$raw"
    }
}

class BankNotificationListener : NotificationListenerService() {
    companion object {
        @Volatile private var connectedListener: BankNotificationListener? = null

        fun refreshActiveNotifications(ctx: Context): String? {
            val listener = connectedListener
                ?: return "Notification listener is not connected. Turn Notification access off and on, then reopen MoneyTracker."
            return listener.refreshActiveNotificationsNow()
        }
    }

    private fun refreshActiveNotificationsNow(): String? {
        val active = runCatching { activeNotifications?.toList().orEmpty() }.getOrElse { emptyList() }
        if (active.isEmpty()) return "Android returned no active notifications. Keep the Dubai First notification expanded in the notification shade and tap Refresh again."
        // Prefer Dubai First when present; otherwise show the newest non-chat notification.
        val candidates = active.filter { sbn ->
            val pkg = sbn.packageName
            !isGroupSummary(sbn) && hasNotificationContent(sbn) && !sbn.isOngoing && pkg != packageName && pkg !in ignore && pkg != Telephony.Sms.getDefaultSmsPackage(this)
        }.sortedByDescending { it.postTime }
        val target = candidates.firstOrNull { sbn ->
            val label = runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() }.getOrDefault(sbn.packageName)
            label.contains("Dubai First", true) || sbn.packageName.contains("dubaifirst", true) || sbn.packageName.contains("dubai.first", true)
        } ?: candidates.firstOrNull()
        if (target == null) return "Android returned ${active.size} active notifications, but none were eligible for debug display."
        captureDebug(target)
        return LatestNotificationDebug.read(this)
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    // Chat apps are skipped for privacy. Other apps are eligible for the local debug snapshot.
    private val ignore = setOf("com.whatsapp", "org.telegram.messenger", "com.facebook.orca", "com.google.android.apps.messaging",
        "com.samsung.android.messaging", "com.android.mms")

    override fun onListenerConnected() {
        super.onListenerConnected()
        connectedListener = this
        // Process only actual child notifications; Samsung's aggregate group summaries contain no transaction text.
        runCatching { activeNotifications?.filter { !isGroupSummary(it) && hasNotificationContent(it) }?.sortedBy { it.postTime }?.forEach { captureDebug(it) } }
    }

    private fun isGroupSummary(sbn: StatusBarNotification): Boolean =
        (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0 || sbn.key.contains("Aggregate_NormalNotificationSection", ignoreCase = true)

    private fun hasNotificationContent(sbn: StatusBarNotification): Boolean {
        val e = sbn.notification.extras
        return listOf(Notification.EXTRA_BIG_TEXT, Notification.EXTRA_TEXT, Notification.EXTRA_SUB_TEXT, Notification.EXTRA_SUMMARY_TEXT, Notification.EXTRA_INFO_TEXT)
            .any { key -> !e.getCharSequence(key).isNullOrBlank() } ||
            !e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES).isNullOrEmpty() || !sbn.notification.tickerText.isNullOrBlank()
    }

    private fun captureDebug(sbn: StatusBarNotification, receivedAt: Long = sbn.postTime) {
        val pkg = sbn.packageName
        if (isGroupSummary(sbn) || !hasNotificationContent(sbn) || sbn.isOngoing || pkg == packageName || pkg in ignore || pkg == Telephony.Sms.getDefaultSmsPackage(this)) return
        val n = sbn.notification
        val e = n.extras
        val fields = listOf(
            "title" to e.getCharSequence(Notification.EXTRA_TITLE),
            "text" to e.getCharSequence(Notification.EXTRA_TEXT),
            "bigText" to e.getCharSequence(Notification.EXTRA_BIG_TEXT),
            "subText" to e.getCharSequence(Notification.EXTRA_SUB_TEXT),
            "summaryText" to e.getCharSequence(Notification.EXTRA_SUMMARY_TEXT),
            "infoText" to e.getCharSequence(Notification.EXTRA_INFO_TEXT),
            "textLines" to e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.joinToString("\n"),
            "ticker" to n.tickerText,
            "appLabel" to runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)) }.getOrNull()
        )
        val label = runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
        val detail = fields.filter { it.second != null && it.second.toString().isNotBlank() }
            .joinToString("\n") { (key, value) -> "$key: $value" }
        val keyDump = e.keySet().sorted().joinToString(", ")
        val raw = "App: $label\nPackage: $pkg\nNotification key: ${sbn.key}\nCategory: ${n.category}\nTemplate: ${e.getString(Notification.EXTRA_TEMPLATE)}\nExtras keys: $keyDump\n\n$detail"
        LatestNotificationDebug.save(applicationContext, label, pkg, raw, receivedAt)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Ignore empty/group-summary notifications before they can replace the last useful debug snapshot.
        if (isGroupSummary(sbn) || !hasNotificationContent(sbn)) return
        // Use Android's notification post time so the transaction keeps the time it was received,
        // including when Android re-delivers an active notification after listener reconnect.
        val receivedAt = sbn.postTime.takeIf { it > 0L } ?: System.currentTimeMillis()
        captureDebug(sbn, receivedAt)
        val pkg = sbn.packageName
        if (sbn.isOngoing || pkg == packageName || pkg in ignore || pkg == Telephony.Sms.getDefaultSmsPackage(this)) return
        val e = sbn.notification.extras
        val parts = listOfNotNull(e.getCharSequence(Notification.EXTRA_TITLE), e.getCharSequence(Notification.EXTRA_SUB_TEXT),
            e.getCharSequence(Notification.EXTRA_BIG_TEXT), e.getCharSequence(Notification.EXTRA_TEXT),
            e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.joinToString(" "), sbn.notification.tickerText)
            .map { it.toString() }.filter { it.isNotBlank() }
        val text = parts.filter { p -> parts.none { q -> q.length > p.length && q.contains(p) } }.distinct().joinToString(" ")
        if (text.length < 6) return
        val label = runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
        val parserText = "$label\n$text"
        scope.launch {
            runCatching {
                Ingest.handle(applicationContext, label, parserText, receivedAt, strict = true, sourceType = "NOTIFICATION")
            }
        }
    }
    override fun onDestroy() {
        if (connectedListener === this) connectedListener = null
        scope.cancel()
        super.onDestroy()
    }
}
