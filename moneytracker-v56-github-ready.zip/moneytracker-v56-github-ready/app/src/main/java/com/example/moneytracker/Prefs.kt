package com.example.moneytracker

import android.content.Context
import com.example.moneytracker.parser.BankParser
import java.io.File

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun load(c: Context) {
        p(c).getString("senders", null)?.let { v ->
            BankParser.smsSenders.clear(); BankParser.smsSenders += v.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        }
        BankParser.setCustomRules(combinedCategoryRules(c))
        BankParser.setTransactionTypeRules(transactionRules(c))
    }
    fun save(c: Context, senders: String, key: String) { p(c).edit().putString("senders", senders).putString("key", key).apply(); load(c) }
    fun senders(c: Context) = p(c).getString("senders", null) ?: BankParser.smsSenders.joinToString(", ")
    fun key(c: Context) = p(c).getString("key", "") ?: ""
    fun themeMode(c: Context) = p(c).getString("theme_mode", "System") ?: "System"
    fun themeAccent(c: Context) = p(c).getString("theme_accent", "Teal") ?: "Teal"
    fun saveTheme(c: Context, mode: String, accent: String) { p(c).edit().putString("theme_mode", mode).putString("theme_accent", accent).apply() }
    fun imported(c: Context) = p(c).getBoolean("imported2", false)
    fun autoBackupEnabled(c: Context) = p(c).getBoolean("auto_backup_enabled", true)
    fun backupFolderUri(c: Context): String? = p(c).getString("backup_folder_uri", null)
    fun saveBackupFolderUri(c: Context, uri: String?) { p(c).edit().putString("backup_folder_uri", uri).apply() }
    fun saveAutoBackupEnabled(c: Context, enabled: Boolean) { p(c).edit().putBoolean("auto_backup_enabled", enabled).apply() }
    fun transactionNotificationsEnabled(c: Context) = p(c).getBoolean("transaction_notifications_enabled", false)
    fun saveTransactionNotificationsEnabled(c: Context, enabled: Boolean) { p(c).edit().putBoolean("transaction_notifications_enabled", enabled).apply() }
    fun setImported(c: Context) = p(c).edit().putBoolean("imported2", true).apply()
    fun modelFile(c: Context) = File(c.filesDir, "model.task")
    fun categoryRules(c: Context) = p(c).getString("category_rules", "") ?: ""
    fun saveCategoryRules(c: Context, value: String) { p(c).edit().putString("category_rules", value).apply(); BankParser.setCustomRules(combinedCategoryRules(c)) }
    fun expenseCategoryRules(c: Context) = p(c).getString("expense_category_rules", null) ?: ExpenseCategories.defaultRules()
    fun saveExpenseCategoryRules(c: Context, value: String) { p(c).edit().putString("expense_category_rules", value).apply(); BankParser.setCustomRules(combinedCategoryRules(c)) }
    private fun combinedCategoryRules(c: Context): String = expenseCategoryRules(c) + "\n" + categoryRules(c)
    fun addMerchantCategoryRule(c: Context, category: String, merchant: String) {
        if (merchant.isBlank()) return
        if (ExpenseCategories.names.any { it.equals(category, true) }) {
            saveExpenseCategoryRules(c, ExpenseCategories.appendMerchantRule(expenseCategoryRules(c), category, merchant))
        } else {
            saveCategoryRules(c, ExpenseCategories.appendMerchantRule(categoryRules(c), category, merchant))
        }
    }
    fun transactionRules(c: Context) = p(c).getString("transaction_rules", "") ?: ""
    fun saveTransactionRules(c: Context, value: String) { p(c).edit().putString("transaction_rules", value).apply(); BankParser.setTransactionTypeRules(value) }
    fun addTransactionRule(c: Context, type: String, category: String, pattern: String) {
        val cleanPattern = pattern.replace("\n", " ").trim()
        if (cleanPattern.isBlank()) return
        val rule = listOf(type.uppercase(), category.trim().ifBlank { "Other" }, cleanPattern).joinToString("\t")
        val existing = transactionRules(c).lineSequence().filter { it.isNotBlank() }.toMutableList()
        fun signature(line: String): Set<String> = Regex("[A-Za-z]{3,}").findAll(line.substringAfterLast('\t'))
            .map { it.value.lowercase() }.filter { it !in setOf("amount", "currency", "merchant", "date", "time", "card", "account") }.toSet()
        val candidate = signature(cleanPattern)
        val similar = existing.any { old ->
            val oldParts = old.split('\t')
            oldParts.getOrNull(0).equals(type, true) && oldParts.getOrNull(1).equals(category, true) &&
                (oldParts.getOrNull(2).equals(cleanPattern, true) || run {
                    val prior = signature(old)
                    candidate.isNotEmpty() && prior.isNotEmpty() && candidate.intersect(prior).size.toDouble() / maxOf(candidate.size, prior.size) >= 0.75
                })
        }
        if (!similar) existing.add(rule)
        saveTransactionRules(c, existing.joinToString("\n"))
    }
    fun userName(c: Context) = p(c).getString("user_name", "") ?: ""
    fun saveUserName(c: Context, value: String) { p(c).edit().putString("user_name", value.trim()).apply() }
    fun dailyReminderEnabled(c: Context) = p(c).getBoolean("daily_summary_enabled", true)
    fun dailyReminderHour(c: Context) = p(c).getInt("daily_summary_hour", 20)
    fun dailyReminderMinute(c: Context) = p(c).getInt("daily_summary_minute", 0)
    fun saveDailyReminder(c: Context, enabled: Boolean, hour: Int, minute: Int) {
        p(c).edit().putBoolean("daily_summary_enabled", enabled).putInt("daily_summary_hour", hour.coerceIn(0, 23)).putInt("daily_summary_minute", minute.coerceIn(0, 59)).apply()
    }
    fun billReminderEnabled(c: Context) = p(c).getBoolean("bill_morning_reminder_enabled", true)
    fun billReminderHour(c: Context) = p(c).getInt("bill_morning_reminder_hour", 9)
    fun billReminderMinute(c: Context) = p(c).getInt("bill_morning_reminder_minute", 0)
    fun saveBillReminder(c: Context, enabled: Boolean, hour: Int, minute: Int) {
        p(c).edit().putBoolean("bill_morning_reminder_enabled", enabled).putInt("bill_morning_reminder_hour", hour.coerceIn(0, 23)).putInt("bill_morning_reminder_minute", minute.coerceIn(0, 59)).apply()
    }
    fun cachedQuote(c: Context, date: String) = if (p(c).getString("quote_date", "") == date) p(c).getString("quote_value", null) else null
    fun saveCachedQuote(c: Context, date: String, value: String) { p(c).edit().putString("quote_date", date).putString("quote_value", value).apply() }
    fun saveCloudKey(c: Context, key: String) { p(c).edit().putString("key", key).apply() }
    private fun excludedKeys(c: Context) = p(c).getStringSet("excluded_transaction_keys", emptySet())?.toMutableSet() ?: mutableSetOf()
    fun addExcludedKey(c: Context, key: String) { val set = excludedKeys(c); set.add(key); p(c).edit().putStringSet("excluded_transaction_keys", set).apply() }
    fun isExcluded(c: Context, key: String) = key in excludedKeys(c)
    fun exclusionKey(account: String?, merchant: String?, category: String): String = if (!account.isNullOrBlank()) "account:" + account.filter { it.isDigit() } else "merchant:" + (merchant ?: "unknown").trim().lowercase() + "|" + category.lowercase()

    fun mainCurrency(c: Context) = p(c).getString("main_currency", "AED") ?: "AED"
    fun saveMainCurrency(c: Context, currency: String) { p(c).edit().putString("main_currency", currency.uppercase()).apply() }
    fun monthlyBudget(c: Context) = p(c).getString("monthly_budget", "") ?: ""
    fun saveMonthlyBudget(c: Context, value: String) { p(c).edit().putString("monthly_budget", value).apply() }
    fun categoryBudgets(c: Context): Map<String, String> = p(c).getString("category_budgets_v1", "")!!.lineSequence()
        .filter { it.contains("=") }.mapNotNull { line ->
            val name = line.substringBefore("=").trim(); val value = line.substringAfter("=", "").trim()
            if (name.isBlank()) null else name to value
        }.toMap()
    fun saveCategoryBudgets(c: Context, values: Map<String, String>): Double {
        val cleaned = values.mapValues { it.value.trim() }.filterValues { it.isNotBlank() }
        p(c).edit().putString("category_budgets_v1", cleaned.entries.joinToString("\n") { "${it.key}=${it.value}" }).apply()
        val total = cleaned.values.sumOf { it.replace(",", "").toDoubleOrNull()?.takeIf { n -> n >= 0 } ?: 0.0 }
        if (cleaned.isNotEmpty()) saveMonthlyBudget(c, total.toString())
        return total
    }
    fun chartType(c: Context) = p(c).getString("chart_type", "Column Chart") ?: "Column Chart"
    fun saveChartType(c: Context, value: String) { p(c).edit().putString("chart_type", value).apply() }
    fun manualBalances(c: Context) = p(c).getString("manual_balances", "") ?: ""
    fun manualBalanceCurrency(c: Context, account: String): String? = p(c).getString("manual_balance_currency:" + account.lowercase(), null)
    fun saveManualBalance(c: Context, account: String, amount: String, currency: String? = null) {
        val entries = manualBalances(c).split("\n").filter { it.isNotBlank() && !it.substringBefore("=").equals(account, true) }.toMutableList()
        entries += "$account=$amount"
        val edit = p(c).edit().putString("manual_balances", entries.joinToString("\n"))
        if (!currency.isNullOrBlank()) edit.putString("manual_balance_currency:" + account.lowercase(), currency.uppercase())
        edit.apply()
    }
    fun manualBalance(c: Context, account: String): String? = manualBalances(c).lineSequence().firstOrNull { it.substringBefore("=").equals(account, true) }?.substringAfter("=", "")
    /** One-time import of the balance message supplied for HDFC Bank A/c XX9565. */
    fun seedProvidedHdfcBalance(c: Context) {
        val account = "HDFC Bank · Account ••9565"
        if (p(c).getBoolean("hdfc_balance_seeded_v1", false)) return
        addCustomAccount(c, "Bank & debit account", account)
        saveManualBalance(c, account, "25348.33", "INR")
        p(c).edit().putBoolean("hdfc_balance_seeded_v1", true).apply()
    }

    fun customAccounts(c: Context): List<Pair<String, String>> = (p(c).getString("custom_accounts_v1", "") ?: "").lineSequence()
        .filter { it.contains("|") }.mapNotNull { line ->
            val type = line.substringBefore("|").trim(); val name = line.substringAfter("|").trim()
            if (type.isBlank() || name.isBlank()) null else type to name
        }.distinctBy { (type, name) -> (type + "|" + name).lowercase() }.toList()
    fun updateCustomAccount(c: Context, oldName: String, type: String, name: String): Boolean {
        val clean = name.trim(); if (clean.isBlank()) return false
        val current = customAccounts(c)
        if (current.any { it.second.equals(clean, true) && !it.second.equals(oldName, true) }) return false
        val updated = current.map { if (it.second.equals(oldName, true)) type.trim() to clean else it }
        p(c).edit().putString("custom_accounts_v1", updated.joinToString("\n") { "${it.first}|${it.second}" }).apply()
        val balance = manualBalance(c, oldName)
        val balanceCurrency = manualBalanceCurrency(c, oldName)
        if (oldName != clean && balance != null) { saveManualBalance(c, clean, balance, balanceCurrency); removeManualBalance(c, oldName) }
        return true
    }
    fun removeCustomAccount(c: Context, name: String) {
        val updated = customAccounts(c).filterNot { it.second.equals(name, true) }
        p(c).edit().putString("custom_accounts_v1", updated.joinToString("\n") { "${it.first}|${it.second}" }).apply()
        removeManualBalance(c, name)
    }
    fun removeManualBalance(c: Context, account: String) {
        val entries = manualBalances(c).split("\n").filter { it.isNotBlank() && !it.substringBefore("=").equals(account, true) }
        p(c).edit().putString("manual_balances", entries.joinToString("\n")).remove("manual_balance_currency:" + account.lowercase()).apply()
    }
    private fun hiddenDetectedAccounts(c: Context) = p(c).getStringSet("hidden_detected_accounts", emptySet())?.toMutableSet() ?: mutableSetOf()
    fun detectedAccountKey(bank: String, kind: String?, last4: String) = "${bank.trim().lowercase()}|${(kind ?: "account").trim().lowercase()}|$last4"
    fun isDetectedAccountHidden(c: Context, bank: String, kind: String?, last4: String) = detectedAccountKey(bank, kind, last4) in hiddenDetectedAccounts(c)
    fun hideDetectedAccount(c: Context, bank: String, kind: String?, last4: String) {
        val hidden = hiddenDetectedAccounts(c); hidden.add(detectedAccountKey(bank, kind, last4))
        p(c).edit().putStringSet("hidden_detected_accounts", hidden).apply()
    }
    fun detectedAccountCustomName(c: Context, bank: String, kind: String?, last4: String): String? =
        p(c).getString("detected_name:" + detectedAccountKey(bank, kind, last4), null)?.takeIf { it.isNotBlank() }
    fun saveDetectedAccountCustomName(c: Context, bank: String, kind: String?, last4: String, name: String) {
        val key = "detected_name:" + detectedAccountKey(bank, kind, last4)
        val clean = name.trim()
        if (clean.isBlank()) p(c).edit().remove(key).apply() else p(c).edit().putString(key, clean).apply()
    }
    fun txNote(c: Context, txId: Long): String = p(c).getString("tx_note:$txId", "") ?: ""
    fun saveTxNote(c: Context, txId: Long, note: String) {
        val clean = note.trim()
        if (clean.isBlank()) p(c).edit().remove("tx_note:$txId").apply() else p(c).edit().putString("tx_note:$txId", clean).apply()
    }
    fun cashBalance(c: Context): Double = manualBalance(c, "Cash Wallet")?.replace(",", "")?.toDoubleOrNull() ?: 0.0
    fun saveCashBalance(c: Context, value: Double) { saveManualBalance(c, "Cash Wallet", value.toString()) }
    fun reviewedMonth(c: Context) = p(c).getString("month_reviewed", "") ?: ""
    fun saveReviewedMonth(c: Context, value: String) { p(c).edit().putString("month_reviewed", value).apply() }
    fun addCustomAccount(c: Context, type: String, name: String): Boolean {
        val clean = name.trim()
        if (clean.isBlank()) return false
        val current = customAccounts(c)
        if (current.any { it.second.equals(clean, true) }) return false
        val updated = (current + (type.trim() to clean)).distinctBy { (t, n) -> (t + "|" + n).lowercase() }
        p(c).edit().putString("custom_accounts_v1", updated.joinToString("\n") { "${it.first}|${it.second}" }).apply()
        return true
    }

}
