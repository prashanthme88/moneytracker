package com.example.moneytracker

import kotlinx.coroutines.*
import org.json.*
import java.net.*

/** Optional cloud fallback. Only the aggregated facts text is sent: no raw SMS, no card numbers. */
object AiAnalyzer {
    suspend fun ask(apiKey: String, prompt: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 1000)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        val c = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true
            setRequestProperty("x-api-key", apiKey); setRequestProperty("anthropic-version", "2023-06-01")
            setRequestProperty("content-type", "application/json")
        }
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val resp = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        JSONObject(resp).optJSONArray("content")?.optJSONObject(0)?.optString("text") ?: "Analysis failed: $resp"
    }
}
